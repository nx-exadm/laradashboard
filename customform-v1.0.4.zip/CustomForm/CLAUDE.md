# CLAUDE.md — Custom Forms Module

This file provides guidance to Claude Code (claude.ai/code) when working with the **Custom Forms** module of Lara Dashboard.

## Module Overview

**Namespace**: `Modules\CustomForm\`
**Alias**: `customform`
**Path**: `modules/customform/`
**Version**: see `module.json`

Dynamic form builder — create, publish, and manage custom forms with a visual schema builder. Forms are embeddable on public pages. Submissions are stored and exportable. Includes a REST API and Livewire submission component for embedding.

## Quick Commands

### Development

```bash
composer run dev    # Start dev server from project root
```

### Testing

```bash
php artisan test modules/customform/tests/
php artisan test --filter=CustomForm
vendor/bin/pint --dirty
```

### Module Management

```bash
php artisan module:enable customform
php artisan module:migrate customform
php artisan module:seed customform
```

---

## Module Architecture

### Directory Structure

```
modules/customform/
├── app/
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── CustomFormBaseController.php        ← Base controller
│   │   │   ├── CustomFormController.php            ← Admin CRUD + public form render
│   │   │   ├── CustomFormSubmissionController.php  ← Submission management
│   │   │   └── Api/
│   │   │       └── FormApiController.php           ← REST API endpoints
│   │   └── Requests/
│   │       ├── CustomFormRequest.php               ← Form create/update validation
│   │       └── CustomFormSubmissionRequest.php     ← Submission validation
│   ├── Livewire/Components/
│   │   ├── CustomFormDatatable.php                 ← Forms listing datatable
│   │   ├── FormDatatable.php
│   │   ├── SubmissionDatatable.php                 ← Submissions listing
│   │   ├── FormSubmission.php                      ← Embedded form (by ID)
│   │   └── FormSubmissionBySlug.php                ← Embedded form (by slug)
│   ├── Models/
│   │   ├── CustomForm.php                          ← Has form_schema (JSON), slug, is_active
│   │   └── CustomFormSubmission.php                ← Has form_data (JSON)
│   ├── Providers/
│   │   ├── CustomFormServiceProvider.php
│   │   ├── CustomFormLivewireServiceProvider.php
│   │   ├── EventServiceProvider.php
│   │   └── RouteServiceProvider.php
│   └── Services/
│       ├── CustomFormService.php                   ← Form CRUD + permissions
│       ├── CustomFormSubmissionService.php         ← Submission handling
│       ├── CustomFormMenuService.php
│       └── CustomFormBootstrapService.php
├── database/
│   ├── migrations/
│   └── factories/
├── resources/views/
│   └── pages/
│       ├── custom-forms/                           ← Admin CRUD views
│       └── submissions/                            ← Submission views
└── routes/
    └── web.php
```

### Core Data Model

```
CustomForm
├── title         (string)
├── slug          (string, unique — used for public embed URL)
├── description   (text, nullable)
├── form_schema   (JSON) ← Array of field definitions
├── is_active     (boolean)
├── created_by    (FK → users)
└── updated_by    (FK → users)

CustomFormSubmission
├── form_id       (FK → custom_forms)
├── form_data     (JSON) ← Key-value pairs matching form_schema fields
├── submitted_by  (FK → users, nullable — guests can submit)
└── ip_address    (string)
```

### Form Schema Structure

The `form_schema` JSON column stores an array of field definitions:

```json
[
  { "type": "text",     "name": "full_name",   "label": "Full Name",    "required": true },
  { "type": "email",    "name": "email",        "label": "Email",        "required": true },
  { "type": "select",   "name": "country",      "label": "Country",      "options": ["US", "UK", "BD"] },
  { "type": "textarea", "name": "message",      "label": "Message",      "required": false },
  { "type": "checkbox", "name": "agree_terms",  "label": "I agree",      "required": true }
]
```

Supported field types: `text`, `email`, `textarea`, `select`, `checkbox`, `radio`, `number`, `date`, `file`

---

## Routing

### Admin routes

```
admin.custom-forms.index
admin.custom-forms.create
admin.custom-forms.store
admin.custom-forms.show
admin.custom-forms.edit
admin.custom-forms.update
admin.custom-forms.destroy
admin.custom-forms.bulk-delete

admin.custom-forms.submissions.index   ← /admin/custom-forms/{form}/submissions
admin.custom-forms.submissions.show
admin.custom-forms.submissions.export  ← CSV export
admin.custom-forms.submissions.destroy
admin.custom-forms.submissions.bulk-delete
```

### Public routes

```
forms.render   ← GET /forms/{slug}         ← Public form page
forms.submit   ← POST /forms/{form_id}/submit
```

### API routes

```
api.custom-forms.*   ← /api/customform/* (REST API via FormApiController)
```

---

## Embedding a Form

**Option 1 — Full-page public URL:**

```
https://yoursite.com/forms/{slug}
```

**Option 2 — Livewire component by slug:**

```blade
<livewire:customform::form-submission-by-slug slug="contact-us" />
```

**Option 3 — Livewire component by ID:**

```blade
<livewire:customform::form-submission :formId="42" />
```

**Option 4 — REST API:**

```
GET  /api/customform/forms/{id}          ← Get form schema
POST /api/customform/forms/{id}/submit   ← Submit form data
```

### Tailwind CSS Prefix

This module uses `prefix(cf)` in its Tailwind CSS config (`resources/assets/css/app.css`). Every Tailwind utility class in module views **must** be prefixed with `cf:`:

```blade
{{-- Correct — prefixed --}}
<div class="cf:py-4 cf:flex cf:items-center cf:gap-2">

{{-- Wrong — class won't be generated by the module CSS --}}
<div class="py-4 flex items-center gap-2">
```

After enabling the module CSS in the layout, run once from the module directory:
```bash
cd modules/customform && npm install && npm run build
```
Shared component classes (`btn`, `btn-primary`, `form-control`, etc.) come from the main app CSS — use them **without** the prefix.

---

## Permissions

```
custom_form.view
custom_form.create
custom_form.edit
custom_form.delete
```

Check permissions:

```php
abort_unless(auth()->user()->can('custom_form.edit'), 403);
```

---

## Coding Conventions

> Note: existing model files may not have `declare(strict_types=1)`. **All new files must include it.**

```php
<?php

declare(strict_types=1);

namespace Modules\CustomForm\Http\Controllers;
```

### Service example

```php
class CustomFormService
{
    public function create(array $data): CustomForm
    {
        $data['slug'] = $data['slug'] ?? Str::slug($data['title']);
        $data['created_by'] = auth()->id();
        return CustomForm::create($data);
    }

    public function update(CustomForm $form, array $data): CustomForm
    {
        $data['updated_by'] = auth()->id();
        $form->update($data);
        return $form;
    }

    public function getAll(array $filters = []): LengthAwarePaginator
    {
        return CustomForm::query()
            ->when($filters['search'] ?? null, fn ($q, $s) =>
                $q->where('title', 'like', "%{$s}%"))
            ->when(isset($filters['is_active']), fn ($q) =>
                $q->where('is_active', $filters['is_active']))
            ->latest()
            ->paginate(15);
    }
}
```

### Submission handling

```php
class CustomFormSubmissionService
{
    public function store(CustomForm $form, array $data): CustomFormSubmission
    {
        return CustomFormSubmission::create([
            'form_id'      => $form->id,
            'form_data'    => $data,
            'submitted_by' => auth()->id(),
            'ip_address'   => request()->ip(),
        ]);
    }

    public function exportCsv(CustomForm $form): StreamedResponse
    {
        // Build CSV from form_schema headers + submission form_data values
    }
}
```

---

## Adding New Form Field Types

1. Add the field type to `resources/views/livewire/components/form-builder.blade.php` field type selector
2. Add rendering logic in `resources/views/livewire/components/form-submission.blade.php`
3. Add validation logic in `CustomFormSubmissionRequest`
4. Update the schema type documentation above

---

## Testing

```php
<?php

declare(strict_types=1);

namespace Modules\CustomForm\Tests\Feature;

use Tests\TestCase;
use Modules\CustomForm\Models\CustomForm;

class CustomFormControllerTest extends TestCase
{
    public function test_admin_can_view_forms(): void
    {
        $this->actingAsAdmin()
            ->get(route('admin.custom-forms.index'))
            ->assertOk();
    }

    public function test_can_create_form(): void
    {
        $data = [
            'title' => 'Contact Form',
            'slug' => 'contact-form',
            'form_schema' => json_encode([
                ['type' => 'text', 'name' => 'name', 'label' => 'Name', 'required' => true],
            ]),
            'is_active' => true,
        ];

        $this->actingAsAdmin()
            ->post(route('admin.custom-forms.store'), $data)
            ->assertRedirect(route('admin.custom-forms.index'));

        $this->assertDatabaseHas('custom_forms', ['slug' => 'contact-form']);
    }

    public function test_public_can_submit_form(): void
    {
        $form = CustomForm::factory()->active()->create();

        $this->post(route('forms.submit', $form->id), ['name' => 'John'])
            ->assertRedirect();

        $this->assertDatabaseHas('custom_form_submissions', ['form_id' => $form->id]);
    }
}
```

---

## Important Reminders

1. **Strict types** — `declare(strict_types=1)` on all new files.
2. **JSON schema** — `form_schema` and `form_data` are JSON columns; always cast to `array` in the model.
3. **Public submissions** — `forms.submit` route has no auth middleware; validate carefully to prevent spam.
4. **Slug uniqueness** — Slugs must be unique; auto-generate from title if not provided.
5. **Export** — `submissions.export` generates CSV; never load all submissions into memory.
6. **API routes** — `FormApiController` serves the REST API; always return proper JSON responses.
7. **Run Pint** — `vendor/bin/pint --dirty` before every commit.
8. **SOLID / DRY / KISS** — Keep it simple.
