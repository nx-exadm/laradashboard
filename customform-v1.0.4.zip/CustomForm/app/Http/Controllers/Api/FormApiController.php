<?php

declare(strict_types=1);

namespace Modules\CustomForm\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Modules\CustomForm\Models\CustomForm;

class FormApiController extends Controller
{
    /**
     * List custom forms with optional search and pagination.
     * Used by LaraBuilder Custom Form Embed block.
     */
    public function index(Request $request): JsonResponse
    {
        $this->checkAuthorization(Auth::user(), ['custom_form.view']);

        $query = CustomForm::query()
            ->select([
                'id',
                'title',
                'slug',
                'description',
                'is_active',
                'form_schema',
            ])
            ->where('is_active', '1');

        if ($search = $request->input('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('title', 'like', "%{$search}%")
                    ->orWhere('slug', 'like', "%{$search}%")
                    ->orWhere('description', 'like', "%{$search}%");
            });
        }

        $limit = min((int) $request->input('limit', 50), 100);
        $forms = $query->orderBy('title')->limit($limit)->get();

        return response()->json([
            'success' => true,
            'data' => $forms,
        ]);
    }

    /**
     * Get a single custom form by ID.
     * Used by LaraBuilder Custom Form Embed block.
     */
    public function show(int $id): JsonResponse
    {
        $this->checkAuthorization(Auth::user(), ['custom_form.view']);

        $form = CustomForm::query()
            ->select([
                'id',
                'title',
                'slug',
                'description',
                'is_active',
                'form_schema',
            ])
            ->find($id);

        if (! $form) {
            return response()->json([
                'success' => false,
                'message' => __('Form not found'),
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $form,
        ]);
    }
}
