<?php

declare(strict_types=1);

namespace Modules\CustomForm\Http\Controllers;

use App\Http\Controllers\Controller;

class CustomFormBaseController extends Controller
{
    protected string $mainTitle = '';

    public array $breadcrumbs = [];

    protected array $mainCrumb = [];

    protected function getMainCrumb(): array
    {
        return [
            'label' => __('Custom Forms'),
            'url' => route('admin.custom-forms.index'),
        ];
    }

    public function __construct()
    {
        $this->mainCrumb = $this->getMainCrumb();

        $this->mainTitle = __('Custom Forms');

        $this->breadcrumbs = [
            'title' => $this->mainTitle,
            'items' => [
                $this->mainCrumb,
            ],
        ];
    }

    protected function addCustomFormMainCrumb(): self
    {
        $mainCrumb = $this->getMainCrumb();
        $this->addBreadcrumbItem($mainCrumb['label'], $mainCrumb['url']);

        return $this;
    }
}
