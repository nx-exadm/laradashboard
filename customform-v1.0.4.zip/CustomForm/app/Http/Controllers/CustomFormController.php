<?php

declare(strict_types=1);

namespace Modules\CustomForm\Http\Controllers;

use App\Enums\ActionType;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Modules\CustomForm\Http\Requests\CustomFormRequest;
use Modules\CustomForm\Http\Requests\CustomFormSubmissionRequest;
use Modules\CustomForm\Services\CustomFormService;

class CustomFormController extends CustomFormBaseController
{
    public function __construct(
        private readonly CustomFormService $formService,
    ) {
        parent::__construct();
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $this->checkAuthorization(Auth::user(), ['custom_form.view']);

        $this->setBreadcrumbIcon('lucide:file-edit')
            ->setBreadcrumbActionButton(
                route('admin.custom-forms.create'),
                __('New Form'),
                'feather:plus',
                'custom_form.create'
            );

        return $this->renderViewWithBreadcrumbs('customform::index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $this->checkAuthorization(Auth::user(), ['custom_form.create']);

        $this->setBreadcrumbTitle(__('Create Form'))
            ->setBreadcrumbIcon('lucide:file-edit')
            ->addCustomFormMainCrumb();

        return $this->renderViewWithBreadcrumbs('customform::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(CustomFormRequest $request)
    {
        $this->checkAuthorization(Auth::user(), ['custom_form.create']);

        try {
            $this->formService->createForm($request->validated());
            $this->storeActionLog(ActionType::CREATED, ['form' => $request->validated()]);

            return redirect()->route('admin.custom-forms.index')->with('success', __('Form created successfully.'));
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', __('Failed to create form.'));
        }
    }

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        $this->checkAuthorization(Auth::user(), ['custom_form.view']);

        $form = $this->formService->getFormById((int) $id);

        if (! $form) {
            return redirect()->route('admin.custom-forms.index')->with('error', __('Form not found.'));
        }

        $this->setBreadcrumbTitle($form->title)
            ->setBreadcrumbIcon('lucide:file-edit')
            ->addCustomFormMainCrumb()
            ->addBreadcrumbItem($form->title);

        return $this->renderViewWithBreadcrumbs('customform::show', [
            'form' => $form,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(int $id)
    {
        $this->checkAuthorization(Auth::user(), ['custom_form.edit']);

        $form = $this->formService->getFormById((int) $id);

        if (! $form) {
            return redirect()->route('admin.custom-forms.index')->with('error', __('Form not found.'));
        }

        $this->setBreadcrumbTitle(__('Edit Form'))
            ->setBreadcrumbIcon('lucide:file-edit')
            ->addCustomFormMainCrumb()
            ->setBreadcrumbActionButton(
                route('admin.custom-forms.submissions.index', $form->id),
                __('View Submissions'),
                'feather:inbox',
                'custom_form.view',
                true,
            );

        return $this->renderViewWithBreadcrumbs('customform::edit', [
            'form' => $form,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(CustomFormRequest $request, int $id): RedirectResponse
    {
        $this->checkAuthorization(Auth::user(), ['custom_form.edit']);

        try {
            $form = $this->formService->getFormById((int) $id);

            if (! $form) {
                return redirect()->route('admin.custom-forms.index')->with('error', __('Form not found.'));
            }

            $this->formService->updateForm($form, $request->validated());
            $this->storeActionLog(ActionType::UPDATED, ['form' => $form]);

            return redirect()->route('admin.custom-forms.index')->with('success', __('Form updated successfully.'));
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', __('Failed to update form.'));
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(int $id)
    {
        $this->checkAuthorization(Auth::user(), ['custom_form.delete']);

        try {
            $form = $this->formService->getFormById((int) $id);

            if (! $form) {
                return redirect()->route('admin.custom-forms.index')->with('error', __('Form not found.'));
            }

            $this->formService->deleteForm($form);
            $this->storeActionLog(ActionType::DELETED, ['form' => $form]);

            return redirect()->route('admin.custom-forms.index')->with('success', __('Form deleted successfully.'));
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', __('Failed to delete form.'));
        }
    }

    /**
     * Bulk delete forms
     */
    public function bulkDelete(Request $request): RedirectResponse
    {
        $this->checkAuthorization(Auth::user(), ['custom_form.delete']);

        $ids = $request->input('ids', []);

        if (empty($ids)) {
            return redirect()->route('admin.custom-forms.index')
                ->with('error', __('No forms selected for deletion'));
        }

        $forms = $this->formService->getFormsByIds($ids);
        $deletedCount = 0;

        foreach ($forms as $form) {
            $form = ld_apply_filters('custom_form_delete_before', $form);
            $form->delete();
            ld_apply_filters('custom_form_delete_after', $form);

            $this->storeActionLog(ActionType::DELETED, ['form' => $form]);
            ld_do_action('custom_form_delete_after', $form);

            $deletedCount++;
        }

        if ($deletedCount > 0) {
            session()->flash('success', __(':count forms deleted successfully', ['count' => $deletedCount]));
        } else {
            session()->flash('error', __('No forms were deleted.'));
        }

        return redirect()->route('admin.custom-forms.index');
    }

    /**
     * Render form in frontend
     */
    public function renderForm(string $slug)
    {
        $form = $this->formService->getFormBySlug($slug);

        if (! $form || ! $form->is_active) {
            abort(404, __('Form not found.'));
        }

        return view('customform::frontend.render', [
            'form' => $form,
        ]);
    }

    /**
     * Submit form from frontend
     */
    public function submitForm(CustomFormSubmissionRequest $request, int $formId)
    {
        $form = $this->formService->getFormById($formId);

        if (! $form || ! $form->is_active) {
            abort(404, __('Form not found.'));
        }

        try {
            $this->formService->submitForm($form, $request->validated());

            return redirect()->back()->with('success', __('Form submitted successfully.'));
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', __('Failed to submit form.'));
        }
    }
}
