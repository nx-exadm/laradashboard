<?php

declare(strict_types=1);

namespace Modules\CustomForm\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\View\View;
use Modules\CustomForm\Models\CustomForm;
use Modules\CustomForm\Models\CustomFormSubmission;
use Modules\CustomForm\Services\CustomFormSubmissionService;

class CustomFormSubmissionController extends CustomFormBaseController
{
    public function __construct(
        protected CustomFormSubmissionService $submissionService
    ) {
        parent::__construct();
    }

    /**
     * Display submissions for a form.
     */
    public function index(CustomForm $form): View
    {
        $this->authorize('custom_form.view');

        $statistics = $this->submissionService->getStatistics($form);

        $this->addBreadcrumbItem($form->title, route('admin.custom-forms.show', $form->id))
            ->addBreadcrumbItem(__('Submissions'))
            ->setBreadcrumbIcon('lucide:file-edit')
            ->setBreadcrumbTitle(__('Submissions'))
            ->setBreadcrumbActionButton(
                route('admin.custom-forms.submissions.export', ['form' => $form->id]),
                __('Export CSV'),
                'feather:download',
                'custom_form.view',
            );

        return $this->renderViewWithBreadcrumbs('customform::submissions.index', [
            'form' => $form,
            'statistics' => $statistics,
        ]);
    }

    /**
     * Show a single submission.
     */
    public function show(CustomForm $form, CustomFormSubmission $submission): View|JsonResponse
    {
        $this->authorize('custom_form.view');

        // Ensure submission belongs to this form
        if ($submission->form_id !== $form->id) {
            abort(404);
        }

        // Mark submission as viewed
        $submission->markAsViewed();

        if (request()->wantsJson()) {
            return response()->json([
                'submission' => $submission->load('user'),
                'form' => $form,
            ]);
        }

        $this->setBreadcrumbTitle(__('Submission #:id', ['id' => $submission->id]))
            ->setBreadcrumbIcon('feather:inbox')
            ->addBreadcrumbItem($form->title, route('admin.custom-forms.show', $form->id))
            ->addBreadcrumbItem(__('Submissions'), route('admin.custom-forms.submissions.index', $form->id))
            ->setBreadcrumbActionButton(
                route('admin.custom-forms.submissions.export', ['form' => $form->id]),
                __('Export CSV'),
                'feather:download',
                'custom_form.view',
            );

        return $this->renderViewWithBreadcrumbs('customform::submissions.show', [
            'form' => $form,
            'submission' => $submission,
        ]);
    }

    /**
     * Delete a submission.
     */
    public function destroy(CustomForm $form, CustomFormSubmission $submission): RedirectResponse
    {
        $this->authorize('custom_form.delete');

        // Ensure submission belongs to this form
        if ($submission->form_id !== $form->id) {
            abort(404);
        }

        $this->submissionService->deleteSubmission($submission);

        return redirect()
            ->route('admin.custom-forms.submissions.index', $form->id)
            ->with('success', __('Submission deleted successfully.'));
    }

    /**
     * Bulk delete submissions.
     */
    public function bulkDelete(Request $request, CustomForm $form): RedirectResponse|JsonResponse
    {
        $this->authorize('custom_form.delete');

        $ids = $request->input('ids', []);

        if (empty($ids)) {
            if ($request->wantsJson()) {
                return response()->json(['error' => __('No submissions selected.')], 400);
            }

            return redirect()
                ->back()
                ->with('error', __('No submissions selected.'));
        }

        // Ensure all submissions belong to this form
        $validIds = $form->submissions()->whereIn('id', $ids)->pluck('id')->toArray();
        $deletedCount = $this->submissionService->bulkDeleteSubmissions($validIds);

        if ($request->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => __(':count submission(s) deleted successfully.', ['count' => $deletedCount]),
            ]);
        }

        return redirect()
            ->route('admin.custom-forms.submissions.index', $form->id)
            ->with('success', __(':count submission(s) deleted successfully.', ['count' => $deletedCount]));
    }

    /**
     * Export submissions to CSV.
     */
    public function export(Request $request, CustomForm $form): Response
    {
        $this->authorize('custom_form.view');

        $filters = [
            'search' => $request->input('search'),
            'date_from' => $request->input('date_from'),
            'date_to' => $request->input('date_to'),
        ];

        $csvData = $this->submissionService->exportToCsv($form, $filters);

        $content = $this->buildCsvContent($csvData['headers'], $csvData['rows']);

        return response($content, 200, [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="'.$csvData['filename'].'"',
        ]);
    }

    /**
     * Build CSV content from headers and rows.
     */
    protected function buildCsvContent(array $headers, array $rows): string
    {
        $output = fopen('php://temp', 'r+');

        // Add BOM for UTF-8 compatibility
        fwrite($output, "\xEF\xBB\xBF");

        fputcsv($output, $headers);

        foreach ($rows as $row) {
            fputcsv($output, $row);
        }

        rewind($output);
        $content = stream_get_contents($output);
        fclose($output);

        return $content;
    }
}
