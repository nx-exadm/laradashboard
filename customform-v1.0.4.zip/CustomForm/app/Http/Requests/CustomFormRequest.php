<?php

declare(strict_types=1);

namespace Modules\CustomForm\Http\Requests;

use App\Http\Requests\FormRequest;
use Illuminate\Validation\Rule;

class CustomFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        $rules = [
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'form_schema' => 'required|string|json',
            'status' => 'required|in:active,inactive',
        ];

        // Add slug validation with unique constraint, except for the current form when updating
        if ($this->isMethod('put') || $this->isMethod('patch')) {
            $rules['slug'] = [
                'nullable',
                'string',
                'max:255',
                Rule::unique('custom_forms')->ignore($this->route('custom_form')),
            ];
        } else {
            $rules['slug'] = 'nullable|string|max:255|unique:custom_forms';
        }

        return ld_apply_filters('custom_forms.validation.rules', $rules);
    }

    /**
     * Get validated data with form_schema converted to array
     */
    public function validated($key = null, $default = null)
    {
        $data = parent::validated($key, $default);

        // Convert form_schema JSON string to array
        if (isset($data['form_schema']) && is_string($data['form_schema'])) {
            $data['form_schema'] = json_decode($data['form_schema'], true) ?? [];
        }

        // Convert status to is_active boolean
        if (isset($data['status'])) {
            $data['is_active'] = $data['status'] === 'active';
        }

        return $data;
    }
}
