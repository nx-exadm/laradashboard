<?php

declare(strict_types=1);

namespace Modules\CustomForm\Http\Requests;

use App\Http\Requests\FormRequest;
use Modules\CustomForm\Models\CustomForm;

class CustomFormSubmissionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        $formId = $this->route('form_id') ?? $this->input('form_id');
        $form = CustomForm::find($formId);

        if (! $form) {
            return [];
        }

        $rules = [];

        // Generate validation rules based on form schema
        foreach ($form->form_schema as $field) {
            if (isset($field['name']) && isset($field['validations'])) {
                $rules[$field['name']] = $field['validations'];
            }
        }

        return ld_apply_filters('custom_form_submissions.validation.rules', $rules, $form);
    }
}
