<?php

declare(strict_types=1);

namespace Modules\CustomForm\Livewire\Components;

use App\Livewire\Datatable\Datatable;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;
use ReflectionProperty;

abstract class CustomFormDatatable extends Datatable
{
    /**
     * Clear all filters, properly handling nullable int types.
     */
    public function clearFilters(): void
    {
        foreach ($this->getFilterPropertyNames() as $filterName) {
            if (property_exists($this, $filterName)) {
                $reflection = new ReflectionProperty($this, $filterName);
                $type = $reflection->getType();

                // If the property allows null and is an int type, set to null instead of empty string
                if ($type && $type->allowsNull() && $type->getName() === 'int') {
                    $this->{$filterName} = null;
                } else {
                    $this->{$filterName} = '';
                }
            }
        }

        $this->resetPage();
    }

    public function getRoutes(): array
    {
        $routes = [
            'create' => 'admin.custom-forms.create',
            'view' => 'admin.custom-forms.show',
            'edit' => 'admin.custom-forms.edit',
            'delete' => 'admin.custom-forms.destroy',
        ];

        // Remove routes if any of them doesn't exist.
        foreach ($routes as $key => $route) {
            if (! Route::has($route)) {
                unset($routes[$key]);
            }
        }

        // Exclude the disabled routes.
        if (! empty($this->disabledRoutes)) {
            foreach ($this->disabledRoutes as $disabledRoute) {
                unset($routes[$disabledRoute]);
            }
        }

        return $routes;
    }
}
