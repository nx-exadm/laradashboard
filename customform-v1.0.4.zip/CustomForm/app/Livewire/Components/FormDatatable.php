<?php

declare(strict_types=1);

namespace Modules\CustomForm\Livewire\Components;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Database\Eloquent\Model;
use Livewire\Attributes\Url;
use Modules\CustomForm\Models\CustomForm;
use Spatie\QueryBuilder\QueryBuilder;

class FormDatatable extends CustomFormDatatable
{
    public string $model = CustomForm::class;

    #[Url(except: '')]
    public string $statusFilter = '';

    public function getSearchbarPlaceholder(): string
    {
        return __('Search by title or slug');
    }

    public function getRoutes(): array
    {
        return [
            'create' => 'admin.custom-forms.create',
            'view' => 'admin.custom-forms.show',
            'edit' => 'admin.custom-forms.edit',
            'delete' => 'admin.custom-forms.destroy',
        ];
    }

    public function getPermissions(): array
    {
        return [
            'view' => 'custom_form.view',
            'create' => 'custom_form.create',
            'edit' => 'custom_form.edit',
            'delete' => 'custom_form.delete',
        ];
    }

    protected function getRouteParameters(): array
    {
        return [];
    }

    protected function getItemRouteParameters($item): array
    {
        return ['custom_form' => $item->id];
    }

    protected function getHeaders(): array
    {
        return [
            [
                'id' => 'id',
                'title' => __('ID'),
                'width' => '5%',
                'sortable' => true,
                'sortBy' => 'id',
            ],
            [
                'id' => 'title',
                'title' => __('Title'),
                'width' => '25%',
                'sortable' => true,
                'sortBy' => 'title',
                'searchable' => true,
            ],
            [
                'id' => 'new_submissions',
                'title' => __('New'),
                'width' => '10%',
                'sortable' => false,
            ],
            [
                'id' => 'is_active',
                'title' => __('Status'),
                'width' => '10%',
                'sortable' => true,
                'sortBy' => 'is_active',
            ],
            [
                'id' => 'embed_code',
                'title' => __('Embed Code'),
                'width' => '20%',
                'sortable' => false,
            ],
            [
                'id' => 'created_by',
                'title' => __('Created By'),
                'width' => '15%',
                'sortable' => false,
            ],
            [
                'id' => 'actions',
                'title' => __('Action'),
                'width' => '15%',
                'sortable' => false,
                'is_action' => true,
            ],
        ];
    }

    protected function getFilters(): array
    {
        return [
            [
                'id' => 'statusFilter',
                'label' => __('Status'),
                'filterLabel' => __('Filter by Status'),
                'icon' => 'lucide:toggle-left',
                'allLabel' => __('All Forms'),
                'options' => [
                    '1' => __('Active'),
                    '0' => __('Inactive'),
                ],
                'selected' => $this->statusFilter,
            ],
        ];
    }

    protected function buildQuery(): QueryBuilder
    {
        $query = QueryBuilder::for(CustomForm::query())
            ->with(['creator'])
            ->withCount(['submissions as unviewed_submissions_count' => function ($query) {
                $query->whereNull('viewed_at');
            }])
            ->when($this->search, function ($query) {
                $query->where(function ($q) {
                    $q->where('title', 'like', "%{$this->search}%")
                        ->orWhere('slug', 'like', "%{$this->search}%")
                        ->orWhere('description', 'like', "%{$this->search}%");
                });
            })
            ->when($this->statusFilter !== '', function ($query) {
                $query->where('is_active', $this->statusFilter === '1');
            });

        return $this->sortQuery($query);
    }

    public function renderTitleColumn(CustomForm $form): Renderable
    {
        return view('customform::livewire.datatable.title-column', compact('form'));
    }

    public function renderNewSubmissionsColumn(CustomForm $form): Renderable
    {
        $count = $form->unviewed_submissions_count ?? 0;
        $url = route('admin.custom-forms.submissions.index', $form->id);

        return view('customform::livewire.datatable.new-submissions-column', [
            'count' => $count,
            'url' => $url,
        ]);
    }

    public function renderIsActiveColumn(CustomForm $form): Renderable
    {
        return view('customform::livewire.datatable.status-column', compact('form'));
    }

    public function renderEmbedCodeColumn(CustomForm $form): Renderable
    {
        return view('customform::livewire.datatable.embed-code-column', compact('form'));
    }

    public function renderCreatedByColumn(CustomForm $form): string
    {
        $name = $form->creator?->full_name ?? __('Unknown');

        return '<span class="text-sm">' . e($name) . '</span>';
    }

    protected function handleBulkDelete(array $ids): int
    {
        $forms = CustomForm::whereIn('id', $ids)->get();
        $deletedCount = 0;

        foreach ($forms as $form) {
            $this->authorize('custom_form.delete', $form);

            $form = ld_apply_filters('custom_form_delete_before', $form);
            $form->delete();
            ld_apply_filters('custom_form_delete_after', $form);
            ld_do_action('custom_form_delete_after', $form);

            $deletedCount++;
        }

        return $deletedCount;
    }

    public function handleRowDelete(Model|CustomForm $form): bool
    {
        $this->authorize('custom_form.delete', $form);

        $form = ld_apply_filters('custom_form_delete_before', $form);
        $deleted = $form->delete();
        ld_apply_filters('custom_form_delete_after', $form);
        ld_do_action('custom_form_delete_after', $form);

        return $deleted;
    }

    /**
     * Add "View Submissions" button after the view action.
     */
    public function renderAfterActionView($item): string|Renderable
    {
        $submissionsCount = $item->submissions()->count();
        $url = route('admin.custom-forms.submissions.index', $item->id);

        return view('customform::livewire.datatable.action-submissions', [
            'url' => $url,
            'count' => $submissionsCount,
        ]);
    }
}
