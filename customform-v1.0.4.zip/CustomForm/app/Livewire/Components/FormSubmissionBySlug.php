<?php

declare(strict_types=1);

namespace Modules\CustomForm\Livewire\Components;

use Illuminate\Support\Facades\Auth;
use Livewire\Component;
use Modules\CustomForm\Models\CustomForm;
use Modules\CustomForm\Models\CustomFormSubmission;

class FormSubmissionBySlug extends Component
{
    public string $slug;

    public $form;

    public $fields = [];

    public $formData = [];

    public $success = false;

    public $errorMessage = '';

    public function mount(string $slug)
    {
        $this->slug = $slug;
        $this->form = CustomForm::where('slug', $slug)->first();

        // If form doesn't exist, don't break the page - just show nothing
        if (! $this->form) {
            $this->fields = [];

            return;
        }

        $this->fields = $this->form->form_schema ?? [];

        // Get authenticated user for prefilling
        $user = Auth::user();

        // Initialize formData keys based on field types
        foreach ($this->fields as $field) {
            $type = $field['type'] ?? 'text';
            $name = $field['name'] ?? '';

            // Skip button fields - they don't need form data
            if ($type === 'button') {
                continue;
            }

            // Initialize with appropriate default values
            if ($type === 'checkbox') {
                $this->formData[$name] = [];
            } else {
                // Prefill with user data if authenticated
                $this->formData[$name] = $this->getPrefillValue($name, $type, $user);
            }
        }
    }

    /**
     * Get prefill value for a field based on field name and authenticated user.
     */
    protected function getPrefillValue(string $fieldName, string $fieldType, $user): string
    {
        if (! $user) {
            return '';
        }

        // Map common field names to user attributes
        $fieldNameLower = strtolower($fieldName);

        return match (true) {
            in_array($fieldNameLower, ['email', 'email_address', 'e-mail']) => $user->email ?? '',
            in_array($fieldNameLower, ['first_name', 'firstname', 'fname']) => $user->first_name ?? '',
            in_array($fieldNameLower, ['last_name', 'lastname', 'lname', 'surname']) => $user->last_name ?? '',
            in_array($fieldNameLower, ['name', 'full_name', 'fullname']) => $user->full_name ?? $user->name ?? '',
            in_array($fieldNameLower, ['phone', 'phone_number', 'mobile', 'telephone']) => $user->phone ?? '',
            in_array($fieldNameLower, ['company', 'organization', 'company_name']) => $user->company ?? '',
            default => '',
        };
    }

    public function submit()
    {
        $rules = [];
        $messages = [];

        foreach ($this->fields as $field) {
            $type = $field['type'] ?? 'text';
            $name = $field['name'];

            // Skip button fields
            if ($type === 'button') {
                continue;
            }

            // Build validation rules
            $fieldRules = [];

            // Required rule
            if (! empty($field['required'])) {
                $fieldRules[] = 'required';
                $messages["formData.{$name}.required"] = ($field['label'] ?? ucfirst($name)) . ' is required.';
            } else {
                $fieldRules[] = 'nullable';
            }

            // Type-specific rules
            if ($type === 'email') {
                $fieldRules[] = 'email';
                $messages["formData.{$name}.email"] = 'Please enter a valid email address.';
            } elseif ($type === 'number') {
                $fieldRules[] = 'numeric';
                $messages["formData.{$name}.numeric"] = 'Please enter a valid number.';
            } elseif ($type === 'checkbox') {
                $fieldRules = [($field['required'] ?? false) ? 'required' : 'nullable', 'array'];
            }

            // Custom validations from field config
            if (! empty($field['validations'])) {
                $customRules = explode('|', $field['validations']);
                foreach ($customRules as $customRule) {
                    $customRule = trim($customRule);
                    if ($customRule && ! in_array($customRule, ['required', 'nullable'])) {
                        $fieldRules[] = $customRule;
                    }
                }
            }

            $rules['formData.' . $name] = implode('|', $fieldRules);
        }

        $this->validate($rules, $messages);

        try {
            // Allow modification of submission data before saving
            $submissionData = $this->formData;
            if (function_exists('ld_apply_filters')) {
                $submissionData = ld_apply_filters('custom_form.submission.data.before_save', $submissionData, [
                    'form' => $this->form,
                    'slug' => $this->slug,
                ]);
            }

            // Fire action hook before submission is created
            if (function_exists('ld_do_action')) {
                ld_do_action('custom_form.submission.before_create', [
                    'form' => $this->form,
                    'slug' => $this->slug,
                    'data' => $submissionData,
                ]);
            }

            $submission = CustomFormSubmission::create([
                'form_id' => $this->form->id,
                'submission_data' => $submissionData,
                'ip_address' => request()->ip(),
                'user_agent' => request()->userAgent(),
                'user_id' => Auth::id(),
            ]);

            // Fire action hook after submission is created
            if (function_exists('ld_do_action')) {
                ld_do_action('custom_form.submission.after_create', [
                    'form' => $this->form,
                    'slug' => $this->slug,
                    'submission' => $submission,
                    'data' => $submissionData,
                ]);
            }

            // Check if a redirect URL is specified via filter
            $redirectUrl = null;
            if (function_exists('ld_apply_filters')) {
                $redirectUrl = ld_apply_filters('custom_form.submission.redirect_url', null, [
                    'form' => $this->form,
                    'slug' => $this->slug,
                    'submission' => $submission,
                    'data' => $submissionData,
                ]);
            }

            if ($redirectUrl) {
                return $this->redirect($redirectUrl);
            }

            $this->success = true;
            $this->errorMessage = '';

            // Reset form data
            foreach ($this->formData as $key => $value) {
                if (is_array($value)) {
                    $this->formData[$key] = [];
                } else {
                    $this->formData[$key] = '';
                }
            }
        } catch (\Exception $e) {
            $this->errorMessage = 'An error occurred while submitting the form. Please try again.';
        }
    }

    public function render()
    {
        return view('customform::livewire.components.form-submission', [
            'form' => $this->form,
            'fields' => $this->fields,
            'success' => $this->success,
            'slug' => $this->slug,
        ]);
    }
}
