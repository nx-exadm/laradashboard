<?php

declare(strict_types=1);

namespace Modules\CustomForm\Livewire\Components;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Modules\CustomForm\Models\CustomForm;
use Modules\CustomForm\Models\CustomFormSubmission;
use Modules\CustomForm\Services\CustomFormSubmissionService;
use Spatie\QueryBuilder\QueryBuilder;

class SubmissionDatatable extends CustomFormDatatable
{
    public string $model = CustomFormSubmission::class;

    public int $formId = 0;

    public ?CustomForm $form = null;

    public function mount(): void
    {
        parent::mount();

        if ($this->formId > 0) {
            $this->form = CustomForm::findOrFail($this->formId);
        }
    }

    public function getSearchbarPlaceholder(): string
    {
        return __('Search in submissions...');
    }

    public function getRoutes(): array
    {
        return [
            'view' => 'admin.custom-forms.submissions.show',
            'delete' => 'admin.custom-forms.submissions.destroy',
            'export' => 'admin.custom-forms.submissions.export',
        ];
    }

    public function getPermissions(): array
    {
        return [
            'view' => 'custom_form.view',
            'delete' => 'custom_form.delete',
        ];
    }

    protected function getRouteParameters(): array
    {
        return ['form' => $this->formId];
    }

    protected function getItemRouteParameters($item): array
    {
        return [
            'form' => $this->formId,
            'submission' => $item->id,
        ];
    }

    protected function getHeaders(): array
    {
        $headers = [
            [
                'id' => 'id',
                'title' => __('ID'),
                'width' => '5%',
                'sortable' => true,
                'sortBy' => 'id',
            ],
        ];

        // Add dynamic columns based on form schema
        if ($this->form && is_array($this->form->form_schema)) {
            foreach ($this->form->form_schema as $field) {
                if (($field['type'] ?? '') !== 'button') {
                    $headers[] = [
                        'id' => 'field_'.($field['name'] ?? ''),
                        'title' => $field['label'] ?? $field['name'] ?? __('Unknown'),
                        'width' => 'auto',
                        'sortable' => false,
                        'field_name' => $field['name'] ?? '',
                        'renderContent' => 'renderDynamicFieldColumn',
                    ];
                }
            }
        }

        $headers = array_merge($headers, [
            [
                'id' => 'ip_address',
                'title' => __('IP Address'),
                'width' => '10%',
                'sortable' => true,
                'sortBy' => 'ip_address',
            ],
            [
                'id' => 'created_at',
                'title' => __('Submitted At'),
                'width' => '12%',
                'sortable' => true,
                'sortBy' => 'created_at',
            ],
            [
                'id' => 'actions',
                'title' => __('Actions'),
                'width' => '10%',
                'sortable' => false,
                'is_action' => true,
            ],
        ]);

        return $headers;
    }

    protected function getFilters(): array
    {
        return [];
    }

    protected function buildQuery(): QueryBuilder
    {
        $query = QueryBuilder::for(
            CustomFormSubmission::query()->where('form_id', $this->formId)
        )
            ->with(['user'])
            ->when($this->search, function ($query) {
                $query->where(function ($q) {
                    $q->whereRaw('LOWER(submission_data) LIKE ?', ['%'.strtolower($this->search).'%'])
                        ->orWhere('ip_address', 'like', "%{$this->search}%");
                });
            });

        return $this->sortQuery($query);
    }

    /**
     * Render dynamic field column content.
     */
    public function renderDynamicFieldColumn($item, array $header): string
    {
        $fieldName = $header['field_name'] ?? '';
        $value = $item->submission_data[$fieldName] ?? '';

        if (is_array($value)) {
            $value = implode(', ', $value);
        }

        $value = e((string) $value);

        // Truncate long values
        if (strlen($value) > 50) {
            $truncated = substr($value, 0, 50).'...';

            return '<span class="text-sm text-gray-700 dark:text-gray-300" title="'.$value.'">'.$truncated.'</span>';
        }

        return '<span class="text-sm text-gray-700 dark:text-gray-300">'.$value.'</span>';
    }

    public function renderIpAddressColumn($submission): string
    {
        return '<span class="text-xs text-gray-500 dark:text-gray-400 font-mono">'.e($submission->ip_address ?? '-').'</span>';
    }

    public function renderCreatedAtColumn($item): string
    {
        return '<span class="text-sm text-gray-600 dark:text-gray-400">'.$item->created_at->format('M d, Y H:i').'</span>';
    }

    protected function handleBulkDelete(array $ids): int
    {
        $this->authorize('custom_form.delete');

        $submissionService = app(CustomFormSubmissionService::class);

        // Ensure all submissions belong to this form
        $validIds = CustomFormSubmission::where('form_id', $this->formId)
            ->whereIn('id', $ids)
            ->pluck('id')
            ->toArray();

        return $submissionService->bulkDeleteSubmissions($validIds);
    }

    public function handleRowDelete(Model|CustomFormSubmission $submission): bool
    {
        $this->authorize('custom_form.delete');

        if ($submission->form_id !== $this->formId) {
            return false;
        }

        return $submission->delete();
    }

    public function export(): void
    {
        $this->redirect(
            route('admin.custom-forms.submissions.export', [
                'form' => $this->formId,
                'search' => $this->search,
            ])
        );
    }

    /**
     * Override render to mark displayed submissions as viewed.
     */
    public function render(): Renderable
    {
        $this->headers = $this->getHeaders();
        $this->filters = $this->getFilters();

        $data = $this->getData();

        // Mark all displayed submissions as viewed
        $this->markDisplayedSubmissionsAsViewed($data);

        return view('backend.livewire.datatable.datatable', [
            'headers' => $this->headers,
            'data' => $data,
            'perPage' => $this->perPage,
            'perPageOptions' => $this->perPageOptions,
        ]);
    }

    /**
     * Mark all submissions on the current page as viewed.
     */
    protected function markDisplayedSubmissionsAsViewed($data): void
    {
        // Get the IDs of submissions that are not yet viewed
        $unviewedIds = collect($data->items())
            ->filter(fn ($submission) => $submission->viewed_at === null)
            ->pluck('id')
            ->toArray();

        if (empty($unviewedIds)) {
            return;
        }

        // Bulk update to mark as viewed
        CustomFormSubmission::whereIn('id', $unviewedIds)
            ->whereNull('viewed_at')
            ->update([
                'viewed_at' => now(),
                'viewed_by' => Auth::id(),
            ]);
    }
}
