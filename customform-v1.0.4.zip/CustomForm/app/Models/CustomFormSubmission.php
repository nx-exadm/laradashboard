<?php

declare(strict_types=1);

namespace Modules\CustomForm\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Auth;

class CustomFormSubmission extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'form_id',
        'submission_data',
        'ip_address',
        'user_agent',
        'user_id',
        'viewed_at',
        'viewed_by',
    ];

    /**
     * The attributes that should be cast.
     */
    protected function casts(): array
    {
        return [
            'submission_data' => 'array',
            'viewed_at' => 'datetime',
        ];
    }

    /**
     * Get the form that owns the submission.
     */
    public function form(): BelongsTo
    {
        return $this->belongsTo(CustomForm::class, 'form_id');
    }

    /**
     * Get the user that submitted the form.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * Get the user that viewed the submission.
     */
    public function viewer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'viewed_by');
    }

    /**
     * Check if the submission has been viewed.
     */
    public function isViewed(): bool
    {
        return $this->viewed_at !== null;
    }

    /**
     * Mark the submission as viewed.
     */
    public function markAsViewed(): void
    {
        if (! $this->isViewed()) {
            $this->update([
                'viewed_at' => now(),
                'viewed_by' => Auth::id(),
            ]);
        }
    }

    /**
     * Scope for unviewed submissions.
     */
    public function scopeUnviewed($query)
    {
        return $query->whereNull('viewed_at');
    }

    /**
     * Scope for viewed submissions.
     */
    public function scopeViewed($query)
    {
        return $query->whereNotNull('viewed_at');
    }
}
