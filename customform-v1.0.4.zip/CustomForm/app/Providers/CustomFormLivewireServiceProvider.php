<?php

declare(strict_types=1);

namespace Modules\CustomForm\Providers;

use Illuminate\Support\ServiceProvider;
use Livewire\Livewire;
use Modules\CustomForm\Livewire\Components\FormDatatable;
use Modules\CustomForm\Livewire\Components\FormSubmission;
use Modules\CustomForm\Livewire\Components\FormSubmissionBySlug;
use Modules\CustomForm\Livewire\Components\SubmissionDatatable;

class CustomFormLivewireServiceProvider extends ServiceProvider
{
    /**
     * Register the service provider.
     */
    public function register(): void
    {
        //
    }

    /**
     * Boot the application events.
     */
    public function boot(): void
    {
        Livewire::component('customform::components.form-datatable', FormDatatable::class);
        Livewire::component('customform::components.form-submission', FormSubmission::class);
        Livewire::component('customform::components.form-submission-by-slug', FormSubmissionBySlug::class);
        Livewire::component('customform::components.submission-datatable', SubmissionDatatable::class);
    }
}
