<?php

declare(strict_types=1);

namespace Modules\CustomForm\Providers;

use App\Services\Builder\BuilderService;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;
use Modules\CustomForm\Services\CustomFormBootstrapService;
use Modules\CustomForm\Services\CustomFormMenuService;
use Nwidart\Modules\Traits\PathNamespace;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

class CustomFormServiceProvider extends ServiceProvider
{
    use PathNamespace;

    protected string $name = 'CustomForm';

    protected string $nameLower = 'customform';

    /**
     * Boot the application events.
     */
    public function boot(): void
    {
        $this->registerCommands();
        $this->registerCommandSchedules();
        $this->registerTranslations();
        $this->registerConfig();
        $this->registerViews();
        $this->loadMigrationsFrom(module_path($this->name, 'database/migrations'));

        $this->app->booted(function () {
            $this->app->make(CustomFormBootstrapService::class)->bootstrap();
            $this->registerBuilderBlocks();

            // Fix Livewire namespace: module name is lowercase 'customform' but PSR-4 namespace is 'Modules\CustomForm'.
            // Must run in booted() to override mhmiton/laravel-modules-livewire auto-registration.
            if (class_exists(\Livewire\Livewire::class)) {
                \Livewire\Livewire::addNamespace(
                    namespace: 'customform',
                    classNamespace: 'Modules\\CustomForm\\Livewire',
                    classPath: module_path($this->name, 'app/Livewire'),
                    classViewPath: module_path($this->name, 'resources/views/livewire'),
                );
            }
        });
    }

    /**
     * Register the service provider.
     */
    public function register(): void
    {
        // Load module's vendor autoload if it exists (for self-contained modules).
        $vendorAutoload = __DIR__ . '/../../vendor/autoload.php';
        if (file_exists($vendorAutoload)) {
            require_once $vendorAutoload;
        }

        $this->app->register(EventServiceProvider::class);
        $this->app->register(RouteServiceProvider::class);
        $this->app->register(CustomFormLivewireServiceProvider::class);

        $this->app->singleton(CustomFormMenuService::class);
        $this->app->singleton(CustomFormBootstrapService::class);
    }

    /**
     * Register commands in the format of Command::class
     */
    protected function registerCommands(): void
    {
        // $this->commands([]);
    }

    /**
     * Register command Schedules.
     */
    protected function registerCommandSchedules(): void
    {
        // $this->app->booted(function () {
        //     $schedule = $this->app->make(Schedule::class);
        //     $schedule->command('inspire')->hourly();
        // });
    }

    /**
     * Register translations.
     */
    public function registerTranslations(): void
    {
        $langPath = resource_path('lang/modules/' . $this->nameLower);

        if (is_dir($langPath)) {
            $this->loadTranslationsFrom($langPath, $this->nameLower);
            $this->loadJsonTranslationsFrom($langPath);
        } else {
            $this->loadTranslationsFrom(module_path($this->name, 'lang'), $this->nameLower);
            $this->loadJsonTranslationsFrom(module_path($this->name, 'lang'));
        }
    }

    /**
     * Register config.
     */
    protected function registerConfig(): void
    {
        $configPath = module_path($this->name, config('modules.paths.generator.config.path'));

        if (is_dir($configPath)) {
            $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($configPath));

            foreach ($iterator as $file) {
                if ($file->isFile() && $file->getExtension() === 'php') {
                    $config = str_replace($configPath . DIRECTORY_SEPARATOR, '', $file->getPathname());
                    $config_key = str_replace([DIRECTORY_SEPARATOR, '.php'], ['.', ''], $config);
                    $segments = explode('.', $this->nameLower . '.' . $config_key);

                    // Remove duplicated adjacent segments
                    $normalized = [];
                    foreach ($segments as $segment) {
                        if (end($normalized) !== $segment) {
                            $normalized[] = $segment;
                        }
                    }

                    $key = ($config === 'config.php') ? $this->nameLower : implode('.', $normalized);

                    $this->publishes([$file->getPathname() => config_path($config)], 'config');
                    $this->merge_config_from($file->getPathname(), $key);
                }
            }
        }
    }

    /**
     * Merge config from the given path recursively.
     */
    protected function merge_config_from(string $path, string $key): void
    {
        $existing = config($key, []);
        $module_config = require $path;

        config([$key => array_replace_recursive($existing, $module_config)]);
    }

    /**
     * Register views.
     */
    public function registerViews(): void
    {
        $viewPath = resource_path('views/modules/' . $this->nameLower);
        $sourcePath = module_path($this->name, 'resources/views');

        $this->publishes([$sourcePath => $viewPath], ['views', $this->nameLower . '-module-views']);

        $this->loadViewsFrom(array_merge($this->getPublishableViewPaths(), [$sourcePath]), $this->nameLower);

        Blade::componentNamespace(config('modules.namespace') . '\\' . $this->name . '\\View\\Components', $this->nameLower);
    }

    /**
     * Register LaraBuilder blocks from this module.
     */
    protected function registerBuilderBlocks(): void
    {
        $builderService = $this->app->make(BuilderService::class);

        // Register Custom Form Embed block with server-side rendering support
        // Block file structure:
        // - index.js   : Block definition and registration
        // - block.jsx  : React component for builder canvas
        // - editor.jsx : React component for properties panel
        // - save.js    : HTML generators for different contexts
        // - render.php : Server-side rendering (takes priority over save.js)
        $builderService->registerModuleBlock(
            'customform-embed',
            module_path($this->name, 'resources/js/lara-builder-blocks/customform-embed'),
            'build-customform'
        );
    }

    /**
     * Get the services provided by the provider.
     */
    public function provides(): array
    {
        return [];
    }

    private function getPublishableViewPaths(): array
    {
        $paths = [];
        foreach (config('view.paths') as $path) {
            if (is_dir($path . '/modules/' . $this->nameLower)) {
                $paths[] = $path . '/modules/' . $this->nameLower;
            }
        }

        return $paths;
    }
}
