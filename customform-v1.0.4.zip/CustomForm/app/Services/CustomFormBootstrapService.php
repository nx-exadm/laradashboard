<?php

declare(strict_types=1);

namespace Modules\CustomForm\Services;

use App\Enums\Hooks\AdminFilterHook;
use App\Support\Facades\Hook;

class CustomFormBootstrapService
{
    public function __construct(
        private readonly CustomFormMenuService $menuService
    ) {
    }

    public function bootstrap(): void
    {
        Hook::addFilter(AdminFilterHook::ADMIN_MENU_GROUPS_BEFORE_SORTING, [$this->menuService, 'addMenu']);
    }
}
