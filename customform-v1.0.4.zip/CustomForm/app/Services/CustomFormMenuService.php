<?php

declare(strict_types=1);

namespace Modules\CustomForm\Services;

use App\Services\MenuService\AdminMenuItem;
use Illuminate\Support\Facades\Route;

class CustomFormMenuService
{
    public function addMenu(array $groups): array
    {
        $adminMenuItem = $this->getMenu();
        $groups[__('Main')][] = $adminMenuItem;

        return $groups;
    }

    /**
     * Build the Custom Forms menu structure
     */
    public function getMenu(): AdminMenuItem
    {
        return (new AdminMenuItem())->setAttributes([
            'label' => __('Custom Forms'),
            'icon' => 'lucide:file-input',
            'iconImage' => asset('images/modules/customform/logo.svg'),
            'route' => route('admin.custom-forms.index'),
            'active' => Route::is('admin.custom-forms.*'),
            'id' => 'custom-forms',
            'priority' => 42,
            'permissions' => ['custom_form.view'],
        ]);
    }
}
