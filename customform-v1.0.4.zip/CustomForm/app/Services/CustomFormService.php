<?php

declare(strict_types=1);

namespace Modules\CustomForm\Services;

use Modules\CustomForm\Models\CustomForm;
use Modules\CustomForm\Models\CustomFormSubmission;
use Illuminate\Support\Str;

class CustomFormService
{
    /**
     * Get all custom form permissions.
     *
     * @return array<int, array{group_name: string, permissions: array<int, string>}>
     */
    public static function getCustomFormPermissions(): array
    {
        return [
            [
                'group_name' => 'custom_form',
                'permissions' => [
                    'custom_form.view',
                    'custom_form.create',
                    'custom_form.edit',
                    'custom_form.delete',
                ],
            ],
        ];
    }

    /**
     * Get forms with filters
     *
     * @return \Illuminate\Pagination\LengthAwarePaginator
     */
    public function getForms(array $filters = [])
    {
        $query = CustomForm::applyFilters($filters);

        if (isset($filters['is_active']) && $filters['is_active'] !== '') {
            $query->where('is_active', $filters['is_active']);
        }

        return $query->paginateData();
    }

    /**
     * Create a new form
     *
     * @param array $data
     * @return CustomForm
     */
    public function createForm(array $data): CustomForm
    {
        $form = new CustomForm();
        $form->fill($data);

        if (empty($data['slug'])) {
            $form->slug = Str::slug($data['title']);
        }

        $form->created_by = auth()->id();
        $form->save();

        return $form;
    }

    /**
     * Update an existing form
     *
     * @param CustomForm $form
     * @param array $data
     * @return CustomForm
     */
    public function updateForm(CustomForm $form, array $data): CustomForm
    {
        $form->fill($data);

        // Only update slug if explicitly provided, don't auto-generate on title change
        if (isset($data['slug']) && !empty($data['slug'])) {
            $form->slug = Str::slug($data['slug']);
        }

        $form->updated_by = auth()->id();
        $form->save();

        return $form;
    }

    /**
     * Delete a form
     *
     * @param CustomForm $form
     * @return void
     */
    public function deleteForm(CustomForm $form): void
    {
        $form->delete();
    }

    /**
     * Get form by ID
     *
     * @param int $id
     * @return CustomForm|null
     */
    public function getFormById(int $id): ?CustomForm
    {
        return CustomForm::find($id);
    }

    /**
     * Get form by slug
     *
     * @param string $slug
     * @return CustomForm|null
     */
    public function getFormBySlug(string $slug): ?CustomForm
    {
        return CustomForm::where('slug', $slug)->first();
    }

    /**
     * Get forms by form ids
     *
     * @param array $formIds
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getFormsByIds(array $formIds)
    {
        return CustomForm::whereIn('id', $formIds)->get();
    }

    /**
     * Submit a form
     *
     * @param CustomForm $form
     * @param array $data
     * @return CustomFormSubmission
     */
    public function submitForm(CustomForm $form, array $data): CustomFormSubmission
    {
        $submission = new CustomFormSubmission();
        $submission->form_id = $form->id;
        $submission->submission_data = $data;
        $submission->ip_address = request()->ip();
        $submission->user_agent = request()->userAgent();
        $submission->user_id = auth()->id();
        $submission->save();

        return $submission;
    }

    /**
     * Get submissions for a form
     *
     * @param CustomForm $form
     * @return \Illuminate\Pagination\LengthAwarePaginator
     */
    public function getFormSubmissions(CustomForm $form, array $filters = [])
    {
        $query = $form->submissions();

        if (isset($filters['search']) && $filters['search']) {
            $search = $filters['search'];
            $query->whereRaw("JSON_CONTAINS(submission_data, '{\"value\":\"$search\"}', '$')");
        }

        return $query->orderBy('created_at', 'desc')->paginate(10);
    }
}
