<?php

declare(strict_types=1);

namespace Modules\CustomForm\Services;

use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\DB;
use Modules\CustomForm\Models\CustomForm;
use Modules\CustomForm\Models\CustomFormSubmission;

class CustomFormSubmissionService
{
    /**
     * Get paginated submissions for a form with optional filters.
     */
    public function getSubmissions(
        CustomForm $form,
        array $filters = [],
        int $perPage = 15
    ): LengthAwarePaginator {
        $query = $form->submissions()->with('user')->latest();

        if (! empty($filters['search'])) {
            $search = $filters['search'];
            $query->where(function ($q) use ($search) {
                $q->whereRaw('LOWER(submission_data) LIKE ?', ['%'.strtolower($search).'%'])
                    ->orWhere('ip_address', 'like', "%{$search}%");
            });
        }

        if (! empty($filters['date_from'])) {
            $query->whereDate('created_at', '>=', $filters['date_from']);
        }

        if (! empty($filters['date_to'])) {
            $query->whereDate('created_at', '<=', $filters['date_to']);
        }

        if (! empty($filters['user_id'])) {
            $query->where('user_id', $filters['user_id']);
        }

        return $query->paginate($perPage);
    }

    /**
     * Get all submissions for a form (for export).
     */
    public function getAllSubmissions(CustomForm $form, array $filters = []): Collection
    {
        $query = $form->submissions()->with('user')->latest();

        if (! empty($filters['search'])) {
            $search = $filters['search'];
            $query->where(function ($q) use ($search) {
                $q->whereRaw('LOWER(submission_data) LIKE ?', ['%'.strtolower($search).'%'])
                    ->orWhere('ip_address', 'like', "%{$search}%");
            });
        }

        if (! empty($filters['date_from'])) {
            $query->whereDate('created_at', '>=', $filters['date_from']);
        }

        if (! empty($filters['date_to'])) {
            $query->whereDate('created_at', '<=', $filters['date_to']);
        }

        return $query->get();
    }

    /**
     * Get a single submission by ID.
     */
    public function getSubmission(int $id): ?CustomFormSubmission
    {
        return CustomFormSubmission::with(['form', 'user'])->find($id);
    }

    /**
     * Create a new form submission.
     */
    public function createSubmission(CustomForm $form, array $data): CustomFormSubmission
    {
        return DB::transaction(function () use ($form, $data) {
            return $form->submissions()->create([
                'submission_data' => $data['submission_data'],
                'ip_address' => $data['ip_address'] ?? request()->ip(),
                'user_agent' => $data['user_agent'] ?? request()->userAgent(),
                'user_id' => $data['user_id'] ?? auth()->id(),
            ]);
        });
    }

    /**
     * Delete a submission.
     */
    public function deleteSubmission(CustomFormSubmission $submission): bool
    {
        return $submission->delete();
    }

    /**
     * Bulk delete submissions.
     */
    public function bulkDeleteSubmissions(array $ids): int
    {
        return CustomFormSubmission::whereIn('id', $ids)->delete();
    }

    /**
     * Get submission statistics for a form.
     */
    public function getStatistics(CustomForm $form): array
    {
        $submissions = $form->submissions();

        return [
            'total' => $submissions->count(),
            'today' => $submissions->whereDate('created_at', today())->count(),
            'this_week' => $submissions->whereBetween('created_at', [
                now()->startOfWeek(),
                now()->endOfWeek(),
            ])->count(),
            'this_month' => $submissions->whereMonth('created_at', now()->month)
                ->whereYear('created_at', now()->year)
                ->count(),
            'authenticated_users' => $form->submissions()->whereNotNull('user_id')->count(),
            'anonymous' => $form->submissions()->whereNull('user_id')->count(),
        ];
    }

    /**
     * Export submissions as CSV data.
     */
    public function exportToCsv(CustomForm $form, array $filters = []): array
    {
        $submissions = $this->getAllSubmissions($form, $filters);
        $formSchema = $form->form_schema ?? [];

        // Build header from form schema
        $fieldLabels = [];
        foreach ($formSchema as $field) {
            if (($field['type'] ?? '') !== 'button') {
                $fieldLabels[$field['name']] = $field['label'] ?? $field['name'];
            }
        }

        $headers = array_merge(
            ['ID', 'Submitted At'],
            array_values($fieldLabels),
            ['IP Address', 'User', 'User Agent']
        );

        $rows = [];
        foreach ($submissions as $submission) {
            $row = [
                $submission->id,
                $submission->created_at->format('Y-m-d H:i:s'),
            ];

            // Add field values in order
            foreach ($fieldLabels as $fieldName => $label) {
                $value = $submission->submission_data[$fieldName] ?? '';
                if (is_array($value)) {
                    $value = implode(', ', $value);
                }
                $row[] = $value;
            }

            $row[] = $submission->ip_address ?? '';
            $row[] = $submission->user?->name ?? 'Anonymous';
            $row[] = $submission->user_agent ?? '';

            $rows[] = $row;
        }

        return [
            'headers' => $headers,
            'rows' => $rows,
            'filename' => sprintf(
                '%s-submissions-%s.csv',
                \Illuminate\Support\Str::slug($form->title),
                now()->format('Y-m-d-His')
            ),
        ];
    }
}
