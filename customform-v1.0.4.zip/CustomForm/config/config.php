<?php

return [
    'name' => 'CustomForm',
];
