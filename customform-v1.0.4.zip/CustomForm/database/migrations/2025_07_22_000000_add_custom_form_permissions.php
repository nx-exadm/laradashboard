<?php

declare(strict_types=1);

use App\Services\PermissionService;
use Illuminate\Database\Migrations\Migration;
use Modules\CustomForm\Services\CustomFormService;

return new class () extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        PermissionService::syncPermissionsForRoles(CustomFormService::getCustomFormPermissions());
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        $permissionNames = [];
        foreach (CustomFormService::getCustomFormPermissions() as $permissionGroup) {
            foreach ($permissionGroup['permissions'] as $permissionName) {
                $permissionNames[] = $permissionName;
            }
        }

        PermissionService::removePermissions($permissionNames);
    }
};
