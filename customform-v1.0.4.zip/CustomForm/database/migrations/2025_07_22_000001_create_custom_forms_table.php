<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Modules\CustomForm\Models\CustomForm;

return new class () extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('custom_forms', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->json('form_schema');
            $table->boolean('is_active')->default(true);
            $table->unsignedBigInteger('created_by')->nullable();
            $table->foreign('created_by')->references('id')->on('users')->onDelete('set null');
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('set null');
            $table->timestamps();
        });

        Schema::create('custom_form_submissions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('form_id');
            $table->foreign('form_id')->references('id')->on('custom_forms')->onDelete('cascade');
            $table->json('submission_data');
            $table->string('ip_address')->nullable();
            $table->string('user_agent')->nullable();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->timestamp('viewed_at')->nullable();
            $table->unsignedBigInteger('viewed_by')->nullable();
            $table->foreign('viewed_by')->references('id')->on('users')->onDelete('set null');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('set null');
            $table->timestamps();
        });

        $this->createSampleContactForm();
    }

    /**
     * Create a sample contact form to help users get started.
     */
    private function createSampleContactForm(): void
    {
        CustomForm::create([
            'title' => 'Contact Us',
            'slug' => 'contact-us',
            'description' => 'Have a question or feedback? Fill out the form below and we\'ll get back to you as soon as possible.',
            'is_active' => true,
            'form_schema' => [
                [
                    'type' => 'text',
                    'name' => 'first_name',
                    'label' => 'First Name',
                    'placeholder' => 'Enter your first name',
                    'required' => true,
                    'width' => 50,
                ],
                [
                    'type' => 'text',
                    'name' => 'last_name',
                    'label' => 'Last Name',
                    'placeholder' => 'Enter your last name',
                    'required' => true,
                    'width' => 50,
                ],
                [
                    'type' => 'email',
                    'name' => 'email',
                    'label' => 'Email Address',
                    'placeholder' => 'Enter your email address',
                    'required' => true,
                    'width' => 100,
                ],
                [
                    'type' => 'textarea',
                    'name' => 'message',
                    'label' => 'Message',
                    'placeholder' => 'Write your message here...',
                    'required' => true,
                    'width' => 100,
                ],
                [
                    'type' => 'button',
                    'name' => 'submit',
                    'buttonType' => 'submit',
                    'buttonText' => 'Send Message',
                    'buttonClass' => 'btn-primary',
                    'width' => 100,
                ],
            ],
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('custom_form_submissions');
        Schema::dropIfExists('custom_forms');
    }
};
