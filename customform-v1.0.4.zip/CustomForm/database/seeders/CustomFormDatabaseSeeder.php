<?php

namespace Modules\CustomForm\database\seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class CustomFormDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Permission List as array.
        $permissions = [
            [
                'group_name' => 'custom_form',
                'permissions' => [
                    'custom_form.view',
                    'custom_form.create',
                    'custom_form.edit',
                    'custom_form.delete',
                ],
            ],
        ];

        $roleSuperAdmin = Role::firstOrCreate(['name' => 'Superadmin']);

        for ($i = 0; $i < count($permissions); $i++) {
            $permissionGroup = $permissions[$i]['group_name'];
            for ($j = 0; $j < count($permissions[$i]['permissions']); $j++) {
                $permissionExist = Permission::where('name', $permissions[$i]['permissions'][$j])->first();
                if (is_null($permissionExist)) {
                    $permission = Permission::create(
                        [
                            'name' => $permissions[$i]['permissions'][$j],
                            'group_name' => $permissionGroup,
                            'guard_name' => 'web',
                        ]
                    );
                    $roleSuperAdmin->givePermissionTo($permission->name);
                    $permission->assignRole($roleSuperAdmin);
                }
            }
        }
    }
}
