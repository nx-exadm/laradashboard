Create beautiful, functional forms in minutes. Custom Form module provides an intuitive drag-and-drop builder to design contact forms, surveys, feedback forms, and more — no coding required.

## Key Features

**Form Builder**
- Drag-and-drop interface for easy form creation
- Multiple field types: text, email, textarea, select, radio, checkbox, and buttons
- Flexible column layouts with customizable field widths
- Required field validation

**Submissions Management**
- View and manage all form submissions in one place
- Track submission details: IP address, user agent, timestamp
- Filter and search through responses

**Embed Anywhere**
- Embed forms on any page using shortcodes
- Standalone form pages with shareable URLs
- Seamless integration with your site's design

**Ready to Use**
- Pre-built "Contact Us" form template included
- Dark mode support
- Mobile-responsive design

## Permissions

- `custom_form.view` - View forms and submissions
- `custom_form.create` - Create new forms
- `custom_form.edit` - Edit existing forms
- `custom_form.delete` - Delete forms
