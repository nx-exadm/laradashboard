/**
 * Custom Form Embed Block Property Editor
 *
 * Custom property editor for the Custom Form Embed block.
 * Allows selecting a form and configuring display options.
 */

// Import React from shim (resolves to window.React via alias)
import React from "react";

const CustomFormEmbedPropertyEditor = ({ props, onUpdate }) => {
  // Destructure hooks inside the function to ensure React is available
  const { useState, useEffect } = React;

  const [forms, setForms] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch forms on mount
  useEffect(() => {
    fetchForms();
  }, []);

  const fetchForms = async (search = "") => {
    setLoading(true);
    try {
      const url = search
        ? `/api/customform/forms?search=${encodeURIComponent(search)}&limit=50`
        : "/api/customform/forms?limit=50";
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        // API already filters active forms
        setForms(data.data || data || []);
      }
    } catch (err) {
      console.error("Failed to fetch forms:", err);
    } finally {
      setLoading(false);
    }
  };

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      fetchForms(searchQuery);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const handleChange = (field, value) => {
    onUpdate({ ...props, [field]: value });
  };

  const sectionStyle = {
    marginBottom: "16px",
    paddingBottom: "16px",
    borderBottom: "1px solid #e5e7eb",
  };

  const labelStyle = {
    display: "block",
    fontSize: "13px",
    fontWeight: "500",
    color: "#374151",
    marginBottom: "6px",
  };

  const sectionTitleStyle = {
    fontSize: "12px",
    fontWeight: "600",
    color: "#6b7280",
    textTransform: "uppercase",
    letterSpacing: "0.5px",
    marginBottom: "12px",
  };

  const checkboxLabelStyle = {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    fontSize: "13px",
    color: "#374151",
    cursor: "pointer",
    marginBottom: "8px",
  };

  return (
    <div>
      {/* Form Selection */}
      <div style={sectionStyle}>
        <div style={sectionTitleStyle}>Form Selection</div>

        <label style={labelStyle}>Search Form</label>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by title..."
          className="form-control mb-2"
        />

        <label style={labelStyle}>Select Form</label>
        <select
          value={props.formId || ""}
          onChange={(e) =>
            handleChange(
              "formId",
              e.target.value ? parseInt(e.target.value) : null
            )
          }
          className="form-control"
          disabled={loading}
        >
          <option value="">-- Select a form --</option>
          {forms.map((form) => (
            <option key={form.id} value={form.id}>
              {form.title}
              {form.form_schema ? ` (${form.form_schema.length} fields)` : ""}
            </option>
          ))}
        </select>
        {loading && (
          <span style={{ fontSize: "12px", color: "#6b7280" }}>Loading...</span>
        )}
      </div>

      {/* Display Options */}
      <div style={sectionStyle}>
        <div style={sectionTitleStyle}>Display Options</div>

        <label style={checkboxLabelStyle}>
          <input
            type="checkbox"
            checked={props.showTitle !== false}
            onChange={(e) => handleChange("showTitle", e.target.checked)}
          />
          Show Form Title
        </label>

        <label style={checkboxLabelStyle}>
          <input
            type="checkbox"
            checked={props.showDescription !== false}
            onChange={(e) => handleChange("showDescription", e.target.checked)}
          />
          Show Description
        </label>
      </div>

      {/* Layout Options */}
      <div style={sectionStyle}>
        <div style={sectionTitleStyle}>Layout</div>

        <label style={labelStyle}>Border Radius</label>
        <select
          value={props.borderRadius || "8px"}
          onChange={(e) => handleChange("borderRadius", e.target.value)}
          className="form-control mb-3"
        >
          <option value="0">None</option>
          <option value="4px">Small (4px)</option>
          <option value="8px">Medium (8px)</option>
          <option value="12px">Large (12px)</option>
          <option value="16px">X-Large (16px)</option>
        </select>

        <label style={labelStyle}>Title Font Size</label>
        <select
          value={props.titleFontSize || "18px"}
          onChange={(e) => handleChange("titleFontSize", e.target.value)}
          className="form-control"
        >
          <option value="16px">Small (16px)</option>
          <option value="18px">Medium (18px)</option>
          <option value="20px">Large (20px)</option>
          <option value="24px">X-Large (24px)</option>
        </select>
      </div>

      {/* Colors */}
      <div style={{ marginBottom: "16px" }}>
        <div style={sectionTitleStyle}>Colors</div>

        <label style={labelStyle}>Background Color</label>
        <input
          type="color"
          value={props.backgroundColor || "#ffffff"}
          onChange={(e) => handleChange("backgroundColor", e.target.value)}
          className="form-control mb-2"
          style={{ height: "36px", padding: "4px" }}
        />

        <label style={labelStyle}>Border Color</label>
        <input
          type="color"
          value={props.borderColor || "#e5e7eb"}
          onChange={(e) => handleChange("borderColor", e.target.value)}
          className="form-control mb-2"
          style={{ height: "36px", padding: "4px" }}
        />

        <label style={labelStyle}>Title Color</label>
        <input
          type="color"
          value={props.titleColor || "#1f2937"}
          onChange={(e) => handleChange("titleColor", e.target.value)}
          className="form-control mb-2"
          style={{ height: "36px", padding: "4px" }}
        />

        <label style={labelStyle}>Label Color</label>
        <input
          type="color"
          value={props.labelColor || "#374151"}
          onChange={(e) => handleChange("labelColor", e.target.value)}
          className="form-control mb-2"
          style={{ height: "36px", padding: "4px" }}
        />

        <label style={labelStyle}>Input Border Color</label>
        <input
          type="color"
          value={props.inputBorderColor || "#d1d5db"}
          onChange={(e) => handleChange("inputBorderColor", e.target.value)}
          className="form-control mb-2"
          style={{ height: "36px", padding: "4px" }}
        />

        <label style={labelStyle}>Button Color</label>
        <input
          type="color"
          value={props.buttonColor || "#3b82f6"}
          onChange={(e) => handleChange("buttonColor", e.target.value)}
          className="form-control mb-2"
          style={{ height: "36px", padding: "4px" }}
        />

        <label style={labelStyle}>Button Text Color</label>
        <input
          type="color"
          value={props.buttonTextColor || "#ffffff"}
          onChange={(e) => handleChange("buttonTextColor", e.target.value)}
          className="form-control"
          style={{ height: "36px", padding: "4px" }}
        />
      </div>
    </div>
  );
};

export default CustomFormEmbedPropertyEditor;
