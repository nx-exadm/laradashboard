/**
 * Custom Form Embed Block Registration
 *
 * Block file structure:
 * - index.js    : Main entry point, block definition and registration
 * - block.json  : Block metadata and configuration
 * - block.jsx   : React component for rendering in the builder canvas
 * - editor.jsx  : React component for the properties panel editor
 * - save.js     : HTML generators for different contexts (email, page, campaign)
 * - render.php  : Server-side rendering (takes priority over save.js when rendering pages)
 *
 * Usage:
 * Import this file in your app.js or wherever LaraBuilder is initialized:
 *
 *   import './lara-builder-blocks/customform-embed';
 *
 * Or dynamically:
 *   import('./lara-builder-blocks/customform-embed');
 */

import block from './block';
import editor from './editor';
import config from './block.json';
import save from './save';

// Default layout styles (matching core block structure)
const defaultLayoutStyles = {
    margin: { top: '', right: '', bottom: '', left: '' },
    padding: { top: '', right: '', bottom: '', left: '' },
    width: '',
    minWidth: '',
    maxWidth: '',
    height: '',
    minHeight: '',
    maxHeight: '',
};

// Block definition - combines config from block.json with components
const customformEmbedBlockDefinition = {
    // Spread all config from block.json (type, label, category, icon, etc.)
    ...config,

    // React component for rendering in the builder canvas
    block,

    // React component for the properties panel editor
    editor,

    // HTML generators for different output contexts (from save.js)
    // Server-side rendering via render.php takes priority when rendering pages
    save,

    // Merge defaultProps with layoutStyles
    defaultProps: {
        ...config.defaultProps,
        layoutStyles: { ...defaultLayoutStyles },
    },
};

/**
 * Register the block with LaraBuilder
 * Uses the global blockRegistry exposed by LaraBuilder core
 */
function registerCustomFormEmbedBlock() {
    // Check if LaraBuilder registry is available
    if (typeof window !== 'undefined' && window.LaraBuilderBlockRegistry) {
        window.LaraBuilderBlockRegistry.register(customformEmbedBlockDefinition);
        return true;
    }

    // If not available yet, wait for it
    if (typeof window !== 'undefined') {
        // Try again after a short delay (LaraBuilder might not be loaded yet)
        const checkInterval = setInterval(() => {
            if (window.LaraBuilderBlockRegistry) {
                window.LaraBuilderBlockRegistry.register(customformEmbedBlockDefinition);
                clearInterval(checkInterval);
            }
        }, 100);

        // Stop checking after 10 seconds
        setTimeout(() => clearInterval(checkInterval), 10000);
    }

    return false;
}

// Auto-register when this module is imported
registerCustomFormEmbedBlock();

// Export for manual registration if needed
export { customformEmbedBlockDefinition, registerCustomFormEmbedBlock };
export default customformEmbedBlockDefinition;
