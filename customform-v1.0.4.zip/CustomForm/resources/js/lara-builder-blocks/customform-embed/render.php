<?php

declare(strict_types=1);

/**
 * Custom Form Embed Block - Server-Side Render
 *
 * This file handles server-side rendering of the Custom Form Embed block.
 * It renders the Livewire form-submission component for the selected form.
 *
 * Available variables:
 * - $props: array - Block properties from the editor
 * - $context: string - Rendering context ('email', 'page', 'campaign')
 * - $blockId: string - Unique block identifier
 *
 * @return string HTML output
 */

use Modules\CustomForm\Models\CustomForm;

/**
 * Render the Custom Form Embed block
 */
return function (array $props, string $context = 'page', ?string $blockId = null): string {
    $formId = $props['formId'] ?? null;

    // Style properties with defaults
    $backgroundColor = $props['backgroundColor'] ?? '#ffffff';
    $borderColor = $props['borderColor'] ?? '#e5e7eb';
    $borderRadius = $props['borderRadius'] ?? '8px';
    $titleColor = $props['titleColor'] ?? '#1f2937';
    $titleFontSize = $props['titleFontSize'] ?? '18px';

    // Display options
    $showTitle = $props['showTitle'] ?? true;
    $showDescription = $props['showDescription'] ?? true;

    // No form selected
    if (! $formId) {
        return sprintf(
            '<div style="padding: 24px; border: 1px solid %s; border-radius: %s; background-color: %s; text-align: center;">
                <p style="color: #6b7280; margin: 0;">Form not selected</p>
            </div>',
            e($borderColor),
            e($borderRadius),
            e($backgroundColor)
        );
    }

    // For email context, forms can't work - show a message
    if ($context === 'email' || $context === 'campaign') {
        try {
            $form = CustomForm::find($formId);
            $formTitle = $form ? $form->title : 'Form';
        } catch (\Exception $e) {
            $formTitle = 'Form';
        }

        return sprintf(
            '<table width="100%%" cellpadding="0" cellspacing="0" border="0">
                <tr>
                    <td style="padding: 20px; border: 1px solid %s; border-radius: %s; background-color: %s;">
                        <p style="margin: 0 0 8px 0; font-size: %s; font-weight: 600; color: %s;">%s</p>
                        <p style="margin: 0; font-size: 14px; color: #6b7280;">This form is available on our website. Click the link below to fill it out.</p>
                    </td>
                </tr>
            </table>',
            e($borderColor),
            e($borderRadius),
            e($backgroundColor),
            e($titleFontSize),
            e($titleColor),
            e($formTitle)
        );
    }

    // Fetch form to verify it exists and is active
    try {
        $form = CustomForm::find($formId);
    } catch (\Exception $e) {
        $form = null;
    }

    if (! $form) {
        return sprintf(
            '<div style="padding: 24px; border: 1px solid %s; border-radius: %s; background-color: %s; text-align: center;">
                <p style="color: #6b7280; margin: 0;">Form not found</p>
            </div>',
            e($borderColor),
            e($borderRadius),
            e($backgroundColor)
        );
    }

    // Check if form is active
    if ($form->status !== 'active') {
        return sprintf(
            '<div style="padding: 24px; border: 1px solid %s; border-radius: %s; background-color: %s; text-align: center;">
                <p style="color: #6b7280; margin: 0;">This form is currently unavailable</p>
            </div>',
            e($borderColor),
            e($borderRadius),
            e($backgroundColor)
        );
    }

    // Build custom styles to pass to the component
    $customStyles = [
        'backgroundColor' => $backgroundColor,
        'borderColor' => $borderColor,
        'borderRadius' => $borderRadius,
        'titleColor' => $titleColor,
        'titleFontSize' => $titleFontSize,
        'showTitle' => $showTitle,
        'showDescription' => $showDescription,
        'labelColor' => $props['labelColor'] ?? '#374151',
        'inputBorderColor' => $props['inputBorderColor'] ?? '#d1d5db',
        'buttonColor' => $props['buttonColor'] ?? '#3b82f6',
        'buttonTextColor' => $props['buttonTextColor'] ?? '#ffffff',
    ];

    // Render the Livewire component
    // In Livewire 3, mount() returns HTML string directly
    $livewireHtml = \Livewire\Livewire::mount('customform::components.form-submission', [
        'id' => $formId,
    ]);

    // Wrap with custom styling container
    $wrapperStyle = sprintf(
        'padding: 0; border-radius: %s; background-color: %s; overflow: hidden;',
        e($borderColor),
        e($borderRadius),
        e($backgroundColor)
    );

    // Add custom CSS variables for styling
    $cssVars = sprintf(
        '--cf-bg-color: %s; --cf-border-color: %s; --cf-title-color: %s; --cf-title-font-size: %s; --cf-label-color: %s; --cf-input-border-color: %s; --cf-button-color: %s; --cf-button-text-color: %s;',
        e($backgroundColor),
        e($borderColor),
        e($titleColor),
        e($titleFontSize),
        e($props['labelColor'] ?? '#374151'),
        e($props['inputBorderColor'] ?? '#d1d5db'),
        e($props['buttonColor'] ?? '#3b82f6'),
        e($props['buttonTextColor'] ?? '#ffffff')
    );

    // Get the CSS file URL from Vite manifest
    $cssUrl = '';
    $manifestPath = public_path('build-customform/manifest.json');
    if (file_exists($manifestPath)) {
        $manifest = json_decode(file_get_contents($manifestPath), true);
        $cssKey = 'modules/customform/resources/assets/css/app.css';
        if (isset($manifest[$cssKey]['file'])) {
            $cssUrl = asset('build-customform/' . $manifest[$cssKey]['file']);
        }
    }

    // Build the CSS loader script (loads CSS once, prevents duplicates)
    $cssLoader = '';
    if ($cssUrl) {
        $cssLoader = sprintf(
            '<script>
                (function() {
                    var cssId = "customform-embed-css";
                    if (!document.getElementById(cssId)) {
                        var link = document.createElement("link");
                        link.id = cssId;
                        link.rel = "stylesheet";
                        link.href = "%s";
                        document.head.appendChild(link);
                    }
                })();
            </script>',
            e($cssUrl)
        );
    }

    return sprintf(
        '%s<div class="customform-embed-block" style="%s %s" data-form-id="%d">%s</div>',
        $cssLoader,
        $wrapperStyle,
        $cssVars,
        $formId,
        $livewireHtml
    );
};
