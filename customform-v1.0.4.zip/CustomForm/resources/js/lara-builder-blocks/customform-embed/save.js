/**
 * Custom Form Embed Block - HTML Generators
 *
 * This block is fully server-rendered via render.php.
 * save.js only outputs a minimal placeholder with data-lara-block attribute
 * that BlockRenderer will replace with server-rendered Livewire component.
 */

/**
 * Generate placeholder for server-side rendering (page context)
 *
 * @param {Object} props - Block properties
 * @returns {string} HTML string placeholder
 */
export function generateHtml(props) {
    const {
        formId,
        backgroundColor = '#ffffff',
        borderColor = '#e5e7eb',
        borderRadius = '8px',
        showTitle = true,
        showDescription = true,
        titleColor = '#1f2937',
        titleFontSize = '18px',
        labelColor = '#374151',
        inputBorderColor = '#d1d5db',
        buttonColor = '#3b82f6',
        buttonTextColor = '#ffffff',
    } = props;

    // No form selected - return static message (no server-side processing needed)
    if (!formId) {
        return `<div style="padding: 24px; border: 1px solid ${borderColor}; border-radius: ${borderRadius}; background-color: ${backgroundColor}; text-align: center;"><p style="color: #6b7280; margin: 0;">Form not selected</p></div>`;
    }

    // Props for server-side rendering
    const serverProps = {
        formId,
        backgroundColor,
        borderColor,
        borderRadius,
        showTitle,
        showDescription,
        titleColor,
        titleFontSize,
        labelColor,
        inputBorderColor,
        buttonColor,
        buttonTextColor,
    };

    // Escape for HTML attribute (single quotes wrap, JSON uses double quotes)
    const propsJson = JSON.stringify(serverProps).replace(/'/g, '&#39;');

    // Minimal placeholder - will be fully replaced by render.php
    return `<div data-lara-block="customform-embed" data-props='${propsJson}'></div>`;
}

/**
 * Generate placeholder for server-side rendering (email/campaign context)
 * Forms can't work in emails, but render.php handles this gracefully
 */
export function generateEmailHtml(props) {
    const {
        formId,
        backgroundColor = '#ffffff',
        borderColor = '#e5e7eb',
        borderRadius = '8px',
        titleFontSize = '18px',
        titleColor = '#1f2937',
    } = props;

    if (!formId) {
        return `<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding: 24px; border: 1px solid ${borderColor}; border-radius: ${borderRadius}; background-color: ${backgroundColor}; text-align: center;"><p style="color: #6b7280; margin: 0; font-size: 14px;">Form not available in email</p></td></tr></table>`;
    }

    // Props for server-side rendering
    const serverProps = {
        formId,
        backgroundColor,
        borderColor,
        borderRadius,
        titleFontSize,
        titleColor,
    };

    // Escape for HTML attribute (single quotes wrap, JSON uses double quotes)
    const propsJson = JSON.stringify(serverProps).replace(/'/g, '&#39;');

    // Minimal placeholder - will be fully replaced by render.php
    return `<div data-lara-block="customform-embed" data-props='${propsJson}'></div>`;
}

/**
 * HTML generators for different contexts
 */
const save = {
    page: generateHtml,
    email: generateEmailHtml,
    campaign: generateEmailHtml,
};

export { save };
export default save;
