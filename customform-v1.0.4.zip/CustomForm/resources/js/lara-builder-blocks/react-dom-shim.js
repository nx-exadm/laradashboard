/**
 * ReactDOM Shim for LaraBuilder Blocks
 *
 * This shim re-exports ReactDOM from window.ReactDOM, ensuring that
 * module blocks use the same ReactDOM instance as the main app.
 */

// Get ReactDOM lazily to handle loading order
const getReactDOM = () => {
    if (!window.ReactDOM) {
        throw new Error('[CustomForm Block] window.ReactDOM is not available. Make sure the main app loads before module blocks.');
    }
    return window.ReactDOM;
};

// Common exports
export const createPortal = (...args) => getReactDOM().createPortal(...args);
export const flushSync = (...args) => getReactDOM().flushSync(...args);
export const render = (...args) => getReactDOM().render(...args);
export const hydrate = (...args) => getReactDOM().hydrate(...args);
export const unmountComponentAtNode = (...args) => getReactDOM().unmountComponentAtNode(...args);
export const findDOMNode = (...args) => getReactDOM().findDOMNode(...args);

// React 18+ client API
export const createRoot = (...args) => getReactDOM().createRoot(...args);
export const hydrateRoot = (...args) => getReactDOM().hydrateRoot(...args);

// Default export - Proxy that delegates all property access to window.ReactDOM
export default new Proxy({}, {
    get(target, prop) {
        if (!window.ReactDOM) {
            throw new Error('[CustomForm Block] window.ReactDOM is not available. Make sure the main app loads before module blocks.');
        }
        return window.ReactDOM[prop];
    }
});
