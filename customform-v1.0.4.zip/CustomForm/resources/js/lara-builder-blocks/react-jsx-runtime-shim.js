/**
 * React JSX Runtime Shim for LaraBuilder Blocks
 *
 * This shim provides JSX runtime functions using window.React.
 */

const getReact = () => {
    if (!window.React) {
        throw new Error('[CustomForm Block] window.React is not available.');
    }
    return window.React;
};

export const jsx = (type, props, key) => {
    const React = getReact();
    return React.createElement(type, { ...props, key });
};

export const jsxs = jsx;

export const Fragment = Symbol.for('react.fragment');
