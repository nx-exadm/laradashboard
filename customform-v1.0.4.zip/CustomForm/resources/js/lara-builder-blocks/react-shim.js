/**
 * React Shim for LaraBuilder Blocks
 *
 * This shim re-exports React from window.React, ensuring that
 * module blocks use the same React instance as the main app.
 * This prevents the "multiple React instances" error.
 */

// Get React lazily to handle loading order
const getReact = () => {
    if (!window.React) {
        throw new Error('[CustomForm Block] window.React is not available. Make sure the main app loads before module blocks.');
    }
    return window.React;
};

// Create proxy functions for hooks that get React at call time
export const useState = (...args) => getReact().useState(...args);
export const useEffect = (...args) => getReact().useEffect(...args);
export const useCallback = (...args) => getReact().useCallback(...args);
export const useContext = (...args) => getReact().useContext(...args);
export const useDebugValue = (...args) => getReact().useDebugValue(...args);
export const useDeferredValue = (...args) => getReact().useDeferredValue(...args);
export const useId = (...args) => getReact().useId(...args);
export const useImperativeHandle = (...args) => getReact().useImperativeHandle(...args);
export const useInsertionEffect = (...args) => getReact().useInsertionEffect(...args);
export const useLayoutEffect = (...args) => getReact().useLayoutEffect(...args);
export const useMemo = (...args) => getReact().useMemo(...args);
export const useReducer = (...args) => getReact().useReducer(...args);
export const useRef = (...args) => getReact().useRef(...args);
export const useSyncExternalStore = (...args) => getReact().useSyncExternalStore(...args);
export const useTransition = (...args) => getReact().useTransition(...args);

// Static exports
export const Fragment = Symbol.for('react.fragment');
export const createElement = (...args) => getReact().createElement(...args);
export const createContext = (...args) => getReact().createContext(...args);
export const createRef = (...args) => getReact().createRef(...args);
export const forwardRef = (...args) => getReact().forwardRef(...args);
export const memo = (...args) => getReact().memo(...args);
export const lazy = (...args) => getReact().lazy(...args);
export const cloneElement = (...args) => getReact().cloneElement(...args);
export const isValidElement = (...args) => getReact().isValidElement(...args);
export const Children = { map: (...args) => getReact().Children.map(...args) };

// Default export - Proxy that delegates all property access to window.React
export default new Proxy({}, {
    get(target, prop) {
        if (!window.React) {
            throw new Error('[CustomForm Block] window.React is not available. Make sure the main app loads before module blocks.');
        }
        return window.React[prop];
    }
});
