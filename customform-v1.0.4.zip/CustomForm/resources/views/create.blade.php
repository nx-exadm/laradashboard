@extends('backend.layouts.app')

@section('title')
    {{ $breadcrumbs['title'] }} | {{ config('app.name') }}
@endsection

@push('styles')
    @vite(['modules/customform/resources/assets/css/app.css'], 'build-customform')
@endpush

@section('admin-content')

<div class="p-4 mx-auto max-w-(--breakpoint-2xl) md:p-6">
   <x-breadcrumbs :breadcrumbs="$breadcrumbs" />

    {!! ld_apply_filters('custom_forms_after_breadcrumbs', '') !!}

    <div class="space-y-6">
        <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
            <div class="p-5 space-y-6 border-t border-gray-100 dark:border-gray-800 sm:p-6">
                @include('customform::partials.form', [
                    'action' => route('admin.custom-forms.store'),
                    'method' => 'POST',
                    'form' => null,
                ])
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    document.addEventListener('alpine:init', () => {
        Alpine.data('formBuilder', () => ({
            formSchema: [],
            selectedField: null,
            isDraggingOver: false,
            draggedFieldIndex: null,
            draggedFieldType: null,
            fieldTypes: [
                { id: 'text', label: 'Text Input', icon: 'lucide:type' },
                { id: 'number', label: 'Number Input', icon: 'lucide:hash' },
                { id: 'email', label: 'Email Input', icon: 'lucide:mail' },
                { id: 'textarea', label: 'Textarea', icon: 'lucide:align-left' },
                { id: 'select', label: 'Select Dropdown', icon: 'lucide:list' },
                { id: 'radio', label: 'Radio Buttons', icon: 'lucide:circle-dot' },
                { id: 'checkbox', label: 'Checkbox', icon: 'lucide:check-square' },
                { id: 'button', label: 'Button', icon: 'lucide:square' },
            ],

            init() {
                this.formSchema = [];
            },

            // Drag from sidebar
            dragStart(event, type) {
                this.draggedFieldType = type;
                this.draggedFieldIndex = null;
                event.dataTransfer.effectAllowed = 'copy';
                event.dataTransfer.setData('text/plain', type);
            },

            // Drag existing field
            dragFieldStart(event, index) {
                this.draggedFieldIndex = index;
                this.draggedFieldType = null;
                event.dataTransfer.effectAllowed = 'move';
                event.dataTransfer.setData('text/plain', index.toString());
                event.target.classList.add('opacity-50');
            },

            dragFieldEnd() {
                this.draggedFieldIndex = null;
                this.isDraggingOver = false;
                document.querySelectorAll('.opacity-50').forEach(el => el.classList.remove('opacity-50'));
            },

            dragFieldOver(event, targetIndex) {
                if (this.draggedFieldIndex !== null && this.draggedFieldIndex !== targetIndex) {
                    const draggedField = this.formSchema[this.draggedFieldIndex];
                    this.formSchema.splice(this.draggedFieldIndex, 1);
                    this.formSchema.splice(targetIndex, 0, draggedField);
                    this.draggedFieldIndex = targetIndex;
                    if (this.selectedField === this.draggedFieldIndex) {
                        this.selectedField = targetIndex;
                    }
                    this.updateFormSchema();
                }
            },

            handleDrop(event) {
                this.isDraggingOver = false;
                if (this.draggedFieldType) {
                    this.addField(this.draggedFieldType);
                }
                this.draggedFieldType = null;
                this.draggedFieldIndex = null;
            },

            addField(type) {
                const newField = this.createField(type);
                this.formSchema.push(newField);
                this.selectedField = this.formSchema.length - 1;
                this.updateFormSchema();
            },

            createField(type) {
                const baseField = {
                    type: type,
                    name: `field_${Date.now()}`,
                    label: this.getDefaultLabel(type),
                    placeholder: '',
                    required: false,
                    validations: '',
                    width: '100',
                };

                if (type === 'select' || type === 'radio' || type === 'checkbox') {
                    baseField.options = [
                        { value: 'option1', label: 'Option 1' },
                        { value: 'option2', label: 'Option 2' }
                    ];
                }

                if (type === 'button') {
                    baseField.buttonText = 'Submit';
                    baseField.buttonType = 'submit';
                    baseField.buttonClass = 'btn-primary';
                }

                return baseField;
            },

            getDefaultLabel(type) {
                const labels = {
                    text: 'Text Field',
                    number: 'Number Field',
                    email: 'Email Field',
                    textarea: 'Text Area',
                    select: 'Select Field',
                    radio: 'Radio Field',
                    checkbox: 'Checkbox Field',
                    button: 'Button'
                };

                return labels[type] || 'New Field';
            },

            getFieldIcon(type) {
                const field = this.fieldTypes.find(f => f.id === type);
                return field ? field.icon : 'lucide:help-circle';
            },

            getFieldTypeLabel(type) {
                const field = this.fieldTypes.find(f => f.id === type);
                return field ? field.label : 'Unknown';
            },

            removeField(index) {
                this.formSchema.splice(index, 1);
                if (this.selectedField === index) {
                    this.selectedField = null;
                } else if (this.selectedField > index) {
                    this.selectedField--;
                }
                this.updateFormSchema();
            },

            duplicateField(index) {
                const original = this.formSchema[index];
                const duplicate = JSON.parse(JSON.stringify(original));
                duplicate.name = `field_${Date.now()}`;
                duplicate.label = original.label + ' (Copy)';
                this.formSchema.splice(index + 1, 0, duplicate);
                this.selectedField = index + 1;
                this.updateFormSchema();
            },

            updateFormSchema() {
                this.$nextTick(() => {
                    document.getElementById('form-schema').value = JSON.stringify(this.formSchema);
                });
            },

            selectField(index) {
                this.selectedField = index;
            },

            updateField() {
                this.updateFormSchema();
            },

            addOption(fieldIndex) {
                if (!this.formSchema[fieldIndex].options) {
                    this.formSchema[fieldIndex].options = [];
                }

                this.formSchema[fieldIndex].options.push({
                    value: `option${this.formSchema[fieldIndex].options.length + 1}`,
                    label: `Option ${this.formSchema[fieldIndex].options.length + 1}`
                });

                this.updateField();
            },

            removeOption(fieldIndex, optionIndex) {
                this.formSchema[fieldIndex].options.splice(optionIndex, 1);
                this.updateField();
            },

            moveUp(index) {
                if (index > 0) {
                    const temp = this.formSchema[index];
                    this.formSchema[index] = this.formSchema[index - 1];
                    this.formSchema[index - 1] = temp;
                    this.selectedField = index - 1;
                    this.updateField();
                }
            },

            moveDown(index) {
                if (index < this.formSchema.length - 1) {
                    const temp = this.formSchema[index];
                    this.formSchema[index] = this.formSchema[index + 1];
                    this.formSchema[index + 1] = temp;
                    this.selectedField = index + 1;
                    this.updateField();
                }
            }
        }));
    });
</script>
@endpush
