<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ $form->title ?? __('Form') }} | {{ config('app.name') }}</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=inter:400,500,600,700&display=swap" rel="stylesheet" />

    <!-- Module CSS with cf: prefix -->
    @vite(['modules/customform/resources/assets/css/app.css'], 'build-customform')

    @livewireStyles
</head>
<body class="cf:antialiased cf:min-h-screen cf:bg-gradient-to-br cf:from-gray-50 cf:to-gray-100 cf:dark:from-gray-900 cf:dark:to-gray-800">
    <div class="cf:py-12 cf:px-4">
        <!-- Livewire Form Component -->
        @livewire('customform::components.form-submission', ['id' => $form->id])

        <!-- Powered By -->
        <div class="cf:mt-8 cf:text-center">
            <p class="cf:text-xs cf:text-gray-400 cf:dark:text-gray-500">
                {{ __('Powered by') }}
                <a href="{{ config('app.url') }}" target="_blank" class="cf:text-gray-500 cf:dark:text-gray-400 cf:hover:underline">{{ config('app.name') }}</a>
            </p>
        </div>
    </div>

    @livewireScripts
</body>
</html>
