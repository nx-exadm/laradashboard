@extends('backend.layouts.app')

@section('title')
   {{ $breadcrumbs['title'] }} | {{ config('app.name') }}
@endsection

@section('admin-content')

<div class="p-4 mx-auto max-w-(--breakpoint-2xl) md:p-6">
    <x-breadcrumbs :breadcrumbs="$breadcrumbs" />

    {!! ld_apply_filters('custom_forms_after_breadcrumbs', '') !!}

    <div class="space-y-6">
        <livewire:customform::components.form-datatable lazy />
    </div>
</div>
@endsection
