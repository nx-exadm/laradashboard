@once
    @if(file_exists(public_path('build-customform/manifest.json')))
        @push('styles')
            @vite(['modules/customform/resources/assets/css/app.css'], 'build-customform')
        @endpush
    @endif
@endonce

<div class="cf:max-w-2xl cf:mx-auto">
    @if(!$form)
        {{-- Form not found - render nothing or a subtle placeholder --}}
        <div class="cf:text-center cf:py-8 cf:text-gray-400 cf:dark:text-gray-600">
            {{-- Optionally show a message in development --}}
            @if(config('app.debug'))
                <p class="cf:text-sm">{{ __('Form not found: :slug', ['slug' => $slug ?? 'unknown']) }}</p>
            @endif
        </div>
    @else
    <div class="cf:bg-white cf:dark:bg-gray-900 cf:rounded-xl cf:shadow-sm cf:border cf:border-gray-200 cf:dark:border-gray-700 cf:overflow-hidden">
        <!-- Form Header -->
        <div class="cf:px-6 cf:py-4 cf:border-b cf:border-gray-200 cf:dark:border-gray-700 cf:bg-gray-50 cf:dark:bg-gray-800">
            <h3 class="cf:text-lg cf:font-semibold cf:text-gray-900 cf:dark:text-white">{{ $form->title ?? __('Form') }}</h3>
            @if($form->description)
                <p class="cf:mt-1 cf:text-sm cf:text-gray-500 cf:dark:text-gray-400">{{ $form->description }}</p>
            @endif
        </div>

        <div class="cf:p-6">
            <!-- Success Message -->
            @if ($success)
                <div class="cf:mb-6 cf:p-4 cf:bg-green-50 cf:dark:bg-green-900/20 cf:border cf:border-green-200 cf:dark:border-green-800 cf:rounded-lg cf:flex cf:items-start cf:gap-3">
                    <svg class="cf:w-5 cf:h-5 cf:text-green-500 cf:shrink-0 cf:mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                    </svg>
                    <div>
                        <p class="cf:font-medium cf:text-green-800 cf:dark:text-green-200">{{ __('Success!') }}</p>
                        <p class="cf:text-sm cf:text-green-700 cf:dark:text-green-300">{{ __('Your submission was successful. Thank you!') }}</p>
                    </div>
                </div>
            @endif

            <!-- Error Message -->
            @if ($errorMessage)
                <div class="cf:mb-6 cf:p-4 cf:bg-red-50 cf:dark:bg-red-900/20 cf:border cf:border-red-200 cf:dark:border-red-800 cf:rounded-lg cf:flex cf:items-start cf:gap-3">
                    <svg class="cf:w-5 cf:h-5 cf:text-red-500 cf:shrink-0 cf:mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                    </svg>
                    <p class="cf:text-sm cf:text-red-700 cf:dark:text-red-300">{{ $errorMessage }}</p>
                </div>
            @endif

            <form wire:submit.prevent="submit" class="cf:flex cf:flex-wrap cf:gap-5">
                @foreach ($fields as $field)
                    @php
                        $fieldType = $field['type'] ?? 'text';
                        $fieldName = $field['name'];
                        $fieldLabel = $field['label'] ?? ucfirst($fieldName);
                        $placeholder = $field['placeholder'] ?? '';
                        $required = $field['required'] ?? false;
                        $options = $field['options'] ?? [];
                        $fieldWidth = $field['width'] ?? '100';
                        $widthStyle = $fieldWidth < 100 ? "width: calc({$fieldWidth}% - 0.625rem);" : "width: 100%;";
                    @endphp

                    @if ($fieldType === 'button')
                        {{-- Button Field --}}
                        @php
                            $buttonClass = $field['buttonClass'] ?? 'btn-primary';
                            $isCustom = $buttonClass === 'btn-custom';
                            $isPrimary = $buttonClass === 'btn-primary';
                            $buttonBgColor = $field['buttonBgColor'] ?? '#635bff';
                            $buttonTextColor = $field['buttonTextColor'] ?? '#ffffff';
                        @endphp
                        <div class="cf:pt-2" style="{{ $widthStyle }}">
                            <button
                                type="{{ $field['buttonType'] ?? 'submit' }}"
                                class="cf:inline-flex cf:items-center cf:justify-center cf:gap-2 cf:px-6 cf:py-2.5 cf:rounded-lg cf:font-medium cf:text-sm cf:transition-all cf:cursor-pointer cf:focus:outline-none cf:focus:ring-2 cf:focus:ring-offset-2 cf:dark:focus:ring-offset-gray-900 cf:disabled:opacity-50 cf:disabled:cursor-not-allowed
                                    @if(!$isCustom && !$isPrimary)
                                        @if($buttonClass === 'btn-secondary')
                                            cf:bg-gray-200 cf:hover:bg-gray-300 cf:dark:bg-gray-700 cf:dark:hover:bg-gray-600 cf:text-gray-800 cf:dark:text-gray-200 cf:focus:ring-gray-400
                                        @elseif($buttonClass === 'btn-success')
                                            cf:bg-green-600 cf:hover:bg-green-700 cf:text-white cf:focus:ring-green-500
                                        @elseif($buttonClass === 'btn-danger')
                                            cf:bg-red-600 cf:hover:bg-red-700 cf:text-white cf:focus:ring-red-500
                                        @endif
                                    @endif
                                    @if($isPrimary) cf:text-white cf:hover:brightness-110 @endif
                                    @if($isCustom) cf:hover:brightness-110 @endif
                                "
                                @if($isCustom)
                                    style="background-color: {{ $buttonBgColor }}; color: {{ $buttonTextColor }}; --tw-ring-color: {{ $buttonBgColor }}80;"
                                @elseif($isPrimary)
                                    style="background-color: var(--color-primary, #635bff); --tw-ring-color: var(--color-primary, #635bff);"
                                @endif
                                wire:loading.attr="disabled"
                                wire:loading.class="cf:opacity-75 cf:cursor-wait"
                            >
                                <svg wire:loading wire:target="submit" class="cf:animate-spin cf:h-4 cf:w-4" fill="none" viewBox="0 0 24 24">
                                    <circle class="cf:opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                    <path class="cf:opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                <span wire:loading.remove wire:target="submit">{{ $field['buttonText'] ?? __('Submit') }}</span>
                                <span wire:loading wire:target="submit">{{ __('Submitting...') }}</span>
                            </button>
                        </div>

                    @elseif ($fieldType === 'textarea')
                        {{-- Textarea Field --}}
                        <div style="{{ $widthStyle }}">
                            <label for="{{ $fieldName }}" class="cf:block cf:text-sm cf:font-medium cf:text-gray-700 cf:dark:text-gray-300 cf:mb-1.5">
                                {{ $fieldLabel }}
                                @if($required)<span class="cf:text-red-500 cf:ml-0.5">*</span>@endif
                            </label>
                            <textarea
                                id="{{ $fieldName }}"
                                wire:model.defer="formData.{{ $fieldName }}"
                                placeholder="{{ $placeholder }}"
                                rows="4"
                                class="cf:w-full cf:px-3 cf:py-2 cf:border cf:border-gray-300 cf:dark:border-gray-600 cf:rounded-lg cf:text-gray-900 cf:dark:text-white cf:bg-white cf:dark:bg-gray-800 cf:placeholder-gray-400 cf:dark:placeholder-gray-500 cf:focus:ring-2 cf:focus:ring-blue-500 cf:focus:border-blue-500 cf:transition-colors"
                                @if($required) required @endif
                            ></textarea>
                            @error('formData.' . $fieldName)
                                <p class="cf:mt-1 cf:text-sm cf:text-red-500">{{ $message }}</p>
                            @enderror
                        </div>

                    @elseif ($fieldType === 'select')
                        {{-- Select Dropdown --}}
                        <div style="{{ $widthStyle }}">
                            <label for="{{ $fieldName }}" class="cf:block cf:text-sm cf:font-medium cf:text-gray-700 cf:dark:text-gray-300 cf:mb-1.5">
                                {{ $fieldLabel }}
                                @if($required)<span class="cf:text-red-500 cf:ml-0.5">*</span>@endif
                            </label>
                            <select
                                id="{{ $fieldName }}"
                                wire:model.defer="formData.{{ $fieldName }}"
                                class="cf:w-full cf:px-3 cf:py-2 cf:border cf:border-gray-300 cf:dark:border-gray-600 cf:rounded-lg cf:text-gray-900 cf:dark:text-white cf:bg-white cf:dark:bg-gray-800 cf:focus:ring-2 cf:focus:ring-blue-500 cf:focus:border-blue-500 cf:transition-colors"
                                @if($required) required @endif
                            >
                                <option value="">{{ $placeholder ?: __('Select an option') }}</option>
                                @foreach ($options as $option)
                                    @if(is_array($option))
                                        <option value="{{ $option['value'] ?? '' }}">{{ $option['label'] ?? $option['value'] ?? '' }}</option>
                                    @else
                                        <option value="{{ $option }}">{{ $option }}</option>
                                    @endif
                                @endforeach
                            </select>
                            @error('formData.' . $fieldName)
                                <p class="cf:mt-1 cf:text-sm cf:text-red-500">{{ $message }}</p>
                            @enderror
                        </div>

                    @elseif ($fieldType === 'radio')
                        {{-- Radio Buttons --}}
                        <div style="{{ $widthStyle }}">
                            <label class="cf:block cf:text-sm cf:font-medium cf:text-gray-700 cf:dark:text-gray-300 cf:mb-2">
                                {{ $fieldLabel }}
                                @if($required)<span class="cf:text-red-500 cf:ml-0.5">*</span>@endif
                            </label>
                            <div class="cf:space-y-2">
                                @foreach ($options as $option)
                                    @php
                                        $optionValue = is_array($option) ? ($option['value'] ?? '') : $option;
                                        $optionLabel = is_array($option) ? ($option['label'] ?? $option['value'] ?? '') : $option;
                                    @endphp
                                    <label class="cf:flex cf:items-center cf:gap-3 cf:cursor-pointer">
                                        <input
                                            type="radio"
                                            name="{{ $fieldName }}"
                                            value="{{ $optionValue }}"
                                            wire:model.defer="formData.{{ $fieldName }}"
                                            class="cf:w-4 cf:h-4 cf:text-blue-600 cf:border-gray-300 cf:dark:border-gray-600 cf:focus:ring-blue-500 cf:dark:bg-gray-800"
                                        >
                                        <span class="cf:text-sm cf:text-gray-700 cf:dark:text-gray-300">{{ $optionLabel }}</span>
                                    </label>
                                @endforeach
                            </div>
                            @error('formData.' . $fieldName)
                                <p class="cf:mt-1 cf:text-sm cf:text-red-500">{{ $message }}</p>
                            @enderror
                        </div>

                    @elseif ($fieldType === 'checkbox')
                        {{-- Checkbox Group --}}
                        <div style="{{ $widthStyle }}">
                            <label class="cf:block cf:text-sm cf:font-medium cf:text-gray-700 cf:dark:text-gray-300 cf:mb-2">
                                {{ $fieldLabel }}
                                @if($required)<span class="cf:text-red-500 cf:ml-0.5">*</span>@endif
                            </label>
                            <div class="cf:space-y-2">
                                @foreach ($options as $option)
                                    @php
                                        $optionValue = is_array($option) ? ($option['value'] ?? '') : $option;
                                        $optionLabel = is_array($option) ? ($option['label'] ?? $option['value'] ?? '') : $option;
                                    @endphp
                                    <label class="cf:flex cf:items-center cf:gap-3 cf:cursor-pointer">
                                        <input
                                            type="checkbox"
                                            value="{{ $optionValue }}"
                                            wire:model.defer="formData.{{ $fieldName }}"
                                            class="cf:w-4 cf:h-4 cf:text-blue-600 cf:border-gray-300 cf:dark:border-gray-600 cf:rounded cf:focus:ring-blue-500 cf:dark:bg-gray-800"
                                        >
                                        <span class="cf:text-sm cf:text-gray-700 cf:dark:text-gray-300">{{ $optionLabel }}</span>
                                    </label>
                                @endforeach
                            </div>
                            @error('formData.' . $fieldName)
                                <p class="cf:mt-1 cf:text-sm cf:text-red-500">{{ $message }}</p>
                            @enderror
                        </div>

                    @else
                        {{-- Text, Number, Email inputs --}}
                        <div style="{{ $widthStyle }}">
                            <label for="{{ $fieldName }}" class="cf:block cf:text-sm cf:font-medium cf:text-gray-700 cf:dark:text-gray-300 cf:mb-1.5">
                                {{ $fieldLabel }}
                                @if($required)<span class="cf:text-red-500 cf:ml-0.5">*</span>@endif
                            </label>
                            <input
                                id="{{ $fieldName }}"
                                type="{{ $fieldType }}"
                                wire:model.defer="formData.{{ $fieldName }}"
                                placeholder="{{ $placeholder }}"
                                class="cf:w-full cf:px-3 cf:py-2 cf:border cf:border-gray-300 cf:dark:border-gray-600 cf:rounded-lg cf:text-gray-900 cf:dark:text-white cf:bg-white cf:dark:bg-gray-800 cf:placeholder-gray-400 cf:dark:placeholder-gray-500 cf:focus:ring-2 cf:focus:ring-blue-500 cf:focus:border-blue-500 cf:transition-colors"
                                @if($required) required @endif
                            >
                            @error('formData.' . $fieldName)
                                <p class="cf:mt-1 cf:text-sm cf:text-red-500">{{ $message }}</p>
                            @enderror
                        </div>
                    @endif
                @endforeach

                {{-- Default submit button if no button field exists --}}
                @php
                    $hasButtonField = collect($fields)->contains(fn($f) => ($f['type'] ?? '') === 'button');
                @endphp
                @if(!$hasButtonField)
                    <div class="cf:pt-2 cf:w-full">
                        <button
                            type="submit"
                            class="cf:inline-flex cf:items-center cf:justify-center cf:gap-2 cf:px-6 cf:py-2.5 cf:text-white cf:rounded-lg cf:font-medium cf:text-sm cf:transition-all cf:cursor-pointer cf:hover:brightness-110 cf:focus:outline-none cf:focus:ring-2 cf:focus:ring-offset-2 cf:dark:focus:ring-offset-gray-900 cf:disabled:opacity-50 cf:disabled:cursor-not-allowed"
                            style="background-color: var(--color-primary, #635bff); --tw-ring-color: var(--color-primary, #635bff);"
                            wire:loading.attr="disabled"
                            wire:loading.class="cf:opacity-75 cf:cursor-wait"
                        >
                            <svg wire:loading wire:target="submit" class="cf:animate-spin cf:h-4 cf:w-4" fill="none" viewBox="0 0 24 24">
                                <circle class="cf:opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="cf:opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            <span wire:loading.remove wire:target="submit">{{ __('Submit') }}</span>
                            <span wire:loading wire:target="submit">{{ __('Submitting...') }}</span>
                        </button>
                    </div>
                @endif
            </form>
        </div>
    </div>
    @endif
</div>
