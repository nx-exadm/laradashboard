<x-buttons.action-item
    :href="$url"
    icon="lucide:inbox"
    :label="__('Submissions') . ($count > 0 ? ' (' . number_format($count) . ')' : '')"
/>
