@php
    $embedCode = '<livewire:customform::components.form-submission :id="' . $form->id . '" />';
@endphp

<div x-data="{ copied: false }" class="flex items-center gap-2">
    <code class="text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded truncate max-w-[180px]" title="{{ $embedCode }}">
        &lt;livewire:customform::...&gt;
    </code>
    <button
        type="button"
        x-on:click="navigator.clipboard.writeText('{{ $embedCode }}'); copied = true; setTimeout(() => copied = false, 2000)"
        class="text-gray-400 hover:text-primary transition-colors"
        title="{{ __('Copy embed code') }}"
    >
        <template x-if="!copied">
            <iconify-icon icon="lucide:copy" class="w-4 h-4"></iconify-icon>
        </template>
        <template x-if="copied">
            <iconify-icon icon="lucide:check" class="w-4 h-4 text-green-500"></iconify-icon>
        </template>
    </button>
</div>
