@if($form->is_active)
    <span class="px-2 py-1 text-xs font-medium text-green-700 bg-green-100 rounded-full dark:bg-green-900/30 dark:text-green-400">
        {{ __('Active') }}
    </span>
@else
    <span class="px-2 py-1 text-xs font-medium text-red-700 bg-red-100 rounded-full dark:bg-red-900/30 dark:text-red-400">
        {{ __('Inactive') }}
    </span>
@endif
