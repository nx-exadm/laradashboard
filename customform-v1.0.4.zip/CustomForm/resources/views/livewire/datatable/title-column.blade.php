<div class="flex items-center">
    <a href="{{ route('admin.custom-forms.show', $form->id) }}" class="text-gray-800 dark:text-white hover:text-primary dark:hover:text-primary font-medium">
        {{ $form->title }}
    </a>
</div>
<div class="text-xs text-gray-500 dark:text-gray-400 mt-1 font-mono">
    {{ $form->slug }}
</div>
