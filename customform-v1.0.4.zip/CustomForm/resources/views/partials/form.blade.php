<div x-data="formBuilder()" class="cf:flex cf:gap-4 cf:min-h-[600px]">
    <!-- Left Sidebar - Component Palette (Compact) -->
    <div class="cf:w-16 cf:shrink-0">
        <div class="cf:sticky cf:top-4 cf:rounded-lg cf:border cf:border-gray-200 cf:bg-white cf:dark:border-gray-700 cf:dark:bg-gray-900 cf:p-2">
            <h3 class="cf:sr-only">{{ __('Form Components') }}</h3>
            <div class="cf:space-y-1">
                <template x-for="fieldType in fieldTypes" :key="fieldType.id">
                    <button
                        type="button"
                        @click="addField(fieldType.id)"
                        class="cf:w-full cf:flex cf:items-center cf:justify-center cf:p-2.5 cf:text-gray-600 cf:dark:text-gray-400 cf:border cf:border-transparent cf:rounded-lg cf:hover:bg-gray-100 cf:dark:hover:bg-gray-800 cf:hover:border-gray-200 cf:dark:hover:border-gray-600 cf:hover:text-gray-900 cf:dark:hover:text-white cf:transition-all group cf:relative"
                        :title="fieldType.label"
                        draggable="true"
                        @dragstart="dragStart($event, fieldType.id)"
                    >
                        <iconify-icon :icon="fieldType.icon" class="cf:text-xl"></iconify-icon>
                        <span class="cf:absolute cf:left-full cf:ml-2 cf:px-2 cf:py-1 cf:text-xs cf:font-medium cf:text-white cf:bg-gray-900 cf:dark:bg-gray-700 cf:rounded cf:opacity-0 group-hover:opacity-100 cf:whitespace-nowrap cf:z-50 cf:pointer-events-none cf:transition-opacity" x-text="fieldType.label"></span>
                    </button>
                </template>
            </div>
        </div>
    </div>

    <!-- Center - Form Builder Canvas -->
    <div class="cf:flex-1 cf:min-w-0">
        <form action="{{ $action }}" method="POST" id="form-builder-form">
            @method($method ?? 'POST')
            @csrf

            <!-- Form Builder Canvas with Header -->
            <div class="cf:rounded-lg cf:border cf:border-gray-200 cf:bg-white cf:dark:border-gray-700 cf:dark:bg-gray-900 cf:mb-4 cf:overflow-hidden">
                <!-- Header Bar with Title, Description, Slug and Status Toggle -->
                <div class="cf:border-b cf:border-gray-200 cf:dark:border-gray-700 cf:bg-gray-50 cf:dark:bg-gray-800" x-data="{ showSlug: false, showDescription: false, description: @js(old('description', $form->description ?? '')) }">
                    <div class="cf:flex cf:items-center cf:justify-between cf:gap-4 cf:p-3">
                        <div class="cf:flex-1">
                            <input
                                type="text"
                                name="title"
                                id="title"
                                required
                                autofocus
                                value="{{ old('title', $form->title ?? '') }}"
                                placeholder="{{ __('Enter Form Title...') }}"
                                class="cf:w-full cf:bg-transparent cf:border-0 cf:text-lg cf:font-semibold cf:text-gray-900 cf:dark:text-white cf:placeholder-gray-400 cf:dark:placeholder-gray-500 cf:focus:ring-0 cf:focus:outline-none"
                            >
                        </div>
                        <div class="cf:flex cf:items-center cf:gap-3 cf:shrink-0">
                            <!-- Description Toggle -->
                            <button
                                type="button"
                                @click="showDescription = !showDescription"
                                class="cf:flex cf:items-center cf:gap-1 cf:px-2 cf:py-1 cf:text-xs cf:text-gray-500 cf:dark:text-gray-400 cf:hover:text-gray-700 cf:dark:hover:text-gray-300 cf:hover:bg-gray-100 cf:dark:hover:bg-gray-700 cf:rounded cf:transition-colors"
                                :class="{ 'cf:bg-gray-100 cf:dark:bg-gray-700': showDescription }"
                                :title="showDescription ? '{{ __('Hide description') }}' : '{{ __('Edit description') }}'"
                            >
                                <iconify-icon icon="lucide:file-text" class="cf:text-sm"></iconify-icon>
                                <span x-show="description && !showDescription" class="cf:max-w-[80px] cf:truncate cf:text-gray-400 cf:dark:text-gray-500" x-text="description"></span>
                                <span x-show="!description && !showDescription">{{ __('Description') }}</span>
                            </button>
                            <!-- Slug Toggle -->
                            <button
                                type="button"
                                @click="showSlug = !showSlug"
                                class="cf:flex cf:items-center cf:gap-1 cf:px-2 cf:py-1 cf:text-xs cf:text-gray-500 cf:dark:text-gray-400 cf:hover:text-gray-700 cf:dark:hover:text-gray-300 cf:hover:bg-gray-100 cf:dark:hover:bg-gray-700 cf:rounded cf:transition-colors"
                                :class="{ 'cf:bg-gray-100 cf:dark:bg-gray-700': showSlug }"
                                :title="showSlug ? '{{ __('Hide slug') }}' : '{{ __('Edit slug') }}'"
                            >
                                <iconify-icon icon="lucide:link" class="cf:text-sm"></iconify-icon>
                                <span>{{ __('Slug') }}</span>
                            </button>
                            <!-- Status Toggle -->
                            <label class="cf:flex cf:items-center cf:gap-2 cf:cursor-pointer">
                                <span class="cf:text-sm cf:text-gray-600 cf:dark:text-gray-400">{{ __('Active') }}</span>
                                <div class="cf:relative" x-data="{ isActive: {{ old('status', $form->status ?? 'active') == 'active' ? 'true' : 'false' }} }">
                                    <input
                                        type="hidden"
                                        name="status"
                                        :value="isActive ? 'active' : 'inactive'"
                                    >
                                    <button
                                        type="button"
                                        @click="isActive = !isActive"
                                        :class="isActive ? 'cf:bg-green-500' : 'cf:bg-gray-300 cf:dark:bg-gray-600'"
                                        class="cf:relative cf:w-11 cf:h-6 cf:rounded-full cf:transition-colors cf:duration-200 cf:focus:outline-none cf:focus:ring-2 cf:focus:ring-green-500 cf:focus:ring-offset-2 cf:dark:focus:ring-offset-gray-800"
                                    >
                                        <span
                                            :class="isActive ? 'cf:translate-x-5' : 'cf:translate-x-0'"
                                            class="cf:absolute cf:left-0.5 cf:top-0.5 cf:w-5 cf:h-5 cf:bg-white cf:rounded-full cf:shadow cf:transition-transform cf:duration-200"
                                        ></span>
                                    </button>
                                </div>
                            </label>
                            <!-- Field Count -->
                            <span class="cf:text-xs cf:text-gray-500 cf:dark:text-gray-400 cf:px-2 cf:py-1 cf:bg-gray-100 cf:dark:bg-gray-700 cf:rounded" x-show="formSchema.length > 0" x-text="`${formSchema.length} field(s)`"></span>
                        </div>
                    </div>

                    <!-- Description Input (Collapsible) -->
                    <div x-show="showDescription" x-collapse class="cf:px-3 cf:pb-3">
                        <div class="cf:flex cf:items-start cf:gap-2">
                            <iconify-icon icon="lucide:file-text" class="cf:text-gray-400 cf:dark:text-gray-500 cf:mt-2"></iconify-icon>
                            <input
                                type="text"
                                name="description"
                                id="description"
                                x-model="description"
                                value="{{ old('description', $form->description ?? '') }}"
                                placeholder="{{ __('Add a short description for this form...') }}"
                                class="cf:flex-1 cf:bg-white cf:dark:bg-gray-900 cf:border cf:border-gray-200 cf:dark:border-gray-600 cf:rounded cf:px-2 cf:py-1.5 cf:text-sm cf:text-gray-700 cf:dark:text-gray-300 cf:placeholder-gray-400 cf:dark:placeholder-gray-500 cf:focus:ring-1 cf:focus:ring-blue-500 cf:focus:border-blue-500 cf:focus:outline-none"
                            >
                        </div>
                    </div>

                    <!-- Slug Input (Collapsible) -->
                    <div x-show="showSlug" x-collapse class="cf:px-3 cf:pb-3">
                        <div class="cf:flex cf:items-center cf:gap-2">
                            <iconify-icon icon="lucide:link" class="cf:text-gray-400 cf:dark:text-gray-500"></iconify-icon>
                            <input
                                type="text"
                                name="slug"
                                id="slug"
                                value="{{ old('slug', $form->slug ?? '') }}"
                                placeholder="{{ __('form-slug') }}"
                                class="cf:flex-1 cf:bg-white cf:dark:bg-gray-900 cf:border cf:border-gray-200 cf:dark:border-gray-600 cf:rounded cf:px-2 cf:py-1.5 cf:text-sm cf:text-gray-700 cf:dark:text-gray-300 cf:placeholder-gray-400 cf:dark:placeholder-gray-500 cf:focus:ring-1 cf:focus:ring-blue-500 cf:focus:border-blue-500 cf:focus:outline-none cf:font-mono"
                            >
                            <span class="cf:text-xs cf:text-gray-400 cf:dark:text-gray-500">{{ __('URL-friendly identifier') }}</span>
                        </div>
                    </div>
                </div>

                <!-- Canvas Area -->
                <div class="cf:p-4">
                    <div
                        class="cf:min-h-[400px] cf:border-2 cf:border-dashed cf:border-gray-300 cf:dark:border-gray-600 cf:rounded-lg cf:p-4 cf:transition-colors"
                        :class="{ 'cf:border-primary cf:bg-blue-50/50 cf:dark:bg-blue-900/10': isDraggingOver }"
                        @dragover.prevent="isDraggingOver = true"
                        @dragleave="isDraggingOver = false"
                        @drop.prevent="handleDrop($event)"
                        id="form-canvas"
                    >
                        <!-- Empty State -->
                        <div x-show="formSchema.length === 0" class="cf:flex cf:flex-col cf:items-center cf:justify-center cf:h-full cf:min-h-[350px] cf:text-center">
                            <svg class="cf:w-16 cf:h-16 cf:mb-4 cf:text-gray-300 cf:dark:text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                            </svg>
                            <p class="cf:text-base cf:font-medium cf:text-gray-500 cf:dark:text-gray-400">{{ __('Start Building Your Form') }}</p>
                            <p class="cf:text-sm cf:text-gray-400 cf:dark:text-gray-500 cf:mt-1">{{ __('Drag components from the sidebar or click to add') }}</p>
                        </div>

                        <!-- Form Fields Preview (Sortable with Flex Layout) -->
                        <div class="cf:flex cf:flex-wrap cf:gap-3" id="sortable-fields">
                            <template x-for="(field, index) in formSchema" :key="field.name">
                                <div
                                    class="cf:border cf:rounded-lg cf:p-3 cf:bg-gray-50 cf:dark:bg-gray-800 cf:relative group cf:cursor-move cf:transition-all cf:min-w-0"
                                    :class="{
                                        'cf:ring-2 cf:ring-blue-500 cf:border-primary cf:bg-blue-50 cf:dark:bg-blue-900/20': selectedField === index,
                                        'cf:border-gray-200 cf:dark:border-gray-700 cf:hover:border-gray-300 cf:dark:hover:border-gray-600': selectedField !== index
                                    }"
                                    :style="{
                                        width: `calc(${field.width || 100}% - ${(field.width || 100) < 100 ? '0.375rem' : '0px'})`,
                                        flexShrink: 0
                                    }"
                                    @click="selectField(index)"
                                    :data-index="index"
                                    draggable="true"
                                    @dragstart="dragFieldStart($event, index)"
                                    @dragend="dragFieldEnd()"
                                    @dragover.prevent="dragFieldOver($event, index)"
                                >
                                    <!-- Field Controls -->
                                    <div class="cf:absolute cf:-top-2 cf:-right-2 cf:flex cf:items-center cf:gap-1 cf:opacity-0 group-hover:opacity-100 cf:transition-opacity">
                                        <button
                                            type="button"
                                            @click.stop="moveUp(index)"
                                            x-show="index > 0"
                                            class="cf:p-1 cf:bg-white cf:dark:bg-gray-700 cf:border cf:border-gray-200 cf:dark:border-gray-600 cf:rounded cf:shadow-sm cf:hover:bg-gray-50 cf:dark:hover:bg-gray-600"
                                            title="{{ __('Move Up') }}"
                                        >
                                            <iconify-icon icon="lucide:chevron-up" class="cf:text-sm cf:text-gray-600 cf:dark:text-gray-300"></iconify-icon>
                                        </button>
                                        <button
                                            type="button"
                                            @click.stop="moveDown(index)"
                                            x-show="index < formSchema.length - 1"
                                            class="cf:p-1 cf:bg-white cf:dark:bg-gray-700 cf:border cf:border-gray-200 cf:dark:border-gray-600 cf:rounded cf:shadow-sm cf:hover:bg-gray-50 cf:dark:hover:bg-gray-600"
                                            title="{{ __('Move Down') }}"
                                        >
                                            <iconify-icon icon="lucide:chevron-down" class="cf:text-sm cf:text-gray-600 cf:dark:text-gray-300"></iconify-icon>
                                        </button>
                                        <button
                                            type="button"
                                            @click.stop="duplicateField(index)"
                                            class="cf:p-1 cf:bg-white cf:dark:bg-gray-700 cf:border cf:border-gray-200 cf:dark:border-gray-600 cf:rounded cf:shadow-sm cf:hover:bg-gray-50 cf:dark:hover:bg-gray-600"
                                            title="{{ __('Duplicate') }}"
                                        >
                                            <iconify-icon icon="lucide:copy" class="cf:text-sm cf:text-gray-600 cf:dark:text-gray-300"></iconify-icon>
                                        </button>
                                        <button
                                            type="button"
                                            @click.stop="removeField(index)"
                                            class="cf:p-1 cf:bg-white cf:dark:bg-gray-700 cf:border cf:border-red-200 cf:dark:border-red-800 cf:rounded cf:shadow-sm cf:hover:bg-red-50 cf:dark:hover:bg-red-900/30"
                                            title="{{ __('Delete') }}"
                                        >
                                            <iconify-icon icon="lucide:trash-2" class="cf:text-sm cf:text-red-500"></iconify-icon>
                                        </button>
                                    </div>

                                    <!-- Drag Handle -->
                                    <div class="cf:absolute cf:left-2 cf:top-1/2 cf:-translate-y-1/2 cf:opacity-0 group-hover:opacity-50 cf:cursor-grab">
                                        <iconify-icon icon="lucide:grip-vertical" class="cf:text-gray-400"></iconify-icon>
                                    </div>

                                    <!-- Field Preview -->
                                    <div class="cf:pl-4">
                                        <!-- Text/Number/Email Input -->
                                        <template x-if="['text', 'number', 'email'].includes(field.type)">
                                            <div>
                                                <label class="cf:block cf:text-sm cf:font-medium cf:text-gray-700 cf:dark:text-gray-300 cf:mb-1">
                                                    <span x-text="field.label"></span>
                                                    <span x-show="field.required" class="cf:text-red-500 cf:ml-0.5">*</span>
                                                </label>
                                                <input
                                                    :type="field.type"
                                                    :placeholder="field.placeholder || `Enter ${field.label.toLowerCase()}`"
                                                    class="form-control cf:text-sm cf:pointer-events-none"
                                                    tabindex="-1"
                                                >
                                            </div>
                                        </template>

                                        <!-- Textarea -->
                                        <template x-if="field.type === 'textarea'">
                                            <div>
                                                <label class="cf:block cf:text-sm cf:font-medium cf:text-gray-700 cf:dark:text-gray-300 cf:mb-1">
                                                    <span x-text="field.label"></span>
                                                    <span x-show="field.required" class="cf:text-red-500 cf:ml-0.5">*</span>
                                                </label>
                                                <textarea
                                                    :placeholder="field.placeholder || `Enter ${field.label.toLowerCase()}`"
                                                    rows="2"
                                                    class="form-control-textarea cf:text-sm cf:pointer-events-none"
                                                    tabindex="-1"
                                                ></textarea>
                                            </div>
                                        </template>

                                        <!-- Select -->
                                        <template x-if="field.type === 'select'">
                                            <div>
                                                <label class="cf:block cf:text-sm cf:font-medium cf:text-gray-700 cf:dark:text-gray-300 cf:mb-1">
                                                    <span x-text="field.label"></span>
                                                    <span x-show="field.required" class="cf:text-red-500 cf:ml-0.5">*</span>
                                                </label>
                                                <select class="form-control cf:text-sm cf:pointer-events-none" tabindex="-1">
                                                    <option x-text="field.placeholder || 'Select an option'"></option>
                                                    <template x-for="option in field.options" :key="option.value">
                                                        <option x-text="option.label"></option>
                                                    </template>
                                                </select>
                                            </div>
                                        </template>

                                        <!-- Radio -->
                                        <template x-if="field.type === 'radio'">
                                            <div>
                                                <label class="cf:block cf:text-sm cf:font-medium cf:text-gray-700 cf:dark:text-gray-300 cf:mb-2">
                                                    <span x-text="field.label"></span>
                                                    <span x-show="field.required" class="cf:text-red-500 cf:ml-0.5">*</span>
                                                </label>
                                                <div class="cf:flex cf:flex-wrap cf:gap-4">
                                                    <template x-for="option in field.options" :key="option.value">
                                                        <label class="cf:flex cf:items-center cf:gap-2 cf:cursor-default">
                                                            <input type="radio" :name="`preview_${index}`" class="form-radio" disabled>
                                                            <span class="cf:text-sm cf:text-gray-700 cf:dark:text-gray-300" x-text="option.label"></span>
                                                        </label>
                                                    </template>
                                                </div>
                                            </div>
                                        </template>

                                        <!-- Checkbox -->
                                        <template x-if="field.type === 'checkbox'">
                                            <div>
                                                <label class="cf:block cf:text-sm cf:font-medium cf:text-gray-700 cf:dark:text-gray-300 cf:mb-2">
                                                    <span x-text="field.label"></span>
                                                    <span x-show="field.required" class="cf:text-red-500 cf:ml-0.5">*</span>
                                                </label>
                                                <div class="cf:flex cf:flex-wrap cf:gap-4">
                                                    <template x-for="option in field.options" :key="option.value">
                                                        <label class="cf:flex cf:items-center cf:gap-2 cf:cursor-default">
                                                            <input type="checkbox" class="form-checkbox" disabled>
                                                            <span class="cf:text-sm cf:text-gray-700 cf:dark:text-gray-300" x-text="option.label"></span>
                                                        </label>
                                                    </template>
                                                </div>
                                            </div>
                                        </template>

                                        <!-- Button -->
                                        <template x-if="field.type === 'button'">
                                            <div>
                                                <button
                                                    type="button"
                                                    class="cf:px-4 cf:py-2 cf:rounded-lg cf:font-medium cf:text-sm cf:transition-colors cf:pointer-events-none"
                                                    :class="{
                                                        'cf:text-white': field.buttonClass === 'btn-primary' || (!field.buttonClass && field.buttonClass !== 'btn-custom'),
                                                        'cf:bg-gray-200 cf:dark:bg-gray-700 cf:text-gray-800 cf:dark:text-gray-200': field.buttonClass === 'btn-secondary',
                                                        'cf:bg-green-600 cf:text-white': field.buttonClass === 'btn-success',
                                                        'cf:bg-red-600 cf:text-white': field.buttonClass === 'btn-danger'
                                                    }"
                                                    :style="field.buttonClass === 'btn-primary' || (!field.buttonClass && field.buttonClass !== 'btn-custom') ? { backgroundColor: 'var(--color-primary, #635bff)' } : (field.buttonClass === 'btn-custom' ? { backgroundColor: field.buttonBgColor || '#635bff', color: field.buttonTextColor || '#ffffff' } : {})"
                                                    x-text="field.buttonText || 'Submit'"
                                                ></button>
                                            </div>
                                        </template>
                                    </div>
                                </div>
                            </template>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Hidden field to store form schema -->
            <input type="hidden" name="form_schema" id="form-schema" x-model="JSON.stringify(formSchema)">

            <!-- Form Actions -->
            <div class="cf:flex cf:justify-start cf:gap-3">
                <button type="submit" class="btn-primary">
                    <iconify-icon icon="lucide:save" class="cf:mr-1"></iconify-icon>
                    {{ __('Save Form') }}
                </button>
                <a href="{{ route('admin.custom-forms.index') }}" class="btn-default">{{ __('Cancel') }}</a>
            </div>
        </form>
    </div>

    <!-- Right Sidebar - Field Properties -->
    <div class="cf:w-72 cf:shrink-0">
        <div class="cf:sticky cf:top-4">
            <div
                class="cf:rounded-lg cf:border cf:border-gray-200 cf:bg-white cf:dark:border-gray-700 cf:dark:bg-gray-900 cf:transition-all"
                :class="{ 'cf:ring-2 cf:ring-blue-500': selectedField !== null }"
            >
                <!-- No Selection State -->
                <div x-show="selectedField === null" class="cf:p-4 cf:text-center">
                    <iconify-icon icon="lucide:mouse-pointer-click" class="cf:text-4xl cf:text-gray-300 cf:dark:text-gray-600 cf:mb-2"></iconify-icon>
                    <p class="cf:text-sm cf:text-gray-500 cf:dark:text-gray-400">{{ __('Select a field to edit its properties') }}</p>
                </div>

                <!-- Field Properties Panel -->
                <template x-if="selectedField !== null && formSchema[selectedField]">
                    <div class="cf:divide-y cf:divide-gray-200 cf:dark:divide-gray-700">
                        <!-- Header -->
                        <div class="cf:p-3 cf:flex cf:items-center cf:justify-between cf:bg-gray-50 cf:dark:bg-gray-800 cf:rounded-t-lg">
                            <div class="cf:flex cf:items-center cf:gap-2">
                                <iconify-icon :icon="getFieldIcon(formSchema[selectedField].type)" class="cf:text-blue-500"></iconify-icon>
                                <span class="cf:text-sm cf:font-medium cf:text-gray-900 cf:dark:text-white" x-text="getFieldTypeLabel(formSchema[selectedField].type)"></span>
                            </div>
                            <button
                                type="button"
                                @click="selectedField = null"
                                class="cf:p-1 cf:text-gray-400 cf:hover:text-gray-600 cf:dark:hover:text-gray-300"
                            >
                                <iconify-icon icon="lucide:x" class="cf:text-lg"></iconify-icon>
                            </button>
                        </div>

                        <!-- Common Properties -->
                        <div class="cf:p-3 cf:space-y-3">
                            <div>
                                <label class="cf:block cf:text-xs cf:font-medium cf:text-gray-600 cf:dark:text-gray-400 cf:mb-1">{{ __('Field Name') }}</label>
                                <input
                                    type="text"
                                    x-model="formSchema[selectedField].name"
                                    @input="updateFormSchema()"
                                    class="form-control cf:text-sm"
                                    placeholder="field_name"
                                >
                            </div>

                            <!-- Show Label for non-button fields -->
                            <div x-show="formSchema[selectedField].type !== 'button'">
                                <label class="cf:block cf:text-xs cf:font-medium cf:text-gray-600 cf:dark:text-gray-400 cf:mb-1">{{ __('Label') }}</label>
                                <input
                                    type="text"
                                    x-model="formSchema[selectedField].label"
                                    @input="updateFormSchema()"
                                    class="form-control cf:text-sm"
                                    placeholder="Field Label"
                                >
                            </div>

                            <!-- Placeholder for text-like fields -->
                            <div x-show="['text', 'number', 'email', 'textarea', 'select'].includes(formSchema[selectedField].type)">
                                <label class="cf:block cf:text-xs cf:font-medium cf:text-gray-600 cf:dark:text-gray-400 cf:mb-1">{{ __('Placeholder') }}</label>
                                <input
                                    type="text"
                                    x-model="formSchema[selectedField].placeholder"
                                    @input="updateFormSchema()"
                                    class="form-control cf:text-sm"
                                    placeholder="Enter placeholder text"
                                >
                            </div>

                            <!-- Width setting for all fields -->
                            <div>
                                <label class="cf:block cf:text-xs cf:font-medium cf:text-gray-600 cf:dark:text-gray-400 cf:mb-1">{{ __('Width') }}</label>
                                <select
                                    x-model="formSchema[selectedField].width"
                                    @change="updateFormSchema()"
                                    class="form-control cf:text-sm"
                                >
                                    <option value="100">{{ __('100% (Full)') }}</option>
                                    <option value="75">{{ __('75% (Three-quarters)') }}</option>
                                    <option value="66">{{ __('66% (Two-thirds)') }}</option>
                                    <option value="50">{{ __('50% (Half)') }}</option>
                                    <option value="33">{{ __('33% (One-third)') }}</option>
                                    <option value="25">{{ __('25% (Quarter)') }}</option>
                                </select>
                                <p class="cf:text-xs cf:text-gray-400 cf:dark:text-gray-500 cf:mt-1">{{ __('Fields with combined widths flow in rows') }}</p>
                            </div>

                            <!-- Required checkbox for non-button fields -->
                            <div x-show="formSchema[selectedField].type !== 'button'" class="cf:flex cf:items-center cf:gap-2">
                                <input
                                    type="checkbox"
                                    x-model="formSchema[selectedField].required"
                                    @change="updateFormSchema()"
                                    class="form-checkbox"
                                    id="field-required"
                                >
                                <label for="field-required" class="cf:text-sm cf:text-gray-700 cf:dark:text-gray-300">{{ __('Required field') }}</label>
                            </div>
                        </div>

                        <!-- Button-specific Properties -->
                        <template x-if="formSchema[selectedField].type === 'button'">
                            <div class="cf:p-3 cf:space-y-3">
                                <div>
                                    <label class="cf:block cf:text-xs cf:font-medium cf:text-gray-600 cf:dark:text-gray-400 cf:mb-1">{{ __('Button Text') }}</label>
                                    <input
                                        type="text"
                                        x-model="formSchema[selectedField].buttonText"
                                        @input="updateFormSchema()"
                                        class="form-control cf:text-sm"
                                        placeholder="Submit"
                                    >
                                </div>
                                <div>
                                    <label class="cf:block cf:text-xs cf:font-medium cf:text-gray-600 cf:dark:text-gray-400 cf:mb-1">{{ __('Button Type') }}</label>
                                    <select
                                        x-model="formSchema[selectedField].buttonType"
                                        @change="updateFormSchema()"
                                        class="form-control cf:text-sm"
                                    >
                                        <option value="submit">{{ __('Submit') }}</option>
                                        <option value="button">{{ __('Button') }}</option>
                                        <option value="reset">{{ __('Reset') }}</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="cf:block cf:text-xs cf:font-medium cf:text-gray-600 cf:dark:text-gray-400 cf:mb-1">{{ __('Button Style') }}</label>
                                    <select
                                        x-model="formSchema[selectedField].buttonClass"
                                        @change="updateFormSchema()"
                                        class="form-control cf:text-sm"
                                    >
                                        <option value="btn-primary">{{ __('Primary') }}</option>
                                        <option value="btn-secondary">{{ __('Secondary (Gray)') }}</option>
                                        <option value="btn-success">{{ __('Success (Green)') }}</option>
                                        <option value="btn-danger">{{ __('Danger (Red)') }}</option>
                                        <option value="btn-custom">{{ __('Custom Colors') }}</option>
                                    </select>
                                </div>
                                <div x-show="formSchema[selectedField].buttonClass === 'btn-custom'" class="cf:space-y-3">
                                    <div>
                                        <label class="cf:block cf:text-xs cf:font-medium cf:text-gray-600 cf:dark:text-gray-400 cf:mb-1">{{ __('Background Color') }}</label>
                                        <div class="cf:flex cf:items-center cf:gap-2">
                                            <input
                                                type="color"
                                                x-model="formSchema[selectedField].buttonBgColor"
                                                @input="updateFormSchema()"
                                                class="cf:w-10 cf:h-8 cf:rounded cf:border cf:border-gray-300 cf:dark:border-gray-600 cf:cursor-pointer cf:p-0.5"
                                            >
                                            <input
                                                type="text"
                                                x-model="formSchema[selectedField].buttonBgColor"
                                                @input="updateFormSchema()"
                                                class="form-control cf:text-sm cf:flex-1"
                                                placeholder="#635bff"
                                            >
                                        </div>
                                    </div>
                                    <div>
                                        <label class="cf:block cf:text-xs cf:font-medium cf:text-gray-600 cf:dark:text-gray-400 cf:mb-1">{{ __('Text Color') }}</label>
                                        <div class="cf:flex cf:items-center cf:gap-2">
                                            <input
                                                type="color"
                                                x-model="formSchema[selectedField].buttonTextColor"
                                                @input="updateFormSchema()"
                                                class="cf:w-10 cf:h-8 cf:rounded cf:border cf:border-gray-300 cf:dark:border-gray-600 cf:cursor-pointer cf:p-0.5"
                                            >
                                            <input
                                                type="text"
                                                x-model="formSchema[selectedField].buttonTextColor"
                                                @input="updateFormSchema()"
                                                class="form-control cf:text-sm cf:flex-1"
                                                placeholder="#ffffff"
                                            >
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </template>

                        <!-- Options for Select/Radio/Checkbox -->
                        <template x-if="['select', 'radio', 'checkbox'].includes(formSchema[selectedField].type)">
                            <div class="cf:p-3">
                                <div class="cf:flex cf:items-center cf:justify-between cf:mb-2">
                                    <label class="cf:text-xs cf:font-medium cf:text-gray-600 cf:dark:text-gray-400">{{ __('Options') }}</label>
                                    <button
                                        type="button"
                                        @click="addOption(selectedField)"
                                        class="cf:text-xs cf:text-blue-600 cf:hover:text-blue-800 cf:dark:text-blue-400 cf:dark:hover:text-blue-300 cf:flex cf:items-center cf:gap-1"
                                    >
                                        <iconify-icon icon="lucide:plus" class="cf:text-sm"></iconify-icon>
                                        {{ __('Add') }}
                                    </button>
                                </div>
                                <div class="cf:space-y-2 cf:max-h-48 cf:overflow-y-auto">
                                    <template x-for="(option, optionIndex) in formSchema[selectedField].options" :key="optionIndex">
                                        <div class="cf:flex cf:items-center cf:gap-2">
                                            <input
                                                type="text"
                                                x-model="option.label"
                                                @input="updateFormSchema()"
                                                class="form-control cf:text-xs cf:flex-1"
                                                placeholder="Option label"
                                            >
                                            <input
                                                type="text"
                                                x-model="option.value"
                                                @input="updateFormSchema()"
                                                class="form-control cf:text-xs cf:w-20"
                                                placeholder="value"
                                            >
                                            <button
                                                type="button"
                                                @click="removeOption(selectedField, optionIndex)"
                                                class="cf:p-1 cf:text-red-500 cf:hover:bg-red-50 cf:dark:hover:bg-red-900/20 cf:rounded"
                                            >
                                                <iconify-icon icon="lucide:x" class="cf:text-sm"></iconify-icon>
                                            </button>
                                        </div>
                                    </template>
                                </div>
                            </div>
                        </template>

                        <!-- Validation Rules for non-button fields -->
                        <template x-if="formSchema[selectedField].type !== 'button'">
                            <div class="cf:p-3">
                                <label class="cf:block cf:text-xs cf:font-medium cf:text-gray-600 cf:dark:text-gray-400 cf:mb-1">{{ __('Validation Rules') }}</label>
                                <input
                                    type="text"
                                    x-model="formSchema[selectedField].validations"
                                    @input="updateFormSchema()"
                                    placeholder="e.g., min:3|max:255|email"
                                    class="form-control cf:text-sm"
                                >
                                <p class="cf:text-xs cf:text-gray-400 cf:dark:text-gray-500 cf:mt-1">{{ __('Laravel validation rules (pipe-separated)') }}</p>
                            </div>
                        </template>
                    </div>
                </template>
            </div>
        </div>
    </div>
</div>
