@extends('backend.layouts.app')

@section('title')
    {{ $form->title }} | {{ config('app.name') }}
@endsection

@section('admin-content')
<div class="p-4 mx-auto max-w-(--breakpoint-2xl) md:p-6">
    <x-breadcrumbs :breadcrumbs="$breadcrumbs" />

    {!! ld_apply_filters('custom_forms_show_after_breadcrumbs', '') !!}

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Main Content -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Form Details Card -->
            <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
                <div class="px-5 py-4 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-800 dark:text-white">{{ $form->title }}</h3>
                        @if($form->description)
                            <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">{{ $form->description }}</p>
                        @endif
                    </div>
                    <div class="flex items-center gap-2">
                        @if($form->is_active)
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">
                                <span class="w-1.5 h-1.5 mr-1.5 rounded-full bg-green-500"></span>
                                {{ __('Active') }}
                            </span>
                        @else
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400">
                                <span class="w-1.5 h-1.5 mr-1.5 rounded-full bg-red-500"></span>
                                {{ __('Inactive') }}
                            </span>
                        @endif
                    </div>
                </div>

                <div class="p-5">
                    <!-- Form Info Grid -->
                    <dl class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-4">
                            <dt class="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{{ __('Slug') }}</dt>
                            <dd class="mt-1 text-sm text-gray-900 dark:text-white font-mono">{{ $form->slug }}</dd>
                        </div>
                        <div class="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-4">
                            <dt class="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{{ __('Total Submissions') }}</dt>
                            <dd class="mt-1 text-2xl font-semibold text-primary">{{ number_format($form->submissions()->count()) }}</dd>
                        </div>
                        <div class="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-4">
                            <dt class="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{{ __('Created At') }}</dt>
                            <dd class="mt-1 text-sm text-gray-900 dark:text-white">{{ $form->created_at->format('M d, Y H:i') }}</dd>
                        </div>
                        <div class="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-4">
                            <dt class="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{{ __('Last Updated') }}</dt>
                            <dd class="mt-1 text-sm text-gray-900 dark:text-white">{{ $form->updated_at->format('M d, Y H:i') }}</dd>
                        </div>
                    </dl>

                    <!-- Form URL -->
                    <div class="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                        <dt class="text-xs font-medium text-blue-600 dark:text-blue-400 uppercase tracking-wider mb-2">{{ __('Public Form URL') }}</dt>
                        <div class="flex items-center gap-2">
                            <input
                                type="text"
                                readonly
                                value="{{ route('forms.render', $form->slug) }}"
                                class="flex-1 text-sm text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2"
                                id="form-url"
                            >
                            <button
                                type="button"
                                onclick="navigator.clipboard.writeText(document.getElementById('form-url').value); this.innerHTML = '<iconify-icon icon=\'lucide:check\' class=\'w-5 h-5\'></iconify-icon>'; setTimeout(() => this.innerHTML = '<iconify-icon icon=\'lucide:copy\' class=\'w-5 h-5\'></iconify-icon>', 2000)"
                                class="flex p-2 text-gray-600 dark:text-gray-400 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                                title="{{ __('Copy URL') }}"
                            >
                                <iconify-icon icon="lucide:copy" class="w-5 h-5"></iconify-icon>
                            </button>
                            <a
                                href="{{ route('forms.render', $form->slug) }}"
                                target="_blank"
                                class="flex p-2 text-primary bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                                title="{{ __('Open Form') }}"
                            >
                                <iconify-icon icon="lucide:external-link" class="w-5 h-5"></iconify-icon>
                            </a>
                        </div>
                    </div>

                    <!-- Livewire Embed Code -->
                    @php
                        $livewireEmbedCode = '<livewire:customform::components.form-submission :id="' . $form->id . '" />';
                    @endphp
                    <div class="mt-4 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg" x-data="{ copied: false }">
                        <dt class="text-xs font-medium text-purple-600 dark:text-purple-400 uppercase tracking-wider mb-2">{{ __('Livewire Embed Code') }}</dt>
                        <p class="text-xs text-gray-500 dark:text-gray-400 mb-2">{{ __('Use this code to embed the form in your Laravel/Livewire application.') }}</p>
                        <div class="flex items-center gap-2">
                            <input
                                type="text"
                                readonly
                                value="{{ $livewireEmbedCode }}"
                                class="flex-1 text-sm text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2 font-mono"
                                id="livewire-embed-code"
                            >
                            <button
                                type="button"
                                x-on:click="navigator.clipboard.writeText('{{ $livewireEmbedCode }}'); copied = true; setTimeout(() => copied = false, 2000)"
                                class="flex p-2 text-gray-600 dark:text-gray-400 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                                title="{{ __('Copy Embed Code') }}"
                            >
                                <template x-if="!copied">
                                    <iconify-icon icon="lucide:copy" class="w-5 h-5"></iconify-icon>
                                </template>
                                <template x-if="copied">
                                    <iconify-icon icon="lucide:check" class="w-5 h-5 text-green-500"></iconify-icon>
                                </template>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Form Fields Preview -->
            <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
                <div class="px-5 py-4 border-b border-gray-100 dark:border-gray-800">
                    <h3 class="text-base font-semibold text-gray-800 dark:text-white">{{ __('Form Fields') }}</h3>
                </div>
                <div class="p-5">
                    @if(is_array($form->form_schema) && count($form->form_schema) > 0)
                        <div class="space-y-3">
                            @foreach($form->form_schema as $index => $field)
                                <div class="flex items-center gap-4 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                                    <span class="w-6 h-6 flex items-center justify-center bg-gray-200 dark:bg-gray-700 rounded text-xs font-medium text-gray-600 dark:text-gray-400">
                                        {{ $index + 1 }}
                                    </span>
                                    <iconify-icon
                                        icon="{{ match($field['type'] ?? 'text') {
                                            'text' => 'lucide:type',
                                            'email' => 'lucide:mail',
                                            'number' => 'lucide:hash',
                                            'textarea' => 'lucide:align-left',
                                            'select' => 'lucide:chevron-down',
                                            'radio' => 'lucide:circle-dot',
                                            'checkbox' => 'lucide:check-square',
                                            'button' => 'lucide:mouse-pointer-click',
                                            default => 'lucide:input'
                                        } }}"
                                        class="w-5 h-5 text-gray-400"
                                    ></iconify-icon>
                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-medium text-gray-900 dark:text-white truncate">
                                            {{ $field['label'] ?? $field['name'] ?? __('Unknown Field') }}
                                        </p>
                                        <p class="text-xs text-gray-500 dark:text-gray-400">
                                            {{ ucfirst($field['type'] ?? 'text') }}
                                            @if($field['required'] ?? false)
                                                <span class="text-red-500 ml-1">{{ __('Required') }}</span>
                                            @endif
                                        </p>
                                    </div>
                                    @if(($field['type'] ?? '') !== 'button')
                                        <span class="text-xs text-gray-400 dark:text-gray-500 font-mono">{{ $field['name'] ?? '' }}</span>
                                    @endif
                                </div>
                            @endforeach
                        </div>
                    @else
                        <div class="text-center py-8">
                            <iconify-icon icon="lucide:file-x" class="w-12 h-12 text-gray-300 dark:text-gray-600 mb-3"></iconify-icon>
                            <p class="text-gray-500 dark:text-gray-400">{{ __('No fields configured') }}</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="lg:col-span-1 space-y-6">
            <!-- Quick Actions Card -->
            <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
                <div class="px-4 py-3 border-b border-gray-100 dark:border-gray-800">
                    <h3 class="text-sm font-semibold text-gray-800 dark:text-white">{{ __('Quick Actions') }}</h3>
                </div>
                <div class="p-4 space-y-3">
                    <a
                        href="{{ route('admin.custom-forms.submissions.index', $form->id) }}"
                        class="flex items-center gap-3 w-full px-4 py-3 text-left text-sm font-medium text-white bg-primary rounded-lg hover:bg-primary/90 transition-colors"
                    >
                        <iconify-icon icon="lucide:inbox" class="w-5 h-5"></iconify-icon>
                        <div>
                            <span class="block">{{ __('View Submissions') }}</span>
                            <span class="text-xs text-white/70">{{ number_format($form->submissions()->count()) }} {{ __('total') }}</span>
                        </div>
                    </a>
                    <a
                        href="{{ route('admin.custom-forms.edit', $form->id) }}"
                        class="flex items-center gap-3 w-full px-4 py-3 text-left text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
                    >
                        <iconify-icon icon="lucide:edit-2" class="w-5 h-5"></iconify-icon>
                        {{ __('Edit Form') }}
                    </a>
                    <a
                        href="{{ route('forms.render', $form->slug) }}"
                        target="_blank"
                        class="flex items-center gap-3 w-full px-4 py-3 text-left text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
                    >
                        <iconify-icon icon="lucide:external-link" class="w-5 h-5"></iconify-icon>
                        {{ __('Preview Form') }}
                    </a>
                    <a
                        href="{{ route('admin.custom-forms.submissions.export', $form->id) }}"
                        class="flex items-center gap-3 w-full px-4 py-3 text-left text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
                    >
                        <iconify-icon icon="lucide:download" class="w-5 h-5"></iconify-icon>
                        {{ __('Export Submissions') }}
                    </a>
                </div>
            </div>

            <!-- Embed Code Card -->
            <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
                <div class="px-4 py-3 border-b border-gray-100 dark:border-gray-800">
                    <h3 class="text-sm font-semibold text-gray-800 dark:text-white">{{ __('Embed Code') }}</h3>
                </div>
                <div class="p-4">
                    <p class="text-xs text-gray-500 dark:text-gray-400 mb-3">{{ __('Copy and paste this code to embed the form on your website.') }}</p>
                    <div class="relative">
                        <pre class="text-xs text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-900/50 rounded-lg p-3 overflow-x-auto" id="embed-code">&lt;iframe src="{{ route('forms.render', $form->slug) }}" width="100%" height="600" frameborder="0"&gt;&lt;/iframe&gt;</pre>
                        <button
                            type="button"
                            onclick="navigator.clipboard.writeText(document.getElementById('embed-code').textContent); this.innerHTML = '<iconify-icon icon=\'lucide:check\' class=\'w-4 h-4\'></iconify-icon>'; setTimeout(() => this.innerHTML = '<iconify-icon icon=\'lucide:copy\' class=\'w-4 h-4\'></iconify-icon>', 2000)"
                            class="absolute top-2 right-2 p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 bg-white dark:bg-gray-800 rounded border border-gray-200 dark:border-gray-700 transition-colors"
                            title="{{ __('Copy') }}"
                        >
                            <iconify-icon icon="lucide:copy" class="w-4 h-4"></iconify-icon>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Created By Card -->
            @if($form->creator)
            <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
                <div class="px-4 py-3 border-b border-gray-100 dark:border-gray-800">
                    <h3 class="text-sm font-semibold text-gray-800 dark:text-white">{{ __('Created By') }}</h3>
                </div>
                <div class="p-4 flex items-center gap-3">
                    <div class="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <span class="text-base font-medium text-primary">{{ substr($form->creator->full_name, 0, 1) }}</span>
                    </div>
                    <div>
                        <p class="text-sm font-medium text-gray-900 dark:text-white">{{ $form->creator->full_name }}</p>
                        <p class="text-xs text-gray-500 dark:text-gray-400">{{ $form->created_at->diffForHumans() }}</p>
                    </div>
                </div>
            </div>
            @endif
        </div>
    </div>
</div>
@endsection
