@extends('backend.layouts.app')

@section('title')
    {{ __('Submissions') }} - {{ $form->title }} | {{ config('app.name') }}
@endsection

@section('admin-content')
<div class="p-4 mx-auto max-w-(--breakpoint-2xl) md:p-6">
    <x-breadcrumbs :breadcrumbs="$breadcrumbs" />

    <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <!-- Left Column - Form Preview & Stats -->
        <div class="lg:col-span-1 space-y-6">
            <!-- Form Preview Card -->
            <x-card.card class="rounded-2xl" bodyClass="p-4 space-y-4">
                <x-slot name="header">
                    <span class="text-sm">{{ __('Form Preview') }}</span>
                </x-slot>

                <!-- Form Title & Status -->
                <div>
                    <h4 class="text-base font-medium text-gray-900 dark:text-white">{{ $form->title }}</h4>
                    @if($form->description)
                        <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">{{ $form->description }}</p>
                    @endif
                </div>

                <!-- Status Badge -->
                <div class="flex items-center gap-2">
                    @if($form->is_active)
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">
                            <span class="w-1.5 h-1.5 mr-1.5 rounded-full bg-green-500"></span>
                            {{ __('Active') }}
                        </span>
                    @else
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400">
                            <span class="w-1.5 h-1.5 mr-1.5 rounded-full bg-red-500"></span>
                            {{ __('Inactive') }}
                        </span>
                    @endif
                </div>

                <!-- Form Fields Preview -->
                <div class="border-t border-gray-100 dark:border-gray-800 pt-4">
                    <h5 class="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">{{ __('Form Fields') }}</h5>
                    <div class="space-y-2">
                        @if(is_array($form->form_schema))
                            @foreach($form->form_schema as $field)
                                @if(($field['type'] ?? '') !== 'button')
                                    <div class="flex items-center gap-2 text-sm">
                                        <iconify-icon
                                            icon="{{ match($field['type'] ?? 'text') {
                                                'text' => 'lucide:type',
                                                'email' => 'lucide:mail',
                                                'number' => 'lucide:hash',
                                                'textarea' => 'lucide:align-left',
                                                'select' => 'lucide:chevron-down',
                                                'radio' => 'lucide:circle-dot',
                                                'checkbox' => 'lucide:check-square',
                                                default => 'lucide:input'
                                            } }}"
                                            class="w-4 h-4 text-gray-400"
                                        ></iconify-icon>
                                        <span class="text-gray-700 dark:text-gray-300">{{ $field['label'] ?? $field['name'] ?? __('Unknown') }}</span>
                                        @if($field['required'] ?? false)
                                            <span class="text-red-500 text-xs">*</span>
                                        @endif
                                    </div>
                                @endif
                            @endforeach
                        @else
                            <p class="text-sm text-gray-400 dark:text-gray-500 italic">{{ __('No fields configured') }}</p>
                        @endif
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="border-t border-gray-100 dark:border-gray-800 pt-4 space-y-2">
                    <a
                        href="{{ route('forms.render', $form->slug) }}"
                        target="_blank"
                        class="btn-primary w-full"
                    >
                        <iconify-icon icon="lucide:external-link" class="w-4 h-4"></iconify-icon>
                        {{ __('View Live Form') }}
                    </a>
                    <a
                        href="{{ route('admin.custom-forms.edit', $form->id) }}"
                        class="btn-default w-full"
                    >
                        <iconify-icon icon="lucide:edit-2" class="w-4 h-4"></iconify-icon>
                        {{ __('Edit Form') }}
                    </a>
                </div>
            </x-card.card>

            <!-- Statistics Card -->
            <x-card.card class="rounded-2xl" bodyClass="p-4">
                <x-slot name="header">
                    <span class="text-sm">{{ __('Statistics') }}</span>
                </x-slot>

                <dl class="grid grid-cols-2 gap-4">
                    <div class="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-3 text-center">
                        <dt class="text-xs text-gray-500 dark:text-gray-400">{{ __('Total') }}</dt>
                        <dd class="text-2xl font-semibold text-gray-900 dark:text-white">{{ number_format($statistics['total']) }}</dd>
                    </div>
                    <div class="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 text-center">
                        <dt class="text-xs text-blue-600 dark:text-blue-400">{{ __('Today') }}</dt>
                        <dd class="text-2xl font-semibold text-blue-700 dark:text-blue-300">{{ number_format($statistics['today']) }}</dd>
                    </div>
                    <div class="bg-green-50 dark:bg-green-900/20 rounded-lg p-3 text-center">
                        <dt class="text-xs text-green-600 dark:text-green-400">{{ __('This Week') }}</dt>
                        <dd class="text-2xl font-semibold text-green-700 dark:text-green-300">{{ number_format($statistics['this_week']) }}</dd>
                    </div>
                    <div class="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-3 text-center">
                        <dt class="text-xs text-purple-600 dark:text-purple-400">{{ __('This Month') }}</dt>
                        <dd class="text-2xl font-semibold text-purple-700 dark:text-purple-300">{{ number_format($statistics['this_month']) }}</dd>
                    </div>
                </dl>

                <div class="mt-4 pt-4 border-t border-gray-100 dark:border-gray-800">
                    <div class="flex justify-between items-center text-sm">
                        <span class="text-gray-500 dark:text-gray-400">{{ __('Authenticated') }}</span>
                        <span class="font-medium text-gray-900 dark:text-white">{{ number_format($statistics['authenticated_users']) }}</span>
                    </div>
                    <div class="flex justify-between items-center text-sm mt-2">
                        <span class="text-gray-500 dark:text-gray-400">{{ __('Anonymous') }}</span>
                        <span class="font-medium text-gray-900 dark:text-white">{{ number_format($statistics['anonymous']) }}</span>
                    </div>
                </div>
            </x-card.card>
        </div>

        <!-- Right Column - Submissions Datatable -->
        <div class="lg:col-span-3">
            <livewire:customform::components.submission-datatable :formId="$form->id" lazy />
        </div>
    </div>
</div>
@endsection
