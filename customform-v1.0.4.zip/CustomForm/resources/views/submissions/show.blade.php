@extends('backend.layouts.app')

@section('title')
    {{ __('Submission #:id', ['id' => $submission->id]) }} | {{ config('app.name') }}
@endsection

@section('admin-content')
<div class="p-4 mx-auto max-w-(--breakpoint-2xl) md:p-6">
    <x-breadcrumbs :breadcrumbs="$breadcrumbs" />

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Main Content - Submission Data -->
        <div class="lg:col-span-2">
            <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
                <div class="px-5 py-4 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-800 dark:text-white">{{ __('Submission Details') }}</h3>
                        <p class="text-sm text-gray-500 dark:text-gray-400">{{ __('Submitted on :date', ['date' => $submission->created_at->format('F d, Y \a\t H:i:s')]) }}</p>
                    </div>
                    <div class="flex items-center gap-2">
                        @can('custom_form.delete')
                        <form action="{{ route('admin.custom-forms.submissions.destroy', ['form' => $form->id, 'submission' => $submission->id]) }}" method="POST" class="inline" onsubmit="return confirm('{{ __('Are you sure you want to delete this submission?') }}')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors">
                                <iconify-icon icon="lucide:trash-2" class="w-4 h-4"></iconify-icon>
                                {{ __('Delete') }}
                            </button>
                        </form>
                        @endcan
                    </div>
                </div>

                <div class="p-5">
                    <!-- Submission Fields -->
                    <div class="space-y-6">
                        @if(is_array($form->form_schema))
                            @foreach($form->form_schema as $field)
                                @if(($field['type'] ?? '') !== 'button')
                                    @php
                                        $fieldName = $field['name'] ?? '';
                                        $fieldLabel = $field['label'] ?? $fieldName;
                                        $fieldValue = $submission->submission_data[$fieldName] ?? null;
                                    @endphp
                                    <div class="border-b border-gray-100 dark:border-gray-800 pb-4 last:border-0 last:pb-0">
                                        <dt class="flex items-center gap-2 text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
                                            <iconify-icon
                                                icon="{{ match($field['type'] ?? 'text') {
                                                    'text' => 'lucide:type',
                                                    'email' => 'lucide:mail',
                                                    'number' => 'lucide:hash',
                                                    'textarea' => 'lucide:align-left',
                                                    'select' => 'lucide:chevron-down',
                                                    'radio' => 'lucide:circle-dot',
                                                    'checkbox' => 'lucide:check-square',
                                                    default => 'lucide:input'
                                                } }}"
                                                class="w-4 h-4"
                                            ></iconify-icon>
                                            {{ $fieldLabel }}
                                            @if($field['required'] ?? false)
                                                <span class="text-xs text-red-500">*</span>
                                            @endif
                                        </dt>
                                        <dd class="mt-1">
                                            @if(is_null($fieldValue) || $fieldValue === '')
                                                <span class="text-sm text-gray-400 dark:text-gray-500 italic">{{ __('No value provided') }}</span>
                                            @elseif(is_array($fieldValue))
                                                <div class="flex flex-wrap gap-1">
                                                    @foreach($fieldValue as $val)
                                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200">
                                                            {{ $val }}
                                                        </span>
                                                    @endforeach
                                                </div>
                                            @elseif(($field['type'] ?? '') === 'textarea')
                                                <div class="text-sm text-gray-900 dark:text-white bg-gray-50 dark:bg-gray-800/50 rounded-lg p-3 whitespace-pre-wrap">{{ $fieldValue }}</div>
                                            @elseif(($field['type'] ?? '') === 'email')
                                                <a href="mailto:{{ $fieldValue }}" class="text-sm text-primary hover:underline">{{ $fieldValue }}</a>
                                            @else
                                                <span class="text-sm text-gray-900 dark:text-white">{{ $fieldValue }}</span>
                                            @endif
                                        </dd>
                                    </div>
                                @endif
                            @endforeach
                        @else
                            <!-- Fallback for unstructured data -->
                            @if(is_array($submission->submission_data))
                                @foreach($submission->submission_data as $key => $value)
                                    <div class="border-b border-gray-100 dark:border-gray-800 pb-4 last:border-0 last:pb-0">
                                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">{{ $key }}</dt>
                                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">
                                            @if(is_array($value))
                                                <pre class="bg-gray-50 dark:bg-gray-800/50 p-2 rounded text-xs overflow-x-auto">{{ json_encode($value, JSON_PRETTY_PRINT) }}</pre>
                                            @else
                                                {{ $value }}
                                            @endif
                                        </dd>
                                    </div>
                                @endforeach
                            @endif
                        @endif
                    </div>
                </div>
            </div>

            <!-- Raw Data (Collapsible) -->
            <div class="mt-6 rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]" x-data="{ open: false }">
                <button
                    type="button"
                    @click="open = !open"
                    class="w-full px-5 py-4 flex items-center justify-between text-left"
                >
                    <h3 class="text-sm font-medium text-gray-700 dark:text-gray-300">{{ __('Raw JSON Data') }}</h3>
                    <iconify-icon
                        :icon="open ? 'lucide:chevron-up' : 'lucide:chevron-down'"
                        class="w-5 h-5 text-gray-400"
                    ></iconify-icon>
                </button>
                <div x-show="open" x-collapse class="border-t border-gray-100 dark:border-gray-800">
                    <pre class="p-4 text-xs text-gray-600 dark:text-gray-400 overflow-x-auto bg-gray-50 dark:bg-gray-900/50">{{ json_encode($submission->submission_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) }}</pre>
                </div>
            </div>
        </div>

        <!-- Sidebar - Meta Information -->
        <div class="lg:col-span-1 space-y-6">
            <!-- Form Info Card -->
            <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
                <div class="px-4 py-3 border-b border-gray-100 dark:border-gray-800">
                    <h3 class="text-sm font-semibold text-gray-800 dark:text-white">{{ __('Form') }}</h3>
                </div>
                <div class="p-4">
                    <h4 class="font-medium text-gray-900 dark:text-white">{{ $form->title }}</h4>
                    <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">{{ $form->slug }}</p>
                    <div class="mt-3">
                        <a
                            href="{{ route('admin.custom-forms.submissions.index', $form->id) }}"
                            class="inline-flex items-center gap-1.5 text-sm text-primary hover:underline"
                        >
                            <iconify-icon icon="lucide:arrow-left" class="w-4 h-4"></iconify-icon>
                            {{ __('Back to all submissions') }}
                        </a>
                    </div>
                </div>
            </div>

            <!-- Submission Meta Card -->
            <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
                <div class="px-4 py-3 border-b border-gray-100 dark:border-gray-800">
                    <h3 class="text-sm font-semibold text-gray-800 dark:text-white">{{ __('Submission Info') }}</h3>
                </div>
                <div class="p-4 space-y-4">
                    <!-- ID -->
                    <div>
                        <dt class="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{{ __('Submission ID') }}</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white font-mono">#{{ $submission->id }}</dd>
                    </div>

                    <!-- User -->
                    <div>
                        <dt class="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{{ __('Submitted By') }}</dt>
                        <dd class="mt-1 flex items-center gap-2">
                            @if($submission->user)
                                <div class="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                                    <span class="text-sm font-medium text-primary">{{ substr($submission->user->full_name, 0, 1) }}</span>
                                </div>
                                <div>
                                    <p class="text-sm font-medium text-gray-900 dark:text-white">{{ $submission->user->name }}</p>
                                    <p class="text-xs text-gray-500 dark:text-gray-400">{{ $submission->user->email }}</p>
                                </div>
                            @else
                                <span class="text-sm text-gray-500 dark:text-gray-400 italic">{{ __('Anonymous') }}</span>
                            @endif
                        </dd>
                    </div>

                    <!-- Timestamps -->
                    <div>
                        <dt class="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{{ __('Submitted At') }}</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">
                            {{ $submission->created_at->format('M d, Y') }}
                            <span class="text-gray-500 dark:text-gray-400">{{ __('at') }}</span>
                            {{ $submission->created_at->format('H:i:s') }}
                        </dd>
                        <dd class="text-xs text-gray-500 dark:text-gray-400">{{ $submission->created_at->diffForHumans() }}</dd>
                    </div>

                    <!-- IP Address -->
                    <div>
                        <dt class="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{{ __('IP Address') }}</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white font-mono">{{ $submission->ip_address ?? '-' }}</dd>
                    </div>

                    <!-- User Agent -->
                    <div>
                        <dt class="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{{ __('User Agent') }}</dt>
                        <dd class="mt-1 text-xs text-gray-600 dark:text-gray-400 break-all">{{ $submission->user_agent ?? '-' }}</dd>
                    </div>
                </div>
            </div>

            <!-- Navigation -->
            <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03] p-4">
                <div class="flex items-center justify-between gap-4">
                    @php
                        $prevSubmission = \Modules\CustomForm\Models\CustomFormSubmission::where('form_id', $form->id)
                            ->where('id', '<', $submission->id)
                            ->orderBy('id', 'desc')
                            ->first();
                        $nextSubmission = \Modules\CustomForm\Models\CustomFormSubmission::where('form_id', $form->id)
                            ->where('id', '>', $submission->id)
                            ->orderBy('id', 'asc')
                            ->first();
                    @endphp

                    @if($prevSubmission)
                        <a
                            href="{{ route('admin.custom-forms.submissions.show', ['form' => $form->id, 'submission' => $prevSubmission->id]) }}"
                            class="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
                        >
                            <iconify-icon icon="lucide:chevron-left" class="w-4 h-4"></iconify-icon>
                            {{ __('Previous') }}
                        </a>
                    @else
                        <span class="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-gray-400 dark:text-gray-600 bg-gray-100 dark:bg-gray-800 rounded-lg cursor-not-allowed">
                            <iconify-icon icon="lucide:chevron-left" class="w-4 h-4"></iconify-icon>
                            {{ __('Previous') }}
                        </span>
                    @endif

                    @if($nextSubmission)
                        <a
                            href="{{ route('admin.custom-forms.submissions.show', ['form' => $form->id, 'submission' => $nextSubmission->id]) }}"
                            class="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
                        >
                            {{ __('Next') }}
                            <iconify-icon icon="lucide:chevron-right" class="w-4 h-4"></iconify-icon>
                        </a>
                    @else
                        <span class="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-gray-400 dark:text-gray-600 bg-gray-100 dark:bg-gray-800 rounded-lg cursor-not-allowed">
                            {{ __('Next') }}
                            <iconify-icon icon="lucide:chevron-right" class="w-4 h-4"></iconify-icon>
                        </span>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
