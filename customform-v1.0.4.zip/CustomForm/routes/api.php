<?php

use Illuminate\Support\Facades\Route;
use Modules\CustomForm\Http\Controllers\Api\FormApiController;
use Modules\CustomForm\Http\Controllers\CustomFormController;

Route::middleware(['auth:sanctum'])->prefix('v1')->group(function () {
    Route::apiResource('customforms', CustomFormController::class)->names('customform');
});

// Custom Forms API for LaraBuilder blocks (requires web auth)
Route::middleware(['web', 'auth'])->prefix('customform')->group(function () {
    Route::get('forms', [FormApiController::class, 'index'])
        ->name('customform.api.forms.index');
    Route::get('forms/{id}', [FormApiController::class, 'show'])
        ->name('customform.api.forms.show');
});
