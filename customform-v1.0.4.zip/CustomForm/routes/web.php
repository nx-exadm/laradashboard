<?php

use Illuminate\Support\Facades\Route;
use Modules\CustomForm\Http\Controllers\CustomFormController;
use Modules\CustomForm\Http\Controllers\CustomFormSubmissionController;

// Admin routes
Route::middleware(['auth', 'verified'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {
        // Form CRUD
        Route::resource('custom-forms', CustomFormController::class)->names('custom-forms');
        Route::delete('custom-forms/delete/bulk-delete', [CustomFormController::class, 'bulkDelete'])->name('custom-forms.bulk-delete');

        // Submission management
        Route::prefix('custom-forms/{form}')
            ->name('custom-forms.submissions.')
            ->group(function () {
                Route::get('submissions', [CustomFormSubmissionController::class, 'index'])->name('index');
                Route::get('submissions/export', [CustomFormSubmissionController::class, 'export'])->name('export');
                Route::get('submissions/{submission}', [CustomFormSubmissionController::class, 'show'])->name('show');
                Route::delete('submissions/{submission}', [CustomFormSubmissionController::class, 'destroy'])->name('destroy');
                Route::delete('submissions/bulk-delete', [CustomFormSubmissionController::class, 'bulkDelete'])->name('bulk-delete');
            });
    });

// Frontend routes
Route::prefix('forms')
    ->name('forms.')
    ->group(function () {
        Route::get('{slug}', [CustomFormController::class, 'renderForm'])->name('render');
        Route::post('{form_id}/submit', [CustomFormController::class, 'submitForm'])->name('submit');
    });
