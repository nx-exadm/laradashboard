import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Determine if we're building for distribution (self-contained) or development
const isDistBuild = process.env.MODULE_DIST_BUILD === 'true';

// For distribution: build inside module directory (self-contained ZIP)
// For development: build to public directory (hot reload works)
const distOutDir = path.resolve(__dirname, 'dist/build-customform');
const devOutDir = path.resolve(__dirname, '../../public/build-customform');

export default defineConfig({
    build: {
        outDir: isDistBuild ? distOutDir : devOutDir,
        emptyOutDir: true,
        // Place manifest at root level (not in .vite/) for Laravel compatibility
        manifest: 'manifest.json',
    },
    plugins: [
        laravel({
            publicDirectory: isDistBuild ? path.resolve(__dirname, 'dist') : path.resolve(__dirname, '../../public'),
            buildDirectory: 'build-customform',
            input: [
                path.resolve(__dirname, 'resources/assets/css/app.css'),
                path.resolve(__dirname, 'resources/assets/js/app.js'),
                path.resolve(__dirname, 'resources/js/lara-builder-blocks/customform-embed/index.js'),
            ],
            refresh: true,
        }),
        react({
            // Use the classic runtime so we can alias React imports
            jsxRuntime: 'classic',
        }),
        tailwindcss({
            // Module-specific Tailwind config
        }),
    ],
    resolve: {
        alias: [
            // LaraBuilder aliases - more specific aliases must come first
            { find: '@lara-builder/utils', replacement: path.resolve(__dirname, '../../resources/js/lara-builder/utils') },
            { find: '@lara-builder/blocks', replacement: path.resolve(__dirname, '../../resources/js/lara-builder/blocks') },
            { find: '@lara-builder', replacement: path.resolve(__dirname, '../../resources/js/lara-builder') },
            // Module-specific aliases
            { find: '~', replacement: path.resolve(__dirname, 'node_modules') },
            // Alias react imports to use window.React via shims
            { find: 'react', replacement: path.resolve(__dirname, 'resources/js/lara-builder-blocks/react-shim.js') },
            { find: 'react-dom', replacement: path.resolve(__dirname, 'resources/js/lara-builder-blocks/react-dom-shim.js') },
        ],
    },
});
