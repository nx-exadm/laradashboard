/**
 * Custom Form Embed Block Component
 *
 * Displays a custom form from the CustomForm module.
 * Self-contained block that can be registered with LaraBuilder.
 */

// Import React from shim (resolves to window.React via alias)
import React from 'react';

const CustomFormEmbedBlock = ({ props, isSelected }) => {
    // Destructure hooks inside the function to ensure React is available
    const { useState, useEffect } = React;

    const [form, setForm] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    // Fetch form data when formId changes
    useEffect(() => {
        if (props.formId) {
            fetchForm(props.formId);
        } else {
            setForm(null);
        }
    }, [props.formId]);

    const fetchForm = async (id) => {
        setLoading(true);
        setError(null);
        try {
            const response = await fetch(`/api/customform/forms/${id}`);
            if (!response.ok) {
                throw new Error('Form not found');
            }
            const data = await response.json();
            setForm(data.data || data);
        } catch (err) {
            setError(err.message);
            setForm(null);
        } finally {
            setLoading(false);
        }
    };

    // Get alignment style
    const getAlignmentStyle = () => {
        const align = props.align || 'left';
        if (align === 'center') {
            return { marginLeft: 'auto', marginRight: 'auto' };
        } else if (align === 'right') {
            return { marginLeft: 'auto', marginRight: '0' };
        }
        return { marginLeft: '0', marginRight: 'auto' };
    };

    // Styles
    const containerStyle = {
        padding: '20px',
        borderRadius: props.borderRadius || '8px',
        border: `1px solid ${props.borderColor || '#e5e7eb'}`,
        backgroundColor: props.backgroundColor || '#ffffff',
        outline: isSelected ? '2px solid #1e40af' : 'none',
        outlineOffset: '2px',
        maxWidth: '100%',
        ...getAlignmentStyle(),
    };

    const titleStyle = {
        fontSize: props.titleFontSize || '18px',
        fontWeight: '600',
        color: props.titleColor || '#1f2937',
        margin: '0 0 8px 0',
    };

    const descriptionStyle = {
        fontSize: '14px',
        color: '#6b7280',
        margin: '0 0 16px 0',
    };

    const labelStyle = {
        display: 'block',
        fontSize: '14px',
        fontWeight: '500',
        color: props.labelColor || '#374151',
        marginBottom: '4px',
    };

    const inputStyle = {
        width: '100%',
        padding: '8px 12px',
        borderRadius: '6px',
        border: `1px solid ${props.inputBorderColor || '#d1d5db'}`,
        fontSize: '14px',
        backgroundColor: '#ffffff',
        boxSizing: 'border-box',
    };

    const buttonStyle = {
        padding: '10px 20px',
        borderRadius: '6px',
        border: 'none',
        backgroundColor: props.buttonColor || '#1e40af',
        color: props.buttonTextColor || '#ffffff',
        fontSize: '14px',
        fontWeight: '500',
        cursor: 'pointer',
    };

    const fieldWrapperStyle = (width) => ({
        width: width < 100 ? `calc(${width}% - 8px)` : '100%',
        marginBottom: '12px',
        flexShrink: 0,
    });

    // Placeholder when no form selected
    if (!props.formId) {
        return (
            <div style={{ ...containerStyle, textAlign: 'center', padding: '32px' }}>
                <div style={{ marginBottom: '8px' }}>
                    <svg
                        width="48"
                        height="48"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="#9ca3af"
                        strokeWidth="1.5"
                        style={{ margin: '0 auto' }}
                    >
                        <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                </div>
                <p style={{ color: '#6b7280', fontSize: '14px', margin: 0 }}>
                    Select a form to display
                </p>
                {isSelected && (
                    <p style={{ color: '#9ca3af', fontSize: '12px', margin: '8px 0 0 0' }}>
                        Use the properties panel to choose a form
                    </p>
                )}
            </div>
        );
    }

    // Loading state
    if (loading) {
        return (
            <div style={{ ...containerStyle, textAlign: 'center', padding: '32px' }}>
                <div style={{ color: '#6b7280' }}>Loading form...</div>
            </div>
        );
    }

    // Error state
    if (error) {
        return (
            <div style={{ ...containerStyle, textAlign: 'center', padding: '32px', borderColor: '#fca5a5' }}>
                <div style={{ color: '#dc2626' }}>{error}</div>
            </div>
        );
    }

    // No form found
    if (!form) {
        return (
            <div style={{ ...containerStyle, textAlign: 'center', padding: '32px' }}>
                <div style={{ color: '#6b7280' }}>Form not found</div>
            </div>
        );
    }

    // Parse form schema
    const formSchema = form.form_schema || [];

    // Render field preview based on type
    const renderFieldPreview = (field, index) => {
        const fieldWidth = field.width || 100;
        const isRequired = field.required;

        switch (field.type) {
            case 'text':
            case 'email':
            case 'number':
                return (
                    <div key={field.name || index} style={fieldWrapperStyle(fieldWidth)}>
                        <label style={labelStyle}>
                            {field.label}
                            {isRequired && <span style={{ color: '#ef4444', marginLeft: '2px' }}>*</span>}
                        </label>
                        <input
                            type={field.type}
                            placeholder={field.placeholder || `Enter ${field.label.toLowerCase()}`}
                            style={inputStyle}
                            disabled
                        />
                    </div>
                );

            case 'textarea':
                return (
                    <div key={field.name || index} style={fieldWrapperStyle(fieldWidth)}>
                        <label style={labelStyle}>
                            {field.label}
                            {isRequired && <span style={{ color: '#ef4444', marginLeft: '2px' }}>*</span>}
                        </label>
                        <textarea
                            placeholder={field.placeholder || `Enter ${field.label.toLowerCase()}`}
                            rows={3}
                            style={{ ...inputStyle, resize: 'vertical' }}
                            disabled
                        />
                    </div>
                );

            case 'select':
                return (
                    <div key={field.name || index} style={fieldWrapperStyle(fieldWidth)}>
                        <label style={labelStyle}>
                            {field.label}
                            {isRequired && <span style={{ color: '#ef4444', marginLeft: '2px' }}>*</span>}
                        </label>
                        <select style={inputStyle} disabled>
                            <option>{field.placeholder || 'Select an option'}</option>
                            {(field.options || []).map((opt, i) => (
                                <option key={i} value={opt.value}>{opt.label}</option>
                            ))}
                        </select>
                    </div>
                );

            case 'radio':
                return (
                    <div key={field.name || index} style={fieldWrapperStyle(fieldWidth)}>
                        <label style={labelStyle}>
                            {field.label}
                            {isRequired && <span style={{ color: '#ef4444', marginLeft: '2px' }}>*</span>}
                        </label>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px' }}>
                            {(field.options || []).map((opt, i) => (
                                <label key={i} style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '14px', color: props.labelColor || '#374151' }}>
                                    <input type="radio" disabled />
                                    {opt.label}
                                </label>
                            ))}
                        </div>
                    </div>
                );

            case 'checkbox':
                return (
                    <div key={field.name || index} style={fieldWrapperStyle(fieldWidth)}>
                        <label style={labelStyle}>
                            {field.label}
                            {isRequired && <span style={{ color: '#ef4444', marginLeft: '2px' }}>*</span>}
                        </label>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px' }}>
                            {(field.options || []).map((opt, i) => (
                                <label key={i} style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '14px', color: props.labelColor || '#374151' }}>
                                    <input type="checkbox" disabled />
                                    {opt.label}
                                </label>
                            ))}
                        </div>
                    </div>
                );

            case 'button':
                return (
                    <div key={field.name || index} style={{ ...fieldWrapperStyle(fieldWidth), marginTop: '8px' }}>
                        <button
                            type="button"
                            style={{
                                ...buttonStyle,
                                backgroundColor: field.buttonClass === 'btn-secondary' ? '#6b7280' :
                                    field.buttonClass === 'btn-success' ? '#22c55e' :
                                    field.buttonClass === 'btn-danger' ? '#ef4444' :
                                    props.buttonColor || '#1e40af',
                            }}
                            disabled
                        >
                            {field.buttonText || 'Submit'}
                        </button>
                    </div>
                );

            default:
                return null;
        }
    };

    // Check if form has a submit button
    const hasButton = formSchema.some(f => f.type === 'button');

    return (
        <div style={containerStyle}>
            {/* Form Title */}
            {props.showTitle !== false && form.title && (
                <h3 style={titleStyle}>{form.title}</h3>
            )}

            {/* Form Description */}
            {props.showDescription !== false && form.description && (
                <p style={descriptionStyle}>{form.description}</p>
            )}

            {/* Form Fields */}
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                {formSchema.map((field, index) => renderFieldPreview(field, index))}
            </div>

            {/* Default Submit Button if none in schema */}
            {!hasButton && (
                <div style={{ marginTop: '16px' }}>
                    <button type="button" style={buttonStyle} disabled>
                        Submit
                    </button>
                </div>
            )}
        </div>
    );
};

export default CustomFormEmbedBlock;
