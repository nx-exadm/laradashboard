<?php

declare(strict_types=1);

namespace Modules\Forum\Enums;

/**
 * Forum Action Hooks
 *
 * Provides action hooks for Forum layout and content customization.
 * Use these hooks to inject custom navbars, footers, sidebars, and content.
 *
 * @example
 * // Add custom navbar before forum header
 * ld_add_action(ForumActionHook::LAYOUT_BEFORE_HEADER, function () {
 *     echo view('components.frontend-navbar')->render();
 * });
 */
enum ForumActionHook: string
{
    // ==========================================================================
    // Layout Hooks
    // ==========================================================================

    /**
     * Hook at the very beginning of the body tag.
     * Use this to inject content at the top of the page.
     */
    case LAYOUT_BODY_START = 'forum.layout.body_start';

    /**
     * Hook before the forum header/navbar.
     * Perfect for injecting a main site navbar above the forum.
     */
    case LAYOUT_BEFORE_HEADER = 'forum.layout.before_header';

    /**
     * Hook after the forum header/navbar.
     */
    case LAYOUT_AFTER_HEADER = 'forum.layout.after_header';

    /**
     * Hook before the main content area.
     */
    case LAYOUT_BEFORE_CONTENT = 'forum.layout.before_content';

    /**
     * Hook after the main content area.
     */
    case LAYOUT_AFTER_CONTENT = 'forum.layout.after_content';

    /**
     * Hook before the forum footer.
     */
    case LAYOUT_BEFORE_FOOTER = 'forum.layout.before_footer';

    /**
     * Hook after the forum footer.
     * Perfect for injecting a main site footer below the forum.
     */
    case LAYOUT_AFTER_FOOTER = 'forum.layout.after_footer';

    /**
     * Hook at the very end of the body tag.
     */
    case LAYOUT_BODY_END = 'forum.layout.body_end';

    // ==========================================================================
    // Head Hooks
    // ==========================================================================

    /**
     * Hook inside the <head> tag for adding custom styles/scripts.
     */
    case LAYOUT_HEAD = 'forum.layout.head';

    // ==========================================================================
    // Content Hooks
    // ==========================================================================

    /**
     * Hook before the category list on forum index.
     */
    case INDEX_BEFORE_CATEGORIES = 'forum.index.before_categories';

    /**
     * Hook after the category list on forum index.
     */
    case INDEX_AFTER_CATEGORIES = 'forum.index.after_categories';

    /**
     * Hook before the topic list on category page.
     */
    case CATEGORY_BEFORE_TOPICS = 'forum.category.before_topics';

    /**
     * Hook after the topic list on category page.
     */
    case CATEGORY_AFTER_TOPICS = 'forum.category.after_topics';

    /**
     * Hook before the topic content.
     */
    case TOPIC_BEFORE_CONTENT = 'forum.topic.before_content';

    /**
     * Hook after the topic content.
     */
    case TOPIC_AFTER_CONTENT = 'forum.topic.after_content';

    /**
     * Hook before the replies section.
     */
    case TOPIC_BEFORE_REPLIES = 'forum.topic.before_replies';

    /**
     * Hook after the replies section.
     */
    case TOPIC_AFTER_REPLIES = 'forum.topic.after_replies';

    /**
     * Hook before the reply form.
     */
    case TOPIC_BEFORE_REPLY_FORM = 'forum.topic.before_reply_form';

    /**
     * Hook after the reply form.
     */
    case TOPIC_AFTER_REPLY_FORM = 'forum.topic.after_reply_form';
}
