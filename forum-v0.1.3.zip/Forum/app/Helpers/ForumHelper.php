<?php

declare(strict_types=1);

namespace Modules\Forum\Helpers;

class ForumHelper
{
    /**
     * Allowed HTML tags for forum content (from TinyMCE).
     */
    private static array $allowedTags = [
        'p', 'br', 'strong', 'b', 'em', 'i', 'u', 's', 'strike',
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
        'ul', 'ol', 'li',
        'a', 'img', 'video', 'audio', 'source',
        'blockquote', 'pre', 'code',
        'table', 'thead', 'tbody', 'tr', 'th', 'td',
        'div', 'span', 'hr',
    ];

    /**
     * Sanitize and render HTML content from TinyMCE.
     * Preserves safe HTML tags while removing potentially dangerous ones.
     */
    public static function sanitizeHtml(?string $html): string
    {
        if (empty($html)) {
            return '';
        }

        // Build allowed tags string for strip_tags
        $allowedTagsString = '<'.implode('><', self::$allowedTags).'>';

        // Strip disallowed tags but keep allowed ones
        $html = strip_tags($html, $allowedTagsString);

        // Remove any javascript: URLs and event handlers
        $html = preg_replace('/\bon\w+\s*=\s*(["\'])[^"\']*\1/i', '', $html);
        $html = preg_replace('/javascript\s*:/i', '', $html);

        return $html;
    }

    /**
     * Convert URLs in plain text to clickable links.
     * Use this for plain text content only (not HTML from TinyMCE).
     */
    public static function linkify(?string $text): string
    {
        if (empty($text)) {
            return '';
        }

        // Check if content appears to be HTML (from TinyMCE)
        if (preg_match('/<[a-z][\s\S]*>/i', $text)) {
            // Content is HTML, sanitize and return
            return self::sanitizeHtml($text);
        }

        // Plain text - escape HTML to prevent XSS
        $text = e($text);

        // Convert URLs to clickable links
        // Match URLs starting with http://, https://, or www.
        $pattern = '/(https?:\/\/[^\s<]+|www\.[^\s<]+)/i';

        $text = preg_replace_callback($pattern, function ($matches) {
            $url = $matches[0];
            $href = $url;

            // Add http:// if URL starts with www.
            if (str_starts_with(strtolower($url), 'www.')) {
                $href = 'http://'.$url;
            }

            // Truncate display URL if too long
            $displayUrl = strlen($url) > 50 ? substr($url, 0, 47).'...' : $url;

            return '<a href="'.htmlspecialchars($href).'" target="_blank" rel="noopener noreferrer" class="link">'.$displayUrl.'</a>';
        }, $text);

        // Convert newlines to <br> tags
        return nl2br($text);
    }
}
