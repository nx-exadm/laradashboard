<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Admin\Categories;

use Illuminate\Contracts\View\View;
use Illuminate\Support\Str;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Modules\Forum\Models\Category;

#[Layout('forum::layouts.crud')]
class Create extends Component
{
    public string $name = '';

    public string $slug = '';

    public string $description = '';

    public string $icon = 'lucide:folder';

    public string $color = '#6366f1';

    public int $order = 0;

    public bool $is_active = true;

    public array $breadcrumbs = [];

    public function updatedName(string $value): void
    {
        if (empty($this->slug)) {
            $this->slug = Str::slug($value);
        }
    }

    public function mount(): void
    {
        $this->breadcrumbs = [
            'title' => __('Create Category'),
            'icon' => 'lucide:list',
            'back_url' => route('admin.forum.categories.index'),
        ];
    }

    protected function rules(): array
    {
        return [
            'name' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:forum_categories,slug',
            'description' => 'nullable|string|max:1000',
            'icon' => 'nullable|string|max:100',
            'color' => 'nullable|string|max:50',
            'order' => 'required|integer|min:0',
            'is_active' => 'nullable|boolean',
        ];
    }

    protected function messages(): array
    {
        return [
            'slug.unique' => __('This slug is already taken. Please use a different one.'),
        ];
    }

    public function save(): void
    {
        $validated = $this->validate();

        $item = Category::create([
            'name' => $validated['name'],
            'slug' => $validated['slug'],
            'description' => $validated['description'],
            'icon' => $validated['icon'],
            'color' => $validated['color'],
            'order' => $validated['order'],
            'is_active' => $validated['is_active'],
        ]);

        session()->flash('success', __('Category created successfully.'));

        $this->redirect(route('admin.forum.categories.edit', $item), navigate: true);
    }


    public function render(): View
    {
        return view('forum::livewire.admin.categories.create');
    }
}
