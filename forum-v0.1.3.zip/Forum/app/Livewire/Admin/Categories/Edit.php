<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Admin\Categories;

use Illuminate\Contracts\View\View;
use Livewire\Attributes\Layout;
use Livewire\Component;

use Modules\Forum\Models\Category;

#[Layout('forum::layouts.crud')]
class Edit extends Component
{

    public Category $category;

    public string $name = '';

    public string $slug = '';

    public string $description = '';

    public string $icon = '';

    public string $color = '';

    public int $order = 0;

    public bool $is_active = false;

    public array $breadcrumbs = [];

    protected function rules(): array
    {
        return [
            'name' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:forum_categories,slug,'.$this->category->id,
            'description' => 'nullable|string|max:1000',
            'icon' => 'nullable|string|max:100',
            'color' => 'nullable|string|max:50',
            'order' => 'required|integer|min:0',
            'is_active' => 'nullable|boolean',
        ];
    }

    protected function messages(): array
    {
        return [
            'slug.unique' => __('This slug is already taken. Please use a different one.'),
        ];
    }

    public function mount(Category $category): void
    {
        $this->category = $category;
        $this->name = $this->category->name ?? '';
        $this->slug = $this->category->slug ?? '';
        $this->description = $this->category->description ?? '';
        $this->icon = $this->category->icon ?? '';
        $this->color = $this->category->color ?? '';
        $this->order = (int) ($this->category->order ?? 0);
        $this->is_active = (bool) $this->category->is_active;

        $this->breadcrumbs = [
            'title' => __('Edit Category'),
            'icon' => 'lucide:list',
            'back_url' => route('admin.forum.categories.index'),
            'action' => [
                'url' => route('admin.forum.categories.show', $this->category),
                'label' => __('View'),
                'icon' => 'lucide:eye',
            ],
        ];
    }

    public function save(): void
    {
        $validated = $this->validate();

        $this->category->update([
            'name' => $validated['name'],
            'slug' => $validated['slug'],
            'description' => $validated['description'],
            'icon' => $validated['icon'],
            'color' => $validated['color'],
            'order' => $validated['order'],
            'is_active' => $validated['is_active'],
        ]);

        session()->flash('success', __('Category updated successfully.'));
    }

    public function delete(): void
    {
        $this->category->delete();

        session()->flash('success', __('Category deleted successfully.'));

        $this->redirect(route('admin.forum.categories.index'), navigate: true);
    }


    public function render(): View
    {
        return view('forum::livewire.admin.categories.edit');
    }
}
