<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Admin\Categories;

use Illuminate\Contracts\View\View;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Modules\Forum\Models\Category;
use Modules\Forum\Models\Topic;

#[Layout('forum::layouts.crud')]
class Index extends Component
{
    public array $breadcrumbs = [];

    public function mount(): void
    {
        $this->breadcrumbs = [
            'title' => __('Categories'),
            'icon' => 'lucide:folders',
            'action' => [
                'url' => route('admin.forum.categories.create'),
                'label' => __('New Category'),
                'icon' => 'lucide:plus',
            ],
        ];
    }

    public function render(): View
    {
        return view('forum::livewire.admin.categories.index', [
            'stats' => $this->getStats(),
        ]);
    }

    protected function getStats(): array
    {
        return [
            [
                'label' => __('Total Categories'),
                'value' => Category::count(),
                'icon' => 'lucide:folders',
                'color' => 'primary',
            ],
            [
                'label' => __('Active Categories'),
                'value' => Category::where('is_active', true)->count(),
                'icon' => 'lucide:check-circle',
                'color' => 'green',
            ],
            [
                'label' => __('Total Topics'),
                'value' => Topic::count(),
                'icon' => 'lucide:message-circle',
                'color' => 'blue',
            ],
            [
                'label' => __('Empty Categories'),
                'value' => Category::doesntHave('topics')->count(),
                'icon' => 'lucide:folder-x',
                'color' => 'amber',
            ],
        ];
    }
}
