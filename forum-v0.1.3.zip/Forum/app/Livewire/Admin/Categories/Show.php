<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Admin\Categories;

use Illuminate\Contracts\View\View;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Modules\Forum\Models\Category;

#[Layout('forum::layouts.crud')]
class Show extends Component
{
    public Category $category;

    public array $breadcrumbs = [];

    public function mount(Category $category): void
    {
        $this->category = $category->loadCount('topics');

        $this->breadcrumbs = [
            'title' => $category->name,
            'icon' => 'lucide:folder',
            'back_url' => route('admin.forum.categories.index'),
            'action' => [
                'url' => route('admin.forum.categories.edit', $this->category),
                'label' => __('Edit'),
                'icon' => 'lucide:pencil',
            ],
        ];
    }

    public function render(): View
    {
        return view('forum::livewire.admin.categories.show', [
            'recentTopics' => $this->category->topics()
                ->with('user')
                ->withCount('replies')
                ->latest()
                ->limit(5)
                ->get(),
            'stats' => $this->getStats(),
        ]);
    }

    protected function getStats(): array
    {
        $topicsCount = $this->category->topics()->count();
        $repliesCount = $this->category->topics()->withCount('replies')->get()->sum('replies_count');
        $viewsCount = $this->category->topics()->sum('views_count');

        return [
            'topics' => $topicsCount,
            'replies' => $repliesCount,
            'views' => (int) $viewsCount,
        ];
    }
}
