<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Admin;

use Carbon\Carbon;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\DB;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Modules\Forum\Models\Category;
use Modules\Forum\Models\Reply;
use Modules\Forum\Models\Topic;

#[Layout('forum::layouts.admin')]
class Dashboard extends Component
{
    public function render(): View
    {
        return view('forum::livewire.admin.dashboard', [
            'stats' => $this->getStats(),
            'topicChartData' => $this->getTopicChartData(),
            'recentTopics' => $this->getRecentTopics(),
            'topCategories' => $this->getTopCategories(),
            'recentReplies' => $this->getRecentReplies(),
        ]);
    }

    protected function getStats(): array
    {
        $totalTopics = Topic::count();
        $totalReplies = Reply::count();
        $totalCategories = Category::count();
        $totalViews = Topic::sum('views_count');
        $solvedTopics = Topic::where('is_solved', true)->count();
        $activeUsers = Topic::distinct('user_id')->count('user_id');

        // Calculate growth percentages (last 30 days vs previous 30 days)
        $now = Carbon::now();
        $thirtyDaysAgo = $now->copy()->subDays(30);
        $sixtyDaysAgo = $now->copy()->subDays(60);

        $topicsLast30 = Topic::where('created_at', '>=', $thirtyDaysAgo)->count();
        $topicsPrev30 = Topic::whereBetween('created_at', [$sixtyDaysAgo, $thirtyDaysAgo])->count();
        $topicsGrowth = $topicsPrev30 > 0 ? round((($topicsLast30 - $topicsPrev30) / $topicsPrev30) * 100, 1) : 0;

        $repliesLast30 = Reply::where('created_at', '>=', $thirtyDaysAgo)->count();
        $repliesPrev30 = Reply::whereBetween('created_at', [$sixtyDaysAgo, $thirtyDaysAgo])->count();
        $repliesGrowth = $repliesPrev30 > 0 ? round((($repliesLast30 - $repliesPrev30) / $repliesPrev30) * 100, 1) : 0;

        return [
            'totalTopics' => $totalTopics,
            'totalReplies' => $totalReplies,
            'totalCategories' => $totalCategories,
            'totalViews' => $totalViews,
            'solvedTopics' => $solvedTopics,
            'activeUsers' => $activeUsers,
            'solvedRate' => $totalTopics > 0 ? round(($solvedTopics / $totalTopics) * 100, 1) : 0,
            'topicsGrowth' => $topicsGrowth,
            'repliesGrowth' => $repliesGrowth,
        ];
    }

    protected function getTopicChartData(): array
    {
        $labels = [];
        $data = [];

        // Get topics per day for last 30 days
        for ($i = 29; $i >= 0; $i--) {
            $date = Carbon::now()->subDays($i);
            $labels[] = $date->format('M d');
            $data[] = Topic::whereDate('created_at', $date)->count();
        }

        return [
            'labels' => $labels,
            'data' => $data,
        ];
    }

    protected function getRecentTopics(): \Illuminate\Database\Eloquent\Collection
    {
        return Topic::with(['user', 'category'])
            ->latest()
            ->limit(5)
            ->get();
    }

    protected function getTopCategories(): \Illuminate\Database\Eloquent\Collection
    {
        return Category::withCount('topics')
            ->orderByDesc('topics_count')
            ->limit(5)
            ->get();
    }

    protected function getRecentReplies(): \Illuminate\Database\Eloquent\Collection
    {
        return Reply::with(['user', 'topic.category'])
            ->latest()
            ->limit(5)
            ->get();
    }
}
