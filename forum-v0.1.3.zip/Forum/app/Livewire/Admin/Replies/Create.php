<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Admin\Replies;

use App\Models\User;
use Illuminate\Contracts\View\View;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Modules\Forum\Models\Reply;
use Modules\Forum\Models\Topic;

#[Layout('forum::layouts.crud')]
class Create extends Component
{
    public ?int $topic_id = null;

    public ?int $user_id = null;

    public ?int $parent_id = null;

    public string $content = '';

    public bool $is_solution = false;

    public array $breadcrumbs = [];

    public function mount(): void
    {
        // Pre-select topic if passed in URL
        if (request()->has('topic')) {
            $this->topic_id = (int) request()->get('topic');
        }

        // Pre-select parent if passed in URL
        if (request()->has('parent')) {
            $this->parent_id = (int) request()->get('parent');
            // Also set topic from parent
            $parent = Reply::find($this->parent_id);
            if ($parent) {
                $this->topic_id = $parent->topic_id;
            }
        }

        $this->breadcrumbs = [
            'title' => __('Create Reply'),
            'icon' => 'lucide:message-square',
            'back_url' => route('admin.forum.replies.index'),
        ];
    }

    protected function rules(): array
    {
        return [
            'topic_id' => 'required|exists:forum_topics,id',
            'user_id' => 'required|exists:users,id',
            'parent_id' => 'nullable|exists:forum_replies,id',
            'content' => 'required|string|max:65535',
            'is_solution' => 'boolean',
        ];
    }

    protected function messages(): array
    {
        return [
            'topic_id.required' => __('Please select a topic.'),
            'user_id.required' => __('Please select an author.'),
        ];
    }

    public function save(): void
    {
        $validated = $this->validate();

        $item = Reply::create([
            'topic_id' => $validated['topic_id'],
            'user_id' => $validated['user_id'],
            'parent_id' => $validated['parent_id'],
            'content' => $validated['content'],
            'is_solution' => $validated['is_solution'],
            'likes_count' => 0,
        ]);

        session()->flash('success', __('Reply created successfully.'));

        $this->redirect(route('admin.forum.replies.edit', $item), navigate: true);
    }

    public function render(): View
    {
        // Get users, ensuring the selected user is always included
        $users = User::orderBy('first_name')->orderBy('last_name')->limit(100)->get();

        if ($this->user_id && ! $users->contains('id', $this->user_id)) {
            $selectedUser = User::find($this->user_id);
            if ($selectedUser) {
                $users->prepend($selectedUser);
            }
        }

        return view('forum::livewire.admin.replies.create', [
            'topics' => Topic::with('category')->orderBy('created_at', 'desc')->limit(100)->get(),
            'users' => $users,
            'parentReplies' => $this->topic_id
                ? Reply::where('topic_id', $this->topic_id)->whereNull('parent_id')->with('user')->get()
                : collect(),
        ]);
    }
}
