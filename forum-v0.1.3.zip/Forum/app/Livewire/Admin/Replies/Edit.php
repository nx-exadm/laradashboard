<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Admin\Replies;

use App\Models\User;
use Illuminate\Contracts\View\View;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Modules\Forum\Models\Reply;
use Modules\Forum\Models\Topic;

#[Layout('forum::layouts.crud')]
class Edit extends Component
{
    public Reply $reply;

    public ?int $topic_id = null;

    public ?int $user_id = null;

    public ?int $parent_id = null;

    public string $content = '';

    public bool $is_solution = false;

    public array $breadcrumbs = [];

    protected function rules(): array
    {
        return [
            'topic_id' => 'required|exists:forum_topics,id',
            'user_id' => 'required|exists:users,id',
            'parent_id' => 'nullable|exists:forum_replies,id',
            'content' => 'required|string|max:65535',
            'is_solution' => 'boolean',
        ];
    }

    protected function messages(): array
    {
        return [
            'topic_id.required' => __('Please select a topic.'),
            'user_id.required' => __('Please select an author.'),
        ];
    }

    public function mount(Reply $reply): void
    {
        $this->reply = $reply->load(['user', 'topic', 'topic.category', 'parent']);
        $this->topic_id = $this->reply->topic_id;
        $this->user_id = $this->reply->user_id;
        $this->parent_id = $this->reply->parent_id;
        $this->content = $this->reply->content ?? '';
        $this->is_solution = (bool) $this->reply->is_solution;

        $this->breadcrumbs = [
            'title' => __('Edit Reply'),
            'icon' => 'lucide:message-square',
            'back_url' => route('admin.forum.replies.index'),
            'action' => [
                'url' => route('admin.forum.replies.show', $this->reply),
                'label' => __('View'),
                'icon' => 'lucide:eye',
            ],
        ];
    }

    public function save(): void
    {
        $validated = $this->validate();

        // Handle solution status change
        $wasSolution = $this->reply->is_solution;
        $isSolution = $validated['is_solution'];

        $this->reply->update([
            'topic_id' => $validated['topic_id'],
            'user_id' => $validated['user_id'],
            'parent_id' => $validated['parent_id'],
            'content' => $validated['content'],
            'is_solution' => $isSolution,
        ]);

        // Update topic solved status if solution changed
        if ($wasSolution !== $isSolution && $this->reply->topic) {
            $this->reply->topic->update(['is_solved' => $isSolution]);
        }

        session()->flash('success', __('Reply updated successfully.'));
    }

    public function delete(): void
    {
        // Unmark solution before deleting
        if ($this->reply->is_solution && $this->reply->topic) {
            $this->reply->topic->update(['is_solved' => false]);
        }

        $this->reply->delete();

        session()->flash('success', __('Reply deleted successfully.'));

        $this->redirect(route('admin.forum.replies.index'), navigate: true);
    }

    public function render(): View
    {
        // Get users, ensuring the selected user is always included
        $users = User::orderBy('first_name')->orderBy('last_name')->limit(100)->get();

        if ($this->user_id && ! $users->contains('id', $this->user_id)) {
            $selectedUser = User::find($this->user_id);
            if ($selectedUser) {
                $users->prepend($selectedUser);
            }
        }

        return view('forum::livewire.admin.replies.edit', [
            'topics' => Topic::with('category')->orderBy('created_at', 'desc')->limit(100)->get(),
            'users' => $users,
            'parentReplies' => $this->topic_id
                ? Reply::where('topic_id', $this->topic_id)
                    ->whereNull('parent_id')
                    ->where('id', '!=', $this->reply->id)
                    ->with('user')
                    ->get()
                : collect(),
        ]);
    }
}
