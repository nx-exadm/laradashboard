<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Admin\Replies;

use Carbon\Carbon;
use Illuminate\Contracts\View\View;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Modules\Forum\Models\Reply;

#[Layout('forum::layouts.crud')]
class Index extends Component
{
    public array $breadcrumbs = [];

    public function mount(): void
    {
        $this->breadcrumbs = [
            'title' => __('Replies'),
            'icon' => 'lucide:message-square',
            'action' => [
                'url' => route('admin.forum.replies.create'),
                'label' => __('New Reply'),
                'icon' => 'lucide:plus',
            ],
        ];
    }

    public function render(): View
    {
        return view('forum::livewire.admin.replies.index', [
            'stats' => $this->getStats(),
        ]);
    }

    protected function getStats(): array
    {
        return [
            [
                'label' => __('Total Replies'),
                'value' => Reply::count(),
                'icon' => 'lucide:message-square',
                'color' => 'primary',
            ],
            [
                'label' => __('Solutions'),
                'value' => Reply::where('is_solution', true)->count(),
                'icon' => 'lucide:check-circle',
                'color' => 'green',
            ],
            [
                'label' => __('Total Likes'),
                'value' => number_format((int) Reply::sum('likes_count')),
                'icon' => 'lucide:heart',
                'color' => 'rose',
            ],
            [
                'label' => __('Today'),
                'value' => Reply::whereDate('created_at', Carbon::today())->count(),
                'icon' => 'lucide:calendar',
                'color' => 'amber',
            ],
        ];
    }
}
