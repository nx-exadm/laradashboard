<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Admin\Replies;

use Illuminate\Contracts\View\View;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Modules\Forum\Models\Reply;

#[Layout('forum::layouts.crud')]
class Show extends Component
{
    public Reply $reply;

    public array $breadcrumbs = [];

    public function mount(Reply $reply): void
    {
        $this->reply = $reply->load(['user', 'topic', 'topic.category', 'parent', 'parent.user']);

        $this->breadcrumbs = [
            'title' => __('Reply Details'),
            'icon' => 'lucide:message-square',
            'back_url' => route('admin.forum.replies.index'),
            'action' => [
                'url' => route('admin.forum.replies.edit', $this->reply),
                'label' => __('Edit'),
                'icon' => 'lucide:pencil',
            ],
        ];
    }

    public function toggleSolution(): void
    {
        $this->reply->update(['is_solution' => ! $this->reply->is_solution]);

        // Update topic solved status
        if ($this->reply->topic) {
            $this->reply->topic->update(['is_solved' => $this->reply->is_solution]);
        }

        $this->reply->refresh();
    }

    public function render(): View
    {
        return view('forum::livewire.admin.replies.show');
    }
}
