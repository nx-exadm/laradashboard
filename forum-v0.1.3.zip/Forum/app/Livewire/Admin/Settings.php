<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Admin;

use App\Models\Setting;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Artisan;
use Livewire\Attributes\Layout;
use Livewire\Component;

#[Layout('forum::layouts.crud')]
class Settings extends Component
{
    public array $breadcrumbs = [];

    public int $topics_per_page = 15;

    public int $replies_per_page = 20;

    public bool $allow_guests_to_view = true;

    public bool $require_email_verification = false;

    public bool $enable_likes = true;

    public bool $enable_solutions = true;

    public bool $show_view_count = true;

    public bool $allow_nested_replies = true;

    public bool $show_forum_header = true;

    public bool $show_user_dropdown = true;

    public bool $show_forum_footer = true;

    public bool $show_page_title = true;

    public string $forum_title = 'Forum';

    public string $forum_description = '';

    public string $forum_footer_text = '';

    public string $forum_base_url = '/forum';

    public function mount(): void
    {
        $this->breadcrumbs = [
            'title' => __('Forum Settings'),
            'icon' => 'lucide:settings',
            'back_url' => route('admin.forum.dashboard'),
        ];

        $this->topics_per_page = (int) config('settings.forum_topics_per_page', 15);
        $this->replies_per_page = (int) config('settings.forum_replies_per_page', 20);
        $this->allow_guests_to_view = filter_var(config('settings.forum_allow_guests_to_view', true), FILTER_VALIDATE_BOOLEAN);
        $this->require_email_verification = filter_var(config('settings.forum_require_email_verification', false), FILTER_VALIDATE_BOOLEAN);
        $this->enable_likes = filter_var(config('settings.forum_enable_likes', true), FILTER_VALIDATE_BOOLEAN);
        $this->enable_solutions = filter_var(config('settings.forum_enable_solutions', true), FILTER_VALIDATE_BOOLEAN);
        $this->show_view_count = filter_var(config('settings.forum_show_view_count', true), FILTER_VALIDATE_BOOLEAN);
        $this->allow_nested_replies = filter_var(config('settings.forum_allow_nested_replies', true), FILTER_VALIDATE_BOOLEAN);
        $this->show_forum_header = filter_var(config('settings.forum_show_header', true), FILTER_VALIDATE_BOOLEAN);
        $this->show_user_dropdown = filter_var(config('settings.forum_show_user_dropdown', true), FILTER_VALIDATE_BOOLEAN);
        $this->show_forum_footer = filter_var(config('settings.forum_show_footer', true), FILTER_VALIDATE_BOOLEAN);
        $this->show_page_title = filter_var(config('settings.forum_show_page_title', true), FILTER_VALIDATE_BOOLEAN);
        $this->forum_title = config('settings.forum_title', 'Forum') ?: 'Forum';
        $this->forum_description = config('settings.forum_description', '') ?: '';
        $this->forum_footer_text = config('settings.forum_footer_text', '') ?: '';
        $this->forum_base_url = config('settings.forum_base_url', '/forum') ?: '/forum';
    }

    public function save(): void
    {
        $this->validate([
            'topics_per_page' => 'required|integer|min:5|max:100',
            'replies_per_page' => 'required|integer|min:5|max:100',
            'allow_guests_to_view' => 'boolean',
            'require_email_verification' => 'boolean',
            'enable_likes' => 'boolean',
            'enable_solutions' => 'boolean',
            'show_view_count' => 'boolean',
            'allow_nested_replies' => 'boolean',
            'show_forum_header' => 'boolean',
            'show_user_dropdown' => 'boolean',
            'show_forum_footer' => 'boolean',
            'show_page_title' => 'boolean',
            'forum_title' => 'required|string|max:100',
            'forum_description' => 'nullable|string|max:500',
            'forum_footer_text' => 'nullable|string|max:500',
            'forum_base_url' => 'required|string|max:255',
        ]);

        // Check if URL changed to clear route cache
        $oldUrl = config('settings.forum_base_url', '/forum');
        $urlChanged = $oldUrl !== $this->forum_base_url;

        $settings = [
            'forum_topics_per_page' => $this->topics_per_page,
            'forum_replies_per_page' => $this->replies_per_page,
            'forum_allow_guests_to_view' => $this->allow_guests_to_view ? '1' : '0',
            'forum_require_email_verification' => $this->require_email_verification ? '1' : '0',
            'forum_enable_likes' => $this->enable_likes ? '1' : '0',
            'forum_enable_solutions' => $this->enable_solutions ? '1' : '0',
            'forum_show_view_count' => $this->show_view_count ? '1' : '0',
            'forum_allow_nested_replies' => $this->allow_nested_replies ? '1' : '0',
            'forum_show_header' => $this->show_forum_header ? '1' : '0',
            'forum_show_user_dropdown' => $this->show_user_dropdown ? '1' : '0',
            'forum_show_footer' => $this->show_forum_footer ? '1' : '0',
            'forum_show_page_title' => $this->show_page_title ? '1' : '0',
            'forum_title' => $this->forum_title,
            'forum_description' => $this->forum_description,
            'forum_footer_text' => $this->forum_footer_text,
            'forum_base_url' => $this->forum_base_url,
        ];

        foreach ($settings as $key => $value) {
            Setting::updateOrCreate(
                ['option_name' => $key],
                ['option_value' => (string) $value]
            );
        }

        // Clear the settings cache
        cache()->forget('settings');

        // Clear route cache if URL changed
        if ($urlChanged) {
            Artisan::call('route:clear');
        }

        $this->dispatch('notify', [
            'variant' => 'success',
            'title' => __('Success'),
            'message' => __('Forum settings saved successfully.'),
        ]);
    }

    public function render(): View
    {
        return view('forum::livewire.admin.settings');
    }
}
