<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Admin\Topics;

use App\Models\User;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Str;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Modules\Forum\Models\Category;
use Modules\Forum\Models\Topic;

#[Layout('forum::layouts.crud')]
class Create extends Component
{
    public ?int $category_id = null;

    public ?int $user_id = null;

    public string $title = '';

    public string $slug = '';

    public string $content = '';

    public bool $is_pinned = false;

    public bool $is_locked = false;

    public array $breadcrumbs = [];

    public function mount(): void
    {
        $this->user_id = auth()->id();

        $this->breadcrumbs = [
            'title' => __('Create Topic'),
            'icon' => 'lucide:message-circle',
            'back_url' => route('admin.forum.topics.index'),
        ];
    }

    public function updatedTitle(string $value): void
    {
        if (empty($this->slug)) {
            $this->slug = Str::slug($value);
        }
    }

    protected function rules(): array
    {
        return [
            'category_id' => 'required|exists:forum_categories,id',
            'user_id' => 'required|exists:users,id',
            'title' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:forum_topics,slug',
            'content' => 'required|string|max:65535',
            'is_pinned' => 'boolean',
            'is_locked' => 'boolean',
        ];
    }

    protected function messages(): array
    {
        return [
            'slug.unique' => __('This slug is already taken. Please use a different one.'),
            'category_id.required' => __('Please select a category.'),
            'user_id.required' => __('Please select an author.'),
        ];
    }

    public function save(): void
    {
        $validated = $this->validate();

        $item = Topic::create([
            'category_id' => $validated['category_id'],
            'user_id' => $validated['user_id'],
            'title' => $validated['title'],
            'slug' => $validated['slug'],
            'content' => $validated['content'],
            'is_pinned' => $validated['is_pinned'],
            'is_locked' => $validated['is_locked'],
            'is_solved' => false,
            'views_count' => 0,
            'replies_count' => 0,
        ]);

        session()->flash('success', __('Topic created successfully.'));

        $this->redirect(route('admin.forum.topics.show', $item), navigate: true);
    }

    public function render(): View
    {
        // Get users, ensuring the selected user is always included
        $users = User::orderBy('first_name')->orderBy('last_name')->limit(100)->get();

        // If selected user is not in the list, prepend them
        if ($this->user_id && ! $users->contains('id', $this->user_id)) {
            $selectedUser = User::find($this->user_id);
            if ($selectedUser) {
                $users->prepend($selectedUser);
            }
        }

        return view('forum::livewire.admin.topics.create', [
            'categories' => Category::where('is_active', true)->orderBy('order')->get(),
            'users' => $users,
        ]);
    }
}
