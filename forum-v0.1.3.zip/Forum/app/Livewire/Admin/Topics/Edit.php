<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Admin\Topics;

use App\Models\User;
use Illuminate\Contracts\View\View;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Modules\Forum\Models\Category;
use Modules\Forum\Models\Topic;

#[Layout('forum::layouts.crud')]
class Edit extends Component
{
    public Topic $topic;

    public ?int $category_id = null;

    public ?int $user_id = null;

    public string $title = '';

    public string $slug = '';

    public string $content = '';

    public bool $is_pinned = false;

    public bool $is_locked = false;

    public bool $is_solved = false;

    public array $breadcrumbs = [];

    protected function rules(): array
    {
        return [
            'category_id' => 'required|exists:forum_categories,id',
            'user_id' => 'required|exists:users,id',
            'title' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:forum_topics,slug,'.$this->topic->id,
            'content' => 'required|string|max:65535',
            'is_pinned' => 'boolean',
            'is_locked' => 'boolean',
            'is_solved' => 'boolean',
        ];
    }

    protected function messages(): array
    {
        return [
            'slug.unique' => __('This slug is already taken. Please use a different one.'),
            'category_id.required' => __('Please select a category.'),
            'user_id.required' => __('Please select an author.'),
        ];
    }

    public function mount(Topic $topic): void
    {
        $this->topic = $topic;
        $this->category_id = $this->topic->category_id;
        $this->user_id = $this->topic->user_id;
        $this->title = $this->topic->title ?? '';
        $this->slug = $this->topic->slug ?? '';
        $this->content = $this->topic->content ?? '';
        $this->is_pinned = (bool) $this->topic->is_pinned;
        $this->is_locked = (bool) $this->topic->is_locked;
        $this->is_solved = (bool) $this->topic->is_solved;

        $this->breadcrumbs = [
            'title' => __('Edit Topic'),
            'icon' => 'lucide:message-circle',
            'back_url' => route('admin.forum.topics.index'),
            'action' => [
                'url' => route('admin.forum.topics.show', $this->topic),
                'label' => __('View'),
                'icon' => 'lucide:eye',
            ],
        ];
    }

    public function save(): void
    {
        $validated = $this->validate();

        $this->topic->update([
            'category_id' => $validated['category_id'],
            'user_id' => $validated['user_id'],
            'title' => $validated['title'],
            'slug' => $validated['slug'],
            'content' => $validated['content'],
            'is_pinned' => $validated['is_pinned'],
            'is_locked' => $validated['is_locked'],
            'is_solved' => $validated['is_solved'],
        ]);

        session()->flash('success', __('Topic updated successfully.'));
    }

    public function delete(): void
    {
        // Delete all replies first
        $this->topic->replies()->delete();
        $this->topic->delete();

        session()->flash('success', __('Topic deleted successfully.'));

        $this->redirect(route('admin.forum.topics.index'), navigate: true);
    }

    public function render(): View
    {
        // Get users, ensuring the selected user is always included
        $users = User::orderBy('first_name')->orderBy('last_name')->limit(100)->get();

        if ($this->user_id && ! $users->contains('id', $this->user_id)) {
            $selectedUser = User::find($this->user_id);
            if ($selectedUser) {
                $users->prepend($selectedUser);
            }
        }

        return view('forum::livewire.admin.topics.edit', [
            'categories' => Category::where('is_active', true)->orderBy('order')->get(),
            'users' => $users,
        ]);
    }
}
