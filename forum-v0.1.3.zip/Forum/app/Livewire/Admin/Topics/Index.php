<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Admin\Topics;

use Illuminate\Contracts\View\View;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Modules\Forum\Models\Reply;
use Modules\Forum\Models\Topic;

#[Layout('forum::layouts.crud')]
class Index extends Component
{
    public array $breadcrumbs = [];

    public function mount(): void
    {
        $this->breadcrumbs = [
            'title' => __('Topics'),
            'icon' => 'lucide:message-circle',
            'action' => [
                'url' => route('admin.forum.topics.create'),
                'label' => __('New Topic'),
                'icon' => 'lucide:plus',
            ],
        ];
    }

    public function render(): View
    {
        return view('forum::livewire.admin.topics.index', [
            'stats' => $this->getStats(),
        ]);
    }

    protected function getStats(): array
    {
        $totalTopics = Topic::count();
        $solvedTopics = Topic::where('is_solved', true)->count();

        return [
            [
                'label' => __('Total Topics'),
                'value' => $totalTopics,
                'icon' => 'lucide:message-circle',
                'color' => 'primary',
            ],
            [
                'label' => __('Solved'),
                'value' => $solvedTopics,
                'icon' => 'lucide:check-circle',
                'color' => 'green',
            ],
            [
                'label' => __('Total Views'),
                'value' => number_format((int) Topic::sum('views_count')),
                'icon' => 'lucide:eye',
                'color' => 'blue',
            ],
            [
                'label' => __('Total Replies'),
                'value' => Reply::count(),
                'icon' => 'lucide:message-square',
                'color' => 'indigo',
            ],
        ];
    }
}
