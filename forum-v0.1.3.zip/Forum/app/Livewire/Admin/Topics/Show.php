<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Admin\Topics;

use Illuminate\Contracts\View\View;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Modules\Forum\Models\Topic;

#[Layout('forum::layouts.crud')]
class Show extends Component
{
    public Topic $topic;

    public array $breadcrumbs = [];

    public function mount(Topic $topic): void
    {
        $this->topic = $topic->load(['user', 'category']);

        $this->breadcrumbs = [
            'title' => $topic->title,
            'icon' => 'lucide:message-circle',
            'back_url' => route('admin.forum.topics.index'),
            'action' => [
                'url' => route('admin.forum.topics.edit', $this->topic),
                'label' => __('Edit'),
                'icon' => 'lucide:pencil',
            ],
        ];
    }

    public function togglePin(): void
    {
        $this->topic->update(['is_pinned' => ! $this->topic->is_pinned]);
        $this->topic->refresh();
    }

    public function toggleLock(): void
    {
        $this->topic->update(['is_locked' => ! $this->topic->is_locked]);
        $this->topic->refresh();
    }

    public function toggleSolved(): void
    {
        $this->topic->update(['is_solved' => ! $this->topic->is_solved]);
        $this->topic->refresh();
    }

    public function render(): View
    {
        return view('forum::livewire.admin.topics.show', [
            'replies' => $this->topic->replies()
                ->with('user')
                ->latest()
                ->limit(10)
                ->get(),
        ]);
    }
}
