<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Components;

use App\Livewire\Datatable\Datatable;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Database\Eloquent\Model;
use Modules\Forum\Models\Category;
use Spatie\QueryBuilder\QueryBuilder;

class CategoryDatatable extends Datatable
{
    public string $model = Category::class;

    public function getSearchbarPlaceholder(): string
    {
        return __('Search categories...');
    }

    protected function getHeaders(): array
    {
        return [
            [
                'id' => 'category',
                'title' => __('Category'),
                'sortable' => true,
                'sortBy' => 'name',
                'searchable' => true,
            ],
            [
                'id' => 'topics_count',
                'title' => __('Topics'),
                'sortable' => true,
                'sortBy' => 'topics_count',
                'width' => '100px',
            ],
            [
                'id' => 'order',
                'title' => __('Order'),
                'sortable' => true,
                'sortBy' => 'order',
                'width' => '80px',
            ],
            [
                'id' => 'status',
                'title' => __('Status'),
                'sortable' => true,
                'sortBy' => 'is_active',
                'width' => '100px',
            ],
            [
                'id' => 'actions',
                'title' => '',
                'sortable' => false,
                'is_action' => true,
                'width' => '80px',
            ],
        ];
    }

    public function getRoutes(): array
    {
        return [
            'create' => 'admin.forum.categories.create',
            'view' => 'admin.forum.categories.show',
            'edit' => 'admin.forum.categories.edit',
            'delete' => 'livewire',
        ];
    }

    public function getDeleteRouteUrl($item): string
    {
        return '';
    }

    public function getActionCellPermissions($item): array
    {
        return [
            'view' => true,
            'edit' => true,
            'delete' => $item->topics_count === 0,
        ];
    }

    protected function buildQuery(): QueryBuilder
    {
        return QueryBuilder::for(Category::query())
            ->withCount('topics')
            ->when($this->search, function ($query) {
                $query->where(function ($q) {
                    $q->where('name', 'like', "%{$this->search}%")
                        ->orWhere('slug', 'like', "%{$this->search}%")
                        ->orWhere('description', 'like', "%{$this->search}%");
                });
            })
            ->orderBy($this->sort, $this->direction);
    }

    public function handleRowDelete(Model|Category $item): bool
    {
        if ($item->topics()->count() > 0) {
            $this->dispatch('notify', [
                'variant' => 'error',
                'title' => __('Error'),
                'message' => __('Cannot delete category with topics. Move or delete topics first.'),
            ]);

            return false;
        }

        return $item->delete();
    }

    public function renderCategoryColumn(Category $item): Renderable
    {
        return view('forum::components.datatable.category-cell', ['item' => $item]);
    }

    public function renderTopicsCountColumn(Category $item): Renderable
    {
        return view('forum::components.datatable.count-cell', [
            'count' => $item->topics_count,
            'label' => __('topics'),
        ]);
    }

    public function renderOrderColumn(Category $item): Renderable
    {
        return view('forum::components.datatable.order-cell', [
            'order' => $item->order,
        ]);
    }

    public function renderStatusColumn(Category $item): Renderable
    {
        return view('forum::components.datatable.status-badge', [
            'active' => $item->is_active,
            'activeLabel' => __('Active'),
            'inactiveLabel' => __('Inactive'),
        ]);
    }
}
