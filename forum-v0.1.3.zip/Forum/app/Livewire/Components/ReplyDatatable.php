<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Components;

use App\Livewire\Datatable\Datatable;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Database\Eloquent\Model;
use Modules\Forum\Models\Reply;
use Spatie\QueryBuilder\QueryBuilder;

class ReplyDatatable extends Datatable
{
    public string $model = Reply::class;

    public function getSearchbarPlaceholder(): string
    {
        return __('Search replies by content, author, or topic...');
    }

    protected function getHeaders(): array
    {
        return [
            [
                'id' => 'reply',
                'title' => __('Reply'),
                'sortable' => true,
                'sortBy' => 'content',
                'searchable' => true,
            ],
            [
                'id' => 'topic',
                'title' => __('Topic'),
                'sortable' => true,
                'sortBy' => 'topic_id',
                'width' => '200px',
            ],
            [
                'id' => 'author',
                'title' => __('Author'),
                'sortable' => true,
                'sortBy' => 'user_id',
                'width' => '150px',
            ],
            [
                'id' => 'engagement',
                'title' => __('Engagement'),
                'sortable' => true,
                'sortBy' => 'likes_count',
                'width' => '100px',
            ],
            [
                'id' => 'status',
                'title' => __('Status'),
                'sortable' => true,
                'sortBy' => 'is_solution',
                'width' => '100px',
            ],
            [
                'id' => 'posted',
                'title' => __('Posted'),
                'sortable' => true,
                'sortBy' => 'created_at',
                'width' => '120px',
            ],
            [
                'id' => 'actions',
                'title' => '',
                'sortable' => false,
                'is_action' => true,
                'width' => '80px',
            ],
        ];
    }

    public function getRoutes(): array
    {
        return [
            'create' => 'admin.forum.replies.create',
            'view' => 'admin.forum.replies.show',
            'edit' => 'admin.forum.replies.edit',
            'delete' => 'livewire',
        ];
    }

    public function getDeleteRouteUrl($item): string
    {
        return '';
    }

    public function getActionCellPermissions($item): array
    {
        return [
            'view' => true,
            'edit' => true,
            'delete' => true,
        ];
    }

    protected function buildQuery(): QueryBuilder
    {
        return QueryBuilder::for(Reply::query())
            ->with(['user', 'topic', 'topic.category'])
            ->when($this->search, function ($query) {
                $query->where(function ($q) {
                    $q->where('content', 'like', "%{$this->search}%")
                        ->orWhereHas('user', function ($userQuery) {
                            $userQuery->where('name', 'like', "%{$this->search}%");
                        })
                        ->orWhereHas('topic', function ($topicQuery) {
                            $topicQuery->where('title', 'like', "%{$this->search}%");
                        });
                });
            })
            ->orderBy($this->sort, $this->direction);
    }

    public function handleRowDelete(Model|Reply $item): bool
    {
        // If this reply was the solution, mark topic as unsolved
        if ($item->is_solution && $item->topic) {
            $item->topic->update(['is_solved' => false]);
        }

        return $item->delete();
    }

    public function renderReplyColumn(Reply $item): Renderable
    {
        return view('forum::components.datatable.reply-cell', ['item' => $item]);
    }

    public function renderTopicColumn(Reply $item): Renderable
    {
        return view('forum::components.datatable.reply-topic-cell', ['topic' => $item->topic]);
    }

    public function renderAuthorColumn(Reply $item): Renderable
    {
        return view('forum::components.datatable.author-cell', ['user' => $item->user]);
    }

    public function renderEngagementColumn(Reply $item): Renderable
    {
        return view('forum::components.datatable.likes-cell', ['likes' => $item->likes_count]);
    }

    public function renderStatusColumn(Reply $item): Renderable
    {
        return view('forum::components.datatable.reply-status', ['isSolution' => $item->is_solution]);
    }

    public function renderPostedColumn(Reply $item): Renderable
    {
        return view('forum::components.datatable.time-cell', ['date' => $item->created_at]);
    }
}
