<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Components;

use App\Livewire\Datatable\Datatable;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Database\Eloquent\Model;
use Modules\Forum\Models\Topic;
use Spatie\QueryBuilder\QueryBuilder;

class TopicDatatable extends Datatable
{
    public string $model = Topic::class;

    public function getSearchbarPlaceholder(): string
    {
        return __('Search topics by title, content, or author...');
    }

    protected function getHeaders(): array
    {
        return [
            [
                'id' => 'topic',
                'title' => __('Topic'),
                'sortable' => true,
                'sortBy' => 'title',
                'searchable' => true,
            ],
            [
                'id' => 'author',
                'title' => __('Author'),
                'sortable' => true,
                'sortBy' => 'user_id',
                'width' => '160px',
            ],
            [
                'id' => 'category',
                'title' => __('Category'),
                'sortable' => true,
                'sortBy' => 'category_id',
                'width' => '140px',
            ],
            [
                'id' => 'stats',
                'title' => __('Stats'),
                'sortable' => true,
                'sortBy' => 'replies_count',
                'width' => '120px',
            ],
            [
                'id' => 'status',
                'title' => __('Status'),
                'sortable' => false,
                'width' => '140px',
            ],
            [
                'id' => 'posted',
                'title' => __('Created'),
                'sortable' => true,
                'sortBy' => 'created_at',
                'width' => '120px',
            ],
            [
                'id' => 'actions',
                'title' => '',
                'sortable' => false,
                'is_action' => true,
                'width' => '80px',
            ],
        ];
    }

    public function getRoutes(): array
    {
        return [
            'create' => 'admin.forum.topics.create',
            'view' => 'admin.forum.topics.show',
            'edit' => 'admin.forum.topics.edit',
            'delete' => 'livewire',
        ];
    }

    public function getDeleteRouteUrl($item): string
    {
        return '';
    }

    public function getActionCellPermissions($item): array
    {
        return [
            'view' => true,
            'edit' => true,
            'delete' => true,
        ];
    }

    protected function buildQuery(): QueryBuilder
    {
        return QueryBuilder::for(Topic::query())
            ->with(['user', 'category'])
            ->withCount('replies')
            ->when($this->search, function ($query) {
                $query->where(function ($q) {
                    $q->where('title', 'like', "%{$this->search}%")
                        ->orWhere('content', 'like', "%{$this->search}%")
                        ->orWhereHas('user', function ($userQuery) {
                            $userQuery->where('name', 'like', "%{$this->search}%");
                        });
                });
            })
            ->orderBy($this->sort, $this->direction);
    }

    public function handleRowDelete(Model|Topic $item): bool
    {
        // Delete all replies first
        $item->replies()->delete();

        return $item->delete();
    }

    public function renderTopicColumn(Topic $item): Renderable
    {
        return view('forum::components.datatable.topic-cell', ['item' => $item]);
    }

    public function renderAuthorColumn(Topic $item): Renderable
    {
        return view('forum::components.datatable.author-cell', ['user' => $item->user]);
    }

    public function renderCategoryColumn(Topic $item): Renderable
    {
        return view('forum::components.datatable.category-badge', ['category' => $item->category]);
    }

    public function renderStatsColumn(Topic $item): Renderable
    {
        return view('forum::components.datatable.topic-stats', [
            'views' => $item->views_count,
            'replies' => $item->replies_count,
        ]);
    }

    public function renderStatusColumn(Topic $item): Renderable
    {
        return view('forum::components.datatable.topic-status', [
            'isPinned' => $item->is_pinned,
            'isLocked' => $item->is_locked,
            'isSolved' => $item->is_solved,
        ]);
    }

    public function renderPostedColumn(Topic $item): Renderable
    {
        return view('forum::components.datatable.time-cell', ['date' => $item->created_at]);
    }
}
