<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Forum;

use Illuminate\View\View;
use Livewire\Component;
use Livewire\WithPagination;
use Modules\Forum\Models\Category;
use Modules\Forum\Models\Topic;
use Modules\Forum\Services\SeoService;

class CategoryShow extends Component
{
    use WithPagination;

    public Category $category;

    public string $filter = '';

    protected $queryString = [
        'filter' => ['except' => ''],
    ];

    public function mount(Category $category): void
    {
        abort_unless($category->is_active, 404);

        $this->category = $category;
    }

    public function updatingFilter(): void
    {
        $this->resetPage();
    }

    public function render(): View
    {
        $perPage = (int) config('settings.forum_topics_per_page', 15);

        $topics = Topic::query()
            ->where('category_id', $this->category->id)
            ->with(['user', 'lastReplyUser'])
            ->when($this->filter === 'solved', fn ($q) => $q->solved())
            ->when($this->filter === 'unsolved', fn ($q) => $q->unsolved())
            ->recent()
            ->paginate($perPage);

        $seo = SeoService::forCategory($this->category);

        return view('forum::livewire.forum.category-show', [
            'topics' => $topics,
        ])->layout('forum::layouts.forum', [
            'title' => $this->category->name.' - '.__('Forum'),
            'seo' => $seo,
        ]);
    }
}
