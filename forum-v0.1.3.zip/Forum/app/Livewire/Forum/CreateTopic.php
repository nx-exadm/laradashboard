<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Forum;

use Illuminate\View\View;
use Livewire\Component;
use Modules\Forum\Models\Category;
use Modules\Forum\Models\Topic;
use Modules\Forum\Services\SeoService;

class CreateTopic extends Component
{
    public ?int $category_id = null;

    public string $title = '';

    public string $content = '';

    public ?Category $selectedCategory = null;

    protected $rules = [
        'category_id' => 'required|exists:forum_categories,id',
        'title' => 'required|min:5|max:255',
        'content' => 'required|min:10',
    ];

    public function mount(?string $category = null): void
    {
        if (! auth()->check()) {
            $this->redirect(route('login'));

            return;
        }

        if ($category) {
            $cat = Category::where('slug', $category)->first();
            if ($cat) {
                $this->category_id = $cat->id;
                $this->selectedCategory = $cat;
            }
        }
    }

    public function createTopic(): void
    {
        $this->validate();

        $category = Category::findOrFail($this->category_id);

        $topic = Topic::create([
            'category_id' => $this->category_id,
            'user_id' => auth()->id(),
            'title' => $this->title,
            'content' => $this->content,
        ]);

        session()->flash('success', __('Topic created successfully!'));

        $this->redirect(route('forum.topic', [$category->slug, $topic->slug]));
    }

    public function render(): View
    {
        $categories = Category::query()
            ->active()
            ->ordered()
            ->get();

        $seo = SeoService::forCreateTopic($this->selectedCategory);

        return view('forum::livewire.forum.create-topic', [
            'categories' => $categories,
        ])->layout('forum::layouts.forum', [
            'title' => __('Create Topic').' - '.__('Forum'),
            'seo' => $seo,
        ]);
    }
}
