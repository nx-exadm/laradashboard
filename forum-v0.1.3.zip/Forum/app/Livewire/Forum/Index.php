<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Forum;

use Illuminate\View\View;
use Livewire\Component;
use Modules\Forum\Models\Category;
use Modules\Forum\Services\SeoService;

class Index extends Component
{
    public function render(): View
    {
        $categories = Category::query()
            ->active()
            ->ordered()
            ->withCount('topics')
            ->with(['lastTopic.user', 'lastTopic.category'])
            ->get();

        $forumTitle = config('settings.forum_title') ?: __('Forum');
        $forumDescription = config('settings.forum_description') ?: '';
        $showPageTitle = filter_var(config('settings.forum_show_page_title', true), FILTER_VALIDATE_BOOLEAN);
        $seo = SeoService::forHomepage();

        return view('forum::livewire.forum.index', [
            'categories' => $categories,
            'forumTitle' => $forumTitle,
            'forumDescription' => $forumDescription,
            'showPageTitle' => $showPageTitle,
        ])->layout('forum::layouts.forum', [
            'title' => $forumTitle,
            'seo' => $seo,
        ]);
    }
}
