<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Forum;

use Illuminate\View\View;
use Livewire\Component;
use Livewire\WithPagination;
use Modules\Forum\Models\Topic;
use Modules\Forum\Services\SeoService;

class Search extends Component
{
    use WithPagination;

    public string $query = '';

    protected $queryString = [
        'query' => ['except' => '', 'as' => 'q'],
    ];

    public function updatingQuery(): void
    {
        $this->resetPage();
    }

    public function render(): View
    {
        $topics = collect();

        if (strlen($this->query) >= 3) {
            $perPage = (int) config('settings.forum_topics_per_page', 15);

            $topics = Topic::query()
                ->search($this->query)
                ->with(['category', 'user'])
                ->recent()
                ->paginate($perPage);
        }

        $seo = SeoService::forSearch($this->query ?: null);

        return view('forum::livewire.forum.search', [
            'topics' => $topics,
        ])->layout('forum::layouts.forum', [
            'title' => __('Search').' - '.__('Forum'),
            'seo' => $seo,
        ]);
    }
}
