<?php

declare(strict_types=1);

namespace Modules\Forum\Livewire\Forum;

use Illuminate\View\View;
use Livewire\Attributes\On;
use Livewire\Component;
use Livewire\WithPagination;
use Modules\Forum\Models\Category;
use Modules\Forum\Models\Reply;
use Modules\Forum\Models\Topic;
use Modules\Forum\Services\SeoService;

class TopicShow extends Component
{
    use WithPagination;

    public Category $category;

    public Topic $topic;

    public string $replyContent = '';

    public ?int $replyingTo = null;

    // Topic editing
    public bool $editingTopic = false;

    public string $editingTopicTitle = '';

    public string $editingTopicContent = '';

    // Reply editing
    public ?int $editingReplyId = null;

    public string $editingReplyContent = '';

    protected $rules = [
        'replyContent' => 'required|min:10',
    ];

    public function mount(Category $category, Topic $topic): void
    {
        abort_unless($category->is_active, 404);
        abort_unless($topic->category_id === $category->id, 404);

        $this->category = $category;
        $this->topic = $topic;

        // Increment view count
        $this->topic->incrementViews();
    }

    public function submitReply(): void
    {
        if (! auth()->check()) {
            $this->redirect(route('login'));

            return;
        }

        if ($this->topic->is_locked) {
            $this->addError('replyContent', __('This topic is locked and cannot receive new replies.'));

            return;
        }

        $this->validate();

        Reply::create([
            'topic_id' => $this->topic->id,
            'user_id' => auth()->id(),
            'parent_id' => $this->replyingTo,
            'content' => $this->replyContent,
        ]);

        $this->reset(['replyContent', 'replyingTo']);
        $this->dispatch('reply-added');
    }

    public function setReplyingTo(int $replyId): void
    {
        $this->replyingTo = $replyId;
    }

    public function cancelReply(): void
    {
        $this->replyingTo = null;
    }

    public function toggleLikeTopic(): void
    {
        if (! auth()->check()) {
            $this->redirect(route('login'));

            return;
        }

        $this->topic->toggleLike(auth()->user());
        $this->topic->refresh();
    }

    public function toggleLikeReply(int $replyId): void
    {
        if (! auth()->check()) {
            $this->redirect(route('login'));

            return;
        }

        $reply = Reply::findOrFail($replyId);
        $reply->toggleLike(auth()->user());
    }

    public function markAsSolution(int $replyId): void
    {
        if (! auth()->check()) {
            return;
        }

        $reply = Reply::findOrFail($replyId);

        // Only topic author can mark as solution
        if ($this->topic->user_id !== auth()->id()) {
            return;
        }

        $reply->markAsSolution();
        $this->topic->refresh();
    }

    public function unmarkAsSolved(): void
    {
        if (! auth()->check()) {
            return;
        }

        // Only topic author can unmark
        if ($this->topic->user_id !== auth()->id()) {
            return;
        }

        $this->topic->unmarkAsSolved();
        $this->topic->refresh();
    }

    #[On('reply-added')]
    public function refreshReplies(): void
    {
        $this->topic->refresh();
    }

    // Topic Edit/Delete Methods
    public function editTopic(): void
    {
        if (! auth()->check() || $this->topic->user_id !== auth()->id()) {
            return;
        }

        $this->editingTopic = true;
        $this->editingTopicTitle = $this->topic->title;
        $this->editingTopicContent = $this->topic->content;
    }

    public function updateTopic(): void
    {
        if (! auth()->check() || $this->topic->user_id !== auth()->id()) {
            return;
        }

        $this->validate([
            'editingTopicTitle' => 'required|min:5|max:255',
            'editingTopicContent' => 'required|min:10',
        ]);

        $this->topic->update([
            'title' => $this->editingTopicTitle,
            'content' => $this->editingTopicContent,
        ]);

        $this->editingTopic = false;
        $this->topic->refresh();

        $this->dispatch('notify', [
            'type' => 'success',
            'message' => __('Topic updated successfully.'),
        ]);
    }

    public function cancelEditTopic(): void
    {
        $this->editingTopic = false;
        $this->editingTopicTitle = '';
        $this->editingTopicContent = '';
    }

    public function deleteTopic(): void
    {
        if (! auth()->check() || $this->topic->user_id !== auth()->id()) {
            return;
        }

        $categorySlug = $this->category->slug;
        $this->topic->delete();

        $this->redirect(route('forum.category', $categorySlug));
    }

    // Reply Edit/Delete Methods
    public function editReply(int $replyId): void
    {
        if (! auth()->check()) {
            return;
        }

        $reply = Reply::find($replyId);
        if (! $reply || $reply->user_id !== auth()->id()) {
            return;
        }

        $this->editingReplyId = $replyId;
        $this->editingReplyContent = $reply->content;
    }

    public function updateReply(): void
    {
        if (! auth()->check() || ! $this->editingReplyId) {
            return;
        }

        $reply = Reply::find($this->editingReplyId);
        if (! $reply || $reply->user_id !== auth()->id()) {
            return;
        }

        $this->validate([
            'editingReplyContent' => 'required|min:10',
        ]);

        $reply->update([
            'content' => $this->editingReplyContent,
        ]);

        $this->editingReplyId = null;
        $this->editingReplyContent = '';

        $this->dispatch('notify', [
            'type' => 'success',
            'message' => __('Reply updated successfully.'),
        ]);
    }

    public function cancelEditReply(): void
    {
        $this->editingReplyId = null;
        $this->editingReplyContent = '';
    }

    public function deleteReply(int $replyId): void
    {
        if (! auth()->check()) {
            return;
        }

        $reply = Reply::find($replyId);
        if (! $reply || $reply->user_id !== auth()->id()) {
            return;
        }

        $reply->delete();

        $this->topic->refresh();

        $this->dispatch('notify', [
            'type' => 'success',
            'message' => __('Reply deleted successfully.'),
        ]);
    }

    public function render(): View
    {
        $perPage = (int) config('settings.forum_replies_per_page', 20);

        $replies = Reply::query()
            ->where('topic_id', $this->topic->id)
            ->topLevel()
            ->with(['user', 'children.user'])
            ->orderBy('created_at')
            ->paginate($perPage);

        $seo = SeoService::forTopic($this->category, $this->topic);

        return view('forum::livewire.forum.topic-show', [
            'replies' => $replies,
        ])->layout('forum::layouts.forum', [
            'title' => $this->topic->title.' - '.__('Forum'),
            'seo' => $seo,
        ]);
    }
}
