<?php

declare(strict_types=1);

namespace Modules\Forum\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Category extends Model
{
    use HasFactory;

    protected $table = 'forum_categories';

    protected $fillable = [
        'name',
        'slug',
        'description',
        'icon',
        'color',
        'order',
        'is_active',
        'topics_count',
        'posts_count',
        'last_topic_id',
    ];

    protected function casts(): array
    {
        return [
            'order' => 'integer',
            'is_active' => 'boolean',
            'topics_count' => 'integer',
            'posts_count' => 'integer',
        ];
    }

    protected static function booted(): void
    {
        static::creating(function (Category $category) {
            if (empty($category->slug)) {
                $category->slug = Str::slug($category->name);
            }
        });
    }

    /*
    |--------------------------------------------------------------------------
    | Relationships
    |--------------------------------------------------------------------------
    */

    public function topics(): HasMany
    {
        return $this->hasMany(Topic::class);
    }

    public function lastTopic(): BelongsTo
    {
        return $this->belongsTo(Topic::class, 'last_topic_id');
    }

    /*
    |--------------------------------------------------------------------------
    | Scopes
    |--------------------------------------------------------------------------
    */

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeOrdered($query)
    {
        return $query->orderBy('order')->orderBy('name');
    }

    /*
    |--------------------------------------------------------------------------
    | Accessors
    |--------------------------------------------------------------------------
    */

    protected function url(): Attribute
    {
        return Attribute::make(
            get: fn () => route('forum.category', $this->slug)
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Methods
    |--------------------------------------------------------------------------
    */

    public function incrementTopicsCount(): void
    {
        $this->increment('topics_count');
    }

    public function decrementTopicsCount(): void
    {
        $this->decrement('topics_count');
    }

    public function incrementPostsCount(): void
    {
        $this->increment('posts_count');
    }

    public function updateLastTopic(Topic $topic): void
    {
        $this->update(['last_topic_id' => $topic->id]);
    }

    public function recalculateCounts(): void
    {
        $this->update([
            'topics_count' => $this->topics()->count(),
            'posts_count' => $this->topics()->withCount('replies')->get()->sum('replies_count') + $this->topics()->count(),
        ]);
    }
}
