<?php

declare(strict_types=1);

namespace Modules\Forum\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Reply extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = 'forum_replies';

    protected $fillable = [
        'topic_id',
        'user_id',
        'parent_id',
        'content',
        'likes_count',
        'is_solution',
    ];

    protected function casts(): array
    {
        return [
            'likes_count' => 'integer',
            'is_solution' => 'boolean',
        ];
    }

    protected static function booted(): void
    {
        static::created(function (Reply $reply) {
            $reply->topic->incrementRepliesCount();
            $reply->topic->updateLastReply($reply);
            $reply->topic->category->incrementPostsCount();
        });

        static::deleted(function (Reply $reply) {
            $reply->topic->decrementRepliesCount();
            $reply->topic->category->recalculateCounts();

            // If this was the solution, unmark the topic
            if ($reply->is_solution) {
                $reply->topic->unmarkAsSolved();
            }
        });
    }

    /*
    |--------------------------------------------------------------------------
    | Relationships
    |--------------------------------------------------------------------------
    */

    public function topic(): BelongsTo
    {
        return $this->belongsTo(Topic::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(Reply::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(Reply::class, 'parent_id');
    }

    public function likes(): MorphMany
    {
        return $this->morphMany(Like::class, 'likeable');
    }

    /*
    |--------------------------------------------------------------------------
    | Scopes
    |--------------------------------------------------------------------------
    */

    public function scopeTopLevel($query)
    {
        return $query->whereNull('parent_id');
    }

    public function scopeSolution($query)
    {
        return $query->where('is_solution', true);
    }

    /*
    |--------------------------------------------------------------------------
    | Methods
    |--------------------------------------------------------------------------
    */

    public function markAsSolution(): void
    {
        // Unmark any existing solution for this topic
        $this->topic->replies()->where('is_solution', true)->update(['is_solution' => false]);

        // Mark this reply as solution
        $this->update(['is_solution' => true]);

        // Update the topic
        $this->topic->update([
            'is_solved' => true,
            'solved_reply_id' => $this->id,
        ]);
    }

    public function unmarkAsSolution(): void
    {
        $this->update(['is_solution' => false]);

        $this->topic->update([
            'is_solved' => false,
            'solved_reply_id' => null,
        ]);
    }

    public function isLikedBy(?User $user): bool
    {
        if (! $user) {
            return false;
        }

        return $this->likes()->where('user_id', $user->id)->exists();
    }

    public function toggleLike(User $user): void
    {
        $like = $this->likes()->where('user_id', $user->id)->first();

        if ($like) {
            $like->delete();
            $this->decrement('likes_count');
        } else {
            $this->likes()->create(['user_id' => $user->id]);
            $this->increment('likes_count');
        }
    }

    public function isAuthor(?User $user): bool
    {
        if (! $user) {
            return false;
        }

        return $this->user_id === $user->id;
    }

    public function canBeMarkedAsSolution(?User $user): bool
    {
        if (! $user) {
            return false;
        }

        // Topic author can mark any reply as solution
        if ($this->topic->user_id === $user->id) {
            return true;
        }

        // Admin/moderator can mark solutions (implement permission check here)
        // return $user->can('forum.topics.edit');

        return false;
    }
}
