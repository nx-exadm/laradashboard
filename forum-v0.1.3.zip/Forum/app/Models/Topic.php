<?php

declare(strict_types=1);

namespace Modules\Forum\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Support\Str;

class Topic extends Model
{
    use HasFactory;

    protected $table = 'forum_topics';

    protected $fillable = [
        'category_id',
        'user_id',
        'title',
        'slug',
        'content',
        'views_count',
        'replies_count',
        'likes_count',
        'is_pinned',
        'is_locked',
        'is_solved',
        'solved_reply_id',
        'last_reply_at',
        'last_reply_user_id',
    ];

    protected function casts(): array
    {
        return [
            'views_count' => 'integer',
            'replies_count' => 'integer',
            'likes_count' => 'integer',
            'is_pinned' => 'boolean',
            'is_locked' => 'boolean',
            'is_solved' => 'boolean',
            'last_reply_at' => 'datetime',
        ];
    }

    protected static function booted(): void
    {
        static::creating(function (Topic $topic) {
            if (empty($topic->slug)) {
                $topic->slug = Str::slug($topic->title);
            }
        });

        static::created(function (Topic $topic) {
            $topic->category->incrementTopicsCount();
            $topic->category->incrementPostsCount();
            $topic->category->updateLastTopic($topic);
        });

        static::deleted(function (Topic $topic) {
            $topic->category->decrementTopicsCount();
            $topic->category->recalculateCounts();
        });
    }

    /*
    |--------------------------------------------------------------------------
    | Relationships
    |--------------------------------------------------------------------------
    */

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function replies(): HasMany
    {
        return $this->hasMany(Reply::class);
    }

    public function solvedReply(): BelongsTo
    {
        return $this->belongsTo(Reply::class, 'solved_reply_id');
    }

    public function lastReplyUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'last_reply_user_id');
    }

    public function likes(): MorphMany
    {
        return $this->morphMany(Like::class, 'likeable');
    }

    /*
    |--------------------------------------------------------------------------
    | Scopes
    |--------------------------------------------------------------------------
    */

    public function scopePinned($query)
    {
        return $query->where('is_pinned', true);
    }

    public function scopeNotPinned($query)
    {
        return $query->where('is_pinned', false);
    }

    public function scopeLocked($query)
    {
        return $query->where('is_locked', true);
    }

    public function scopeUnlocked($query)
    {
        return $query->where('is_locked', false);
    }

    public function scopeSolved($query)
    {
        return $query->where('is_solved', true);
    }

    public function scopeUnsolved($query)
    {
        return $query->where('is_solved', false);
    }

    public function scopeRecent($query)
    {
        return $query->orderByDesc('is_pinned')
            ->orderByDesc('last_reply_at')
            ->orderByDesc('created_at');
    }

    public function scopeSearch($query, string $search)
    {
        return $query->where(function ($q) use ($search) {
            $q->where('title', 'like', "%{$search}%")
                ->orWhere('content', 'like', "%{$search}%");
        });
    }

    /*
    |--------------------------------------------------------------------------
    | Accessors
    |--------------------------------------------------------------------------
    */

    protected function url(): Attribute
    {
        return Attribute::make(
            get: fn () => route('forum.topic', [$this->category->slug, $this->slug])
        );
    }

    protected function excerpt(): Attribute
    {
        return Attribute::make(
            get: fn () => Str::limit(strip_tags($this->content), 150)
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Methods
    |--------------------------------------------------------------------------
    */

    public function incrementViews(): void
    {
        $this->increment('views_count');
    }

    public function incrementRepliesCount(): void
    {
        $this->increment('replies_count');
    }

    public function decrementRepliesCount(): void
    {
        $this->decrement('replies_count');
    }

    public function updateLastReply(Reply $reply): void
    {
        $this->update([
            'last_reply_at' => $reply->created_at,
            'last_reply_user_id' => $reply->user_id,
        ]);

        $this->category->updateLastTopic($this);
    }

    public function togglePin(): void
    {
        $this->update(['is_pinned' => ! $this->is_pinned]);
    }

    public function toggleLock(): void
    {
        $this->update(['is_locked' => ! $this->is_locked]);
    }

    public function markAsSolved(Reply $reply): void
    {
        $this->update([
            'is_solved' => true,
            'solved_reply_id' => $reply->id,
        ]);

        $reply->update(['is_solution' => true]);
    }

    public function unmarkAsSolved(): void
    {
        if ($this->solvedReply) {
            $this->solvedReply->update(['is_solution' => false]);
        }

        $this->update([
            'is_solved' => false,
            'solved_reply_id' => null,
        ]);
    }

    public function isLikedBy(?User $user): bool
    {
        if (! $user) {
            return false;
        }

        return $this->likes()->where('user_id', $user->id)->exists();
    }

    public function toggleLike(User $user): void
    {
        $like = $this->likes()->where('user_id', $user->id)->first();

        if ($like) {
            $like->delete();
            $this->decrement('likes_count');
        } else {
            $this->likes()->create(['user_id' => $user->id]);
            $this->increment('likes_count');
        }
    }
}
