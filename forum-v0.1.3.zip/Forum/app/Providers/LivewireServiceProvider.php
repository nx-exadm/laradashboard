<?php

declare(strict_types=1);

namespace Modules\Forum\Providers;

use Illuminate\Support\ServiceProvider;
use Livewire\Livewire;

// Admin Components
use Modules\Forum\Livewire\Admin\Dashboard;
use Modules\Forum\Livewire\Admin\Categories\Index as CategoryIndex;
use Modules\Forum\Livewire\Admin\Categories\Create as CategoryCreate;
use Modules\Forum\Livewire\Admin\Categories\Edit as CategoryEdit;
use Modules\Forum\Livewire\Admin\Categories\Show as CategoryShow;
use Modules\Forum\Livewire\Admin\Topics\Index as TopicIndex;
use Modules\Forum\Livewire\Admin\Topics\Create as TopicCreate;
use Modules\Forum\Livewire\Admin\Topics\Edit as TopicEdit;
use Modules\Forum\Livewire\Admin\Topics\Show as TopicShow;
use Modules\Forum\Livewire\Admin\Replies\Index as ReplyIndex;
use Modules\Forum\Livewire\Admin\Replies\Create as ReplyCreate;
use Modules\Forum\Livewire\Admin\Replies\Edit as ReplyEdit;
use Modules\Forum\Livewire\Admin\Replies\Show as ReplyShow;

// Public Forum Components
use Modules\Forum\Livewire\Forum\Index as ForumIndex;
use Modules\Forum\Livewire\Forum\CategoryShow as ForumCategoryShow;
use Modules\Forum\Livewire\Forum\TopicShow as ForumTopicShow;
use Modules\Forum\Livewire\Forum\CreateTopic as ForumCreateTopic;
use Modules\Forum\Livewire\Forum\Search as ForumSearch;

// Datatable Components
use Modules\Forum\Livewire\Components\CategoryDatatable;
use Modules\Forum\Livewire\Components\TopicDatatable;
use Modules\Forum\Livewire\Components\ReplyDatatable;

class LivewireServiceProvider extends ServiceProvider
{
    /**
     * Register the service provider.
     */
    public function register(): void
    {
        //
    }

    /**
     * Boot the application events.
     */
    public function boot(): void
    {
        // Admin Livewire components
        Livewire::component('forum::admin.dashboard', Dashboard::class);

        // Admin Categories
        Livewire::component('forum::admin.categories.index', CategoryIndex::class);
        Livewire::component('forum::admin.categories.create', CategoryCreate::class);
        Livewire::component('forum::admin.categories.edit', CategoryEdit::class);
        Livewire::component('forum::admin.categories.show', CategoryShow::class);

        // Admin Topics
        Livewire::component('forum::admin.topics.index', TopicIndex::class);
        Livewire::component('forum::admin.topics.create', TopicCreate::class);
        Livewire::component('forum::admin.topics.edit', TopicEdit::class);
        Livewire::component('forum::admin.topics.show', TopicShow::class);

        // Admin Replies
        Livewire::component('forum::admin.replies.index', ReplyIndex::class);
        Livewire::component('forum::admin.replies.create', ReplyCreate::class);
        Livewire::component('forum::admin.replies.edit', ReplyEdit::class);
        Livewire::component('forum::admin.replies.show', ReplyShow::class);

        // Public Forum components
        Livewire::component('forum::forum.index', ForumIndex::class);
        Livewire::component('forum::forum.category-show', ForumCategoryShow::class);
        Livewire::component('forum::forum.topic-show', ForumTopicShow::class);
        Livewire::component('forum::forum.create-topic', ForumCreateTopic::class);
        Livewire::component('forum::forum.search', ForumSearch::class);

        // Datatable components
        Livewire::component('forum::components.category-datatable', CategoryDatatable::class);
        Livewire::component('forum::components.topic-datatable', TopicDatatable::class);
        Livewire::component('forum::components.reply-datatable', ReplyDatatable::class);
    }
}
