<?php

declare(strict_types=1);

namespace Modules\Forum\Services;

use App\Services\MenuService\AdminMenuItem;
use Illuminate\Support\Facades\Route;

class MenuService
{
    /**
     * Add the module menu to the admin sidebar.
     */
    public function addMenu(array $groups): array
    {
        $groups[__('Main')][] = $this->getMenu();

        return $groups;
    }

    /**
     * Get the module menu item.
     */
    public function getMenu(): AdminMenuItem
    {
        $menu = (new AdminMenuItem())->setAttributes([
            'label' => __('Forum'),
            'icon' => 'lucide:messages-square',
            'iconImage' => asset('images/modules/forum/logo.svg'),
            'route' => route('admin.forum.dashboard'),
            'active' => Route::is('admin.forum.*'),
            'id' => 'forum',
            'priority' => 50,
            'permissions' => [],
        ]);

        $menu->setChildren([
            (new AdminMenuItem())->setAttributes([
                'label' => __('Dashboard'),
                'route' => route('admin.forum.dashboard'),
                'active' => Route::is('admin.forum.dashboard'),
                'id' => 'forum-dashboard',
                'permissions' => [],
            ]),
            (new AdminMenuItem())->setAttributes([
                'label' => __('Categories'),
                'route' => route('admin.forum.categories.index'),
                'active' => Route::is('admin.forum.categories.*'),
                'id' => 'forum-categories',
                'permissions' => [],
            ]),
            (new AdminMenuItem())->setAttributes([
                'label' => __('Topics'),
                'route' => route('admin.forum.topics.index'),
                'active' => Route::is('admin.forum.topics.*'),
                'id' => 'forum-topics',
                'permissions' => [],
            ]),
            (new AdminMenuItem())->setAttributes([
                'label' => __('Replies'),
                'route' => route('admin.forum.replies.index'),
                'active' => Route::is('admin.forum.replies.*'),
                'id' => 'forum-replies',
                'permissions' => [],
            ]),
            (new AdminMenuItem())->setAttributes([
                'label' => __('Settings'),
                'route' => route('admin.forum.settings'),
                'active' => Route::is('admin.forum.settings'),
                'id' => 'forum-settings',
                'permissions' => [],
            ]),
        ]);

        return $menu;
    }
}
