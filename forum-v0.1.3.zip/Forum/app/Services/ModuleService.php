<?php

declare(strict_types=1);

namespace Modules\Forum\Services;

use App\Enums\Hooks\AdminFilterHook;
use App\Enums\Hooks\PermissionFilterHook;
use App\Support\Facades\Hook;

class ModuleService
{
    public function __construct(
        private readonly MenuService $menuService
    ) {
    }

    /**
     * Bootstrap the module services.
     */
    public function bootstrap(): void
    {
        // Register sidebar menu
        Hook::addFilter(AdminFilterHook::ADMIN_MENU_GROUPS_BEFORE_SORTING, [$this->menuService, 'addMenu']);

        // Register permissions
        Hook::addFilter(PermissionFilterHook::PERMISSION_GROUPS, [$this, 'addPermissions']);

        // Add Forum to Quick Links dropdown
        Hook::addFilter(AdminFilterHook::QUICK_LINKS_DROPDOWN, [$this, 'addQuickLink']);
    }

    /**
     * Add Forum link to Quick Links dropdown.
     */
    public function addQuickLink(array $links): array
    {
        $forumBaseUrl = config('settings.forum_base_url', '/forum') ?: '/forum';
        $forumTitle = config('settings.forum_title', 'Forum') ?: 'Forum';

        $links[] = [
            'label' => __($forumTitle),
            'url' => url($forumBaseUrl),
            'icon' => 'lucide:messages-square',
            'target' => '_blank',
        ];

        return $links;
    }

    /**
     * Add module permissions to the permission groups.
     */
    public function addPermissions(array $groups): array
    {
        return array_merge($groups, $this->getPermissions());
    }

    /**
     * Get the module permission definitions.
     * Add permissions here when needed, e.g.:
     * ['group_name' => 'forum', 'permissions' => ['forum.dashboard', 'forum.settings']]
     */
    public static function getPermissions(): array
    {
        return [];
    }
}
