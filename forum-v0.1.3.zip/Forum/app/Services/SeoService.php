<?php

declare(strict_types=1);

namespace Modules\Forum\Services;

use Modules\Forum\Models\Category;
use Modules\Forum\Models\Topic;

class SeoService
{
    /**
     * Get SEO data for the forum homepage.
     */
    public static function forHomepage(): array
    {
        $siteName = config('app.name');
        $forumTitle = config('settings.forum_title') ?: __('Forum');
        $forumDescription = config('settings.forum_description') ?: __('Join the discussion, ask questions, and share your knowledge with the community.');

        $title = $forumTitle.' - '.$siteName;
        $url = route('forum.index');

        return [
            'title' => $title,
            'description' => $forumDescription,
            'canonical' => $url,
            'og' => [
                'title' => $title,
                'description' => $forumDescription,
                'type' => 'website',
                'url' => $url,
                'site_name' => $siteName,
            ],
            'twitter' => [
                'card' => 'summary_large_image',
                'title' => $title,
                'description' => $forumDescription,
            ],
            'jsonLd' => [
                self::websiteSchema(),
                self::organizationSchema(),
                self::breadcrumbSchema([
                    ['name' => __('Home'), 'url' => config('app.url')],
                    ['name' => $forumTitle, 'url' => $url],
                ]),
            ],
        ];
    }

    /**
     * Get SEO data for a category page.
     */
    public static function forCategory(Category $category): array
    {
        $siteName = config('app.name');
        $forumTitle = config('settings.forum_title') ?: __('Forum');

        $title = $category->name.' - '.$forumTitle.' - '.$siteName;
        $description = $category->description ?: __('Browse topics in :category', ['category' => $category->name]);
        $url = route('forum.category', $category->slug);

        return [
            'title' => $title,
            'description' => self::truncate($description, 160),
            'canonical' => $url,
            'og' => [
                'title' => $title,
                'description' => self::truncate($description, 160),
                'type' => 'website',
                'url' => $url,
                'site_name' => $siteName,
            ],
            'twitter' => [
                'card' => 'summary',
                'title' => $title,
                'description' => self::truncate($description, 160),
            ],
            'jsonLd' => [
                self::collectionPageSchema($category),
                self::breadcrumbSchema([
                    ['name' => __('Home'), 'url' => config('app.url')],
                    ['name' => $forumTitle, 'url' => route('forum.index')],
                    ['name' => $category->name, 'url' => $url],
                ]),
            ],
        ];
    }

    /**
     * Get SEO data for a topic page.
     */
    public static function forTopic(Category $category, Topic $topic): array
    {
        $siteName = config('app.name');
        $forumTitle = config('settings.forum_title') ?: __('Forum');

        $title = $topic->title.' - '.$forumTitle.' - '.$siteName;
        $description = self::truncate(strip_tags($topic->content), 160);
        $url = route('forum.topic', [$category->slug, $topic->slug]);

        return [
            'title' => $title,
            'description' => $description,
            'canonical' => $url,
            'og' => [
                'title' => $topic->title,
                'description' => $description,
                'type' => 'article',
                'url' => $url,
                'site_name' => $siteName,
                'article' => [
                    'published_time' => $topic->created_at->toIso8601String(),
                    'modified_time' => $topic->updated_at->toIso8601String(),
                    'author' => $topic->user->full_name,
                    'section' => $category->name,
                ],
            ],
            'twitter' => [
                'card' => 'summary',
                'title' => $topic->title,
                'description' => $description,
            ],
            'jsonLd' => [
                self::discussionForumPostingSchema($category, $topic),
                self::breadcrumbSchema([
                    ['name' => __('Home'), 'url' => config('app.url')],
                    ['name' => $forumTitle, 'url' => route('forum.index')],
                    ['name' => $category->name, 'url' => route('forum.category', $category->slug)],
                    ['name' => $topic->title, 'url' => $url],
                ]),
            ],
        ];
    }

    /**
     * Get SEO data for the create topic page.
     */
    public static function forCreateTopic(?Category $category = null): array
    {
        $siteName = config('app.name');
        $forumTitle = config('settings.forum_title') ?: __('Forum');

        $title = $category
            ? __('Create Topic in :category', ['category' => $category->name]).' - '.$forumTitle.' - '.$siteName
            : __('Create Topic').' - '.$forumTitle.' - '.$siteName;

        $description = __('Start a new discussion in the forum.');
        $url = $category ? route('forum.create.category', $category->slug) : route('forum.create');

        $breadcrumbs = [
            ['name' => __('Home'), 'url' => config('app.url')],
            ['name' => $forumTitle, 'url' => route('forum.index')],
        ];

        if ($category) {
            $breadcrumbs[] = ['name' => $category->name, 'url' => route('forum.category', $category->slug)];
        }

        $breadcrumbs[] = ['name' => __('Create Topic'), 'url' => $url];

        return [
            'title' => $title,
            'description' => $description,
            'canonical' => $url,
            'robots' => 'noindex, follow', // Don't index create forms
            'og' => [
                'title' => $title,
                'description' => $description,
                'type' => 'website',
                'url' => $url,
                'site_name' => $siteName,
            ],
            'twitter' => [
                'card' => 'summary',
                'title' => $title,
                'description' => $description,
            ],
            'jsonLd' => [
                self::breadcrumbSchema($breadcrumbs),
            ],
        ];
    }

    /**
     * Get SEO data for the search page.
     */
    public static function forSearch(?string $query = null): array
    {
        $siteName = config('app.name');
        $forumTitle = config('settings.forum_title') ?: __('Forum');

        $title = $query
            ? __('Search results for ":query"', ['query' => $query]).' - '.$forumTitle.' - '.$siteName
            : __('Search').' - '.$forumTitle.' - '.$siteName;

        $description = $query
            ? __('Search results for ":query" in the forum.', ['query' => $query])
            : __('Search topics and discussions in the forum.');

        $url = $query ? route('forum.search', ['q' => $query]) : route('forum.search');

        return [
            'title' => $title,
            'description' => $description,
            'canonical' => $url,
            'robots' => 'noindex, follow', // Don't index search results
            'og' => [
                'title' => $title,
                'description' => $description,
                'type' => 'website',
                'url' => $url,
                'site_name' => $siteName,
            ],
            'twitter' => [
                'card' => 'summary',
                'title' => $title,
                'description' => $description,
            ],
            'jsonLd' => [
                self::searchActionSchema(),
                self::breadcrumbSchema([
                    ['name' => __('Home'), 'url' => config('app.url')],
                    ['name' => $forumTitle, 'url' => route('forum.index')],
                    ['name' => __('Search'), 'url' => route('forum.search')],
                ]),
            ],
        ];
    }

    /**
     * Generate WebSite schema.
     */
    protected static function websiteSchema(): array
    {
        return [
            '@context' => 'https://schema.org',
            '@type' => 'WebSite',
            'name' => config('app.name'),
            'url' => config('app.url'),
            'potentialAction' => [
                '@type' => 'SearchAction',
                'target' => [
                    '@type' => 'EntryPoint',
                    'urlTemplate' => route('forum.search').'?q={search_term_string}',
                ],
                'query-input' => 'required name=search_term_string',
            ],
        ];
    }

    /**
     * Generate Organization schema.
     */
    protected static function organizationSchema(): array
    {
        return [
            '@context' => 'https://schema.org',
            '@type' => 'Organization',
            'name' => config('app.name'),
            'url' => config('app.url'),
        ];
    }

    /**
     * Generate BreadcrumbList schema.
     */
    protected static function breadcrumbSchema(array $items): array
    {
        $listItems = [];
        foreach ($items as $index => $item) {
            $listItems[] = [
                '@type' => 'ListItem',
                'position' => $index + 1,
                'name' => $item['name'],
                'item' => $item['url'],
            ];
        }

        return [
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => $listItems,
        ];
    }

    /**
     * Generate CollectionPage schema for category.
     */
    protected static function collectionPageSchema(Category $category): array
    {
        return [
            '@context' => 'https://schema.org',
            '@type' => 'CollectionPage',
            'name' => $category->name,
            'description' => $category->description,
            'url' => route('forum.category', $category->slug),
            'isPartOf' => [
                '@type' => 'WebSite',
                'name' => config('app.name'),
                'url' => config('app.url'),
            ],
        ];
    }

    /**
     * Generate DiscussionForumPosting schema for topic.
     */
    protected static function discussionForumPostingSchema(Category $category, Topic $topic): array
    {
        $schema = [
            '@context' => 'https://schema.org',
            '@type' => 'DiscussionForumPosting',
            'headline' => $topic->title,
            'text' => self::truncate(strip_tags($topic->content), 500),
            'url' => route('forum.topic', [$category->slug, $topic->slug]),
            'datePublished' => $topic->created_at->toIso8601String(),
            'dateModified' => $topic->updated_at->toIso8601String(),
            'author' => [
                '@type' => 'Person',
                'name' => $topic->user->full_name,
            ],
            'interactionStatistic' => [
                [
                    '@type' => 'InteractionCounter',
                    'interactionType' => 'https://schema.org/ViewAction',
                    'userInteractionCount' => $topic->views_count,
                ],
                [
                    '@type' => 'InteractionCounter',
                    'interactionType' => 'https://schema.org/CommentAction',
                    'userInteractionCount' => $topic->replies_count,
                ],
                [
                    '@type' => 'InteractionCounter',
                    'interactionType' => 'https://schema.org/LikeAction',
                    'userInteractionCount' => $topic->likes_count,
                ],
            ],
            'discussionUrl' => route('forum.topic', [$category->slug, $topic->slug]),
            'isPartOf' => [
                '@type' => 'DiscussionForumPosting',
                'name' => $category->name,
                'url' => route('forum.category', $category->slug),
            ],
        ];

        // Add solution/accepted answer if exists
        if ($topic->is_solved && $topic->solution) {
            $schema['acceptedAnswer'] = [
                '@type' => 'Answer',
                'text' => self::truncate(strip_tags($topic->solution->content), 500),
                'dateCreated' => $topic->solution->created_at->toIso8601String(),
                'author' => [
                    '@type' => 'Person',
                    'name' => $topic->solution->user->full_name,
                ],
                'upvoteCount' => $topic->solution->likes_count,
            ];
        }

        return $schema;
    }

    /**
     * Generate SearchAction schema.
     */
    protected static function searchActionSchema(): array
    {
        return [
            '@context' => 'https://schema.org',
            '@type' => 'WebSite',
            'url' => route('forum.index'),
            'potentialAction' => [
                '@type' => 'SearchAction',
                'target' => [
                    '@type' => 'EntryPoint',
                    'urlTemplate' => route('forum.search').'?q={search_term_string}',
                ],
                'query-input' => 'required name=search_term_string',
            ],
        ];
    }

    /**
     * Truncate text to a specified length.
     */
    protected static function truncate(string $text, int $length): string
    {
        $text = trim(preg_replace('/\s+/', ' ', $text));

        if (strlen($text) <= $length) {
            return $text;
        }

        return substr($text, 0, $length - 3).'...';
    }
}
