# Forum Module - Architecture & Progress

## Overview
A community discussion forum module for LaraDashboard with categories, topics, replies, and engagement features.

## Progress Tracker

### Phase 1 - Core Features
- [x] Module setup (`php artisan module:make Forum`)
- [x] Database migrations
  - [x] `forum_categories` table
  - [x] `forum_topics` table
  - [x] `forum_replies` table
- [x] Admin CRUD
  - [x] Category management (Index, Create, Edit, Delete)
  - [x] Topic management (Index, Show, Edit, Delete)
  - [x] Reply management (Index, Show, Edit, Delete)
- [x] Public Forum Pages
  - [x] Forum index (list categories)
  - [x] Category page (list topics)
  - [x] Topic page (view topic + replies)
  - [x] Create topic form
  - [x] Reply form
  - [x] Search page
- [x] Core Features
  - [x] View count tracking (in TopicShow component)
  - [x] Pin topics (model methods ready)
  - [x] Lock topics (model methods ready)
  - [ ] Markdown support (basic nl2br for now)
  - [x] User attribution (author display)

### Phase 2 - Engagement Features
- [x] Database migrations
  - [x] `forum_likes` table
- [x] Like System
  - [x] Like topics
  - [x] Like replies
  - [x] Like counts display
- [x] Mark as Solved
  - [x] Mark reply as solution
  - [x] Solved badge on topic
  - [x] Filter solved/unsolved
- [ ] Mentions
  - [ ] @username detection
  - [ ] Notifications (if notification system exists)
- [ ] User Stats
  - [ ] Topics count
  - [ ] Replies count
  - [ ] User profile page

### Phase 3 - UI Polish
- [x] Updated all forum views to use consistent CSS component classes
  - [x] `card`, `card-header`, `card-body`, `card-footer`
  - [x] `btn-primary`, `btn-secondary`
  - [x] `badge`, `badge-success`, `badge-warning`, `badge-danger`, `badge-primary`
  - [x] `form-control`, `form-control-textarea`, `form-label`
  - [x] `page-title`, `page-description`, `section-title`
  - [x] `link`, `link-secondary`
  - [x] `alert`, `alert-warning`
  - [x] `prose` for content rendering

### TODO - Remaining Work
- [ ] Add pin/lock toggle buttons in admin topic view
- [ ] Add markdown rendering (integrate with existing markdown service)
- [ ] Add @mentions detection and notifications
- [ ] Add user profile page with forum stats
- [ ] Add tests

---

## Database Schema

### forum_categories
```
id                  - bigint, primary key
name                - string(255)
slug                - string(255), unique
description         - text, nullable
icon                - string(100), nullable (lucide icon name)
color               - string(50), nullable (hex or tailwind color)
order               - integer, default 0
is_active           - boolean, default true
topics_count        - integer, default 0 (cached)
posts_count         - integer, default 0 (cached)
last_topic_id       - bigint, nullable, foreign key
created_at          - timestamp
updated_at          - timestamp
```

### forum_topics
```
id                  - bigint, primary key
category_id         - bigint, foreign key -> forum_categories
user_id             - bigint, foreign key -> users
title               - string(255)
slug                - string(255)
content             - text
views_count         - integer, default 0
replies_count       - integer, default 0 (cached)
likes_count         - integer, default 0 (cached)
is_pinned           - boolean, default false
is_locked           - boolean, default false
is_solved           - boolean, default false
solved_reply_id     - bigint, nullable, foreign key
last_reply_at       - timestamp, nullable
last_reply_user_id  - bigint, nullable, foreign key
created_at          - timestamp
updated_at          - timestamp
```

### forum_replies
```
id                  - bigint, primary key
topic_id            - bigint, foreign key -> forum_topics
user_id             - bigint, foreign key -> users
parent_id           - bigint, nullable, foreign key -> forum_replies (nested)
content             - text
likes_count         - integer, default 0 (cached)
is_solution         - boolean, default false
created_at          - timestamp
updated_at          - timestamp
deleted_at          - timestamp, nullable (soft delete)
```

### forum_likes
```
id                  - bigint, primary key
user_id             - bigint, foreign key -> users
likeable_type       - string (Topic or Reply)
likeable_id         - bigint
created_at          - timestamp
updated_at          - timestamp

unique index: (user_id, likeable_type, likeable_id)
```

---

## Routes

### Admin Routes (prefix: /admin/forum)
| Method | URI | Name | Description |
|--------|-----|------|-------------|
| GET | `/admin/forum` | `admin.forum.dashboard` | Dashboard/stats |
| GET | `/admin/forum/categories` | `admin.forum.categories.index` | List categories |
| GET | `/admin/forum/categories/create` | `admin.forum.categories.create` | Create category |
| GET | `/admin/forum/categories/{id}` | `admin.forum.categories.show` | View category |
| GET | `/admin/forum/categories/{id}/edit` | `admin.forum.categories.edit` | Edit category |
| GET | `/admin/forum/topics` | `admin.forum.topics.index` | List all topics |
| GET | `/admin/forum/topics/{id}` | `admin.forum.topics.show` | View topic |
| GET | `/admin/forum/topics/{id}/edit` | `admin.forum.topics.edit` | Edit topic |
| GET | `/admin/forum/replies` | `admin.forum.replies.index` | List all replies |
| GET | `/admin/forum/replies/{id}` | `admin.forum.replies.show` | View reply |
| GET | `/admin/forum/replies/{id}/edit` | `admin.forum.replies.edit` | Edit reply |

### Public Routes (prefix: /forum)
| Method | URI | Name | Description |
|--------|-----|------|-------------|
| GET | `/forum` | `forum.index` | All categories |
| GET | `/forum/search` | `forum.search` | Search forum |
| GET | `/forum/new` | `forum.create` | Create topic form |
| GET | `/forum/new/{category}` | `forum.create.category` | Create topic in category |
| GET | `/forum/{category:slug}` | `forum.category` | Topics in category |
| GET | `/forum/{category:slug}/{topic:slug}` | `forum.topic` | Single topic |

---

## File Structure
```
modules/Forum/
├── app/
│   ├── Http/
│   │   └── Controllers/
│   │       └── ForumController.php
│   ├── Livewire/
│   │   ├── Admin/
│   │   │   ├── Dashboard.php
│   │   │   ├── Categories/
│   │   │   │   ├── Index.php
│   │   │   │   ├── Create.php
│   │   │   │   ├── Edit.php
│   │   │   │   └── Show.php
│   │   │   ├── Topics/
│   │   │   │   ├── Index.php
│   │   │   │   ├── Create.php
│   │   │   │   ├── Edit.php
│   │   │   │   └── Show.php
│   │   │   └── Replies/
│   │   │       ├── Index.php
│   │   │       ├── Create.php
│   │   │       ├── Edit.php
│   │   │       └── Show.php
│   │   ├── Forum/
│   │   │   ├── Index.php (category list)
│   │   │   ├── CategoryShow.php (topics list)
│   │   │   ├── TopicShow.php (single topic + replies)
│   │   │   ├── CreateTopic.php
│   │   │   └── Search.php
│   │   └── Components/
│   │       ├── CategoryDatatable.php
│   │       ├── TopicDatatable.php
│   │       └── ReplyDatatable.php
│   ├── Models/
│   │   ├── Category.php
│   │   ├── Topic.php
│   │   ├── Reply.php
│   │   └── Like.php
│   ├── Providers/
│   │   ├── ForumServiceProvider.php
│   │   ├── LivewireServiceProvider.php
│   │   ├── RouteServiceProvider.php
│   │   └── EventServiceProvider.php
│   └── Services/
│       ├── ModuleService.php
│       └── MenuService.php
├── config/
│   └── config.php
├── database/
│   ├── migrations/
│   │   ├── 2026_02_14_182041_create_forum_categories_table.php
│   │   ├── 2026_02_14_182047_create_forum_topics_table.php
│   │   ├── 2026_02_14_182051_create_forum_replies_table.php
│   │   └── 2026_02_14_182104_create_forum_likes_table.php
│   └── seeders/
│       └── ForumDatabaseSeeder.php
├── resources/
│   └── views/
│       ├── layouts/
│       │   ├── admin.blade.php
│       │   ├── crud.blade.php
│       │   ├── master.blade.php
│       │   └── forum.blade.php (public layout)
│       └── livewire/
│           ├── admin/
│           │   ├── dashboard.blade.php
│           │   ├── categories/
│           │   ├── topics/
│           │   └── replies/
│           └── forum/
│               ├── index.blade.php
│               ├── category-show.blade.php
│               ├── topic-show.blade.php
│               ├── create-topic.blade.php
│               └── search.blade.php
├── routes/
│   ├── web.php
│   └── api.php
├── tests/
├── composer.json
├── module.json
├── description.md
├── architecture.md (this file)
└── vite.config.js
```

---

## Permissions (TODO)

| Permission | Description |
|------------|-------------|
| `forum.view` | View forum admin |
| `forum.categories.create` | Create categories |
| `forum.categories.edit` | Edit categories |
| `forum.categories.delete` | Delete categories |
| `forum.topics.view` | View all topics in admin |
| `forum.topics.edit` | Edit any topic |
| `forum.topics.delete` | Delete any topic |
| `forum.topics.pin` | Pin/unpin topics |
| `forum.topics.lock` | Lock/unlock topics |
| `forum.replies.delete` | Delete any reply |
| `forum.settings` | Manage forum settings |

---

## Commands Executed

```bash
# Module creation
[x] php artisan module:make Forum

# CRUD generation
[x] php artisan module:make-crud Forum --model=Category --fields="name:string,slug:string,description:text,icon:string,color:string,order:integer,is_active:toggle"
[x] php artisan module:make-crud Forum --model=Topic --fields="title:string,slug:string,content:editor,views_count:integer,replies_count:integer,is_pinned:toggle,is_locked:toggle,is_solved:toggle"
[x] php artisan module:make-crud Forum --model=Reply --fields="content:editor,likes_count:integer,is_solution:toggle"
[x] php artisan module:make-migration create_forum_likes_table Forum

# Run migrations
[x] php artisan migrate

# Clear cache
[x] php artisan optimize:clear

# Format code
[x] ./vendor/bin/pint modules/Forum --dirty
```

---

## Action Hooks

The Forum module provides action hooks for layout customization. Use these to inject custom navbars, footers, or content.

### Available Layout Hooks

| Hook | Description |
|------|-------------|
| `LAYOUT_BODY_START` | Very beginning of body tag |
| `LAYOUT_BEFORE_HEADER` | Before forum header - **perfect for main site navbar** |
| `LAYOUT_AFTER_HEADER` | After forum header |
| `LAYOUT_BEFORE_CONTENT` | Before main content |
| `LAYOUT_AFTER_CONTENT` | After main content |
| `LAYOUT_BEFORE_FOOTER` | Before forum footer |
| `LAYOUT_AFTER_FOOTER` | After forum footer - **perfect for main site footer** |
| `LAYOUT_BODY_END` | End of body tag |
| `LAYOUT_HEAD` | Inside `<head>` for styles/scripts |

### Example: Add Main Site Navbar

In LaraDashboard core `AppServiceProvider` or a dedicated provider:

```php
use Modules\Forum\Enums\ForumActionHook;

// Add main site navbar above forum
ld_add_action(ForumActionHook::LAYOUT_BEFORE_HEADER, function () {
    echo view('components.frontend-navbar')->render();
}, priority: 10);

// Add main site footer below forum
ld_add_action(ForumActionHook::LAYOUT_AFTER_FOOTER, function () {
    echo view('components.frontend-footer')->render();
}, priority: 10);
```

---

## Notes

- Using Livewire 3 for all components
- Following LaraDashboard module conventions
- Public forum uses separate layout from admin
- Basic content rendering with nl2br (markdown TODO)
- Real-time updates for replies using Livewire
- Like system uses polymorphic relationships
- Nested replies supported (one level)
- View count increments on topic page load
- Extensible via action hooks for layout customization
