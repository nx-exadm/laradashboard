<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('forum_topics', function (Blueprint $table) {
            $table->id();
            $table->foreignId('category_id')->constrained('forum_categories')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('title');
            $table->string('slug');
            $table->text('content');
            $table->unsignedInteger('views_count')->default(0);
            $table->unsignedInteger('replies_count')->default(0);
            $table->unsignedInteger('likes_count')->default(0);
            $table->boolean('is_pinned')->default(false);
            $table->boolean('is_locked')->default(false);
            $table->boolean('is_solved')->default(false);
            $table->unsignedBigInteger('solved_reply_id')->nullable();
            $table->timestamp('last_reply_at')->nullable();
            $table->unsignedBigInteger('last_reply_user_id')->nullable();
            $table->timestamps();

            $table->unique(['category_id', 'slug']);
            $table->index(['category_id', 'is_pinned', 'last_reply_at']);
            $table->index(['user_id', 'created_at']);
            $table->index(['is_solved', 'created_at']);

            $table->foreign('last_reply_user_id')
                ->references('id')
                ->on('users')
                ->nullOnDelete();
        });

        // Add foreign key for last_topic_id in categories after topics table exists
        Schema::table('forum_categories', function (Blueprint $table) {
            $table->foreign('last_topic_id')
                ->references('id')
                ->on('forum_topics')
                ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('forum_categories', function (Blueprint $table) {
            $table->dropForeign(['last_topic_id']);
        });

        Schema::dropIfExists('forum_topics');
    }
};
