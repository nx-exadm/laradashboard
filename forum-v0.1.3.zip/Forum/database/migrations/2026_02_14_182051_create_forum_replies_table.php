<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('forum_replies', function (Blueprint $table) {
            $table->id();
            $table->foreignId('topic_id')->constrained('forum_topics')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->unsignedBigInteger('parent_id')->nullable();
            $table->text('content');
            $table->unsignedInteger('likes_count')->default(0);
            $table->boolean('is_solution')->default(false);
            $table->timestamps();
            $table->softDeletes();

            $table->index(['topic_id', 'created_at']);
            $table->index(['user_id', 'created_at']);
            $table->index(['parent_id']);

            $table->foreign('parent_id')
                ->references('id')
                ->on('forum_replies')
                ->nullOnDelete();
        });

        // Add foreign key for solved_reply_id in topics after replies table exists
        Schema::table('forum_topics', function (Blueprint $table) {
            $table->foreign('solved_reply_id')
                ->references('id')
                ->on('forum_replies')
                ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('forum_topics', function (Blueprint $table) {
            $table->dropForeign(['solved_reply_id']);
        });

        Schema::dropIfExists('forum_replies');
    }
};
