<?php

namespace Modules\Forum\Database\Seeders;

use Illuminate\Database\Seeder;
use Modules\Forum\Models\Category;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categories = [
            [
                'name' => 'Announcements',
                'slug' => 'announcements',
                'description' => 'Official announcements, updates, and important news.',
                'icon' => 'lucide:megaphone',
                'color' => 'blue',
                'order' => 1,
                'is_active' => true,
            ],
            [
                'name' => 'General Discussion',
                'slug' => 'general-discussion',
                'description' => 'Chat about anything. Introduce yourself, share tips, and connect with the community.',
                'icon' => 'lucide:messages-square',
                'color' => 'gray',
                'order' => 2,
                'is_active' => true,
            ],
            [
                'name' => 'Help & Support',
                'slug' => 'help-support',
                'description' => 'Need help? Ask questions and get assistance from the community.',
                'icon' => 'lucide:help-circle',
                'color' => 'purple',
                'order' => 3,
                'is_active' => true,
            ],
            [
                'name' => 'Feature Requests',
                'slug' => 'feature-requests',
                'description' => 'Have an idea for a new feature? Share your suggestions and vote on others.',
                'icon' => 'lucide:lightbulb',
                'color' => 'yellow',
                'order' => 4,
                'is_active' => true,
            ],
            [
                'name' => 'Bug Reports',
                'slug' => 'bug-reports',
                'description' => 'Found a bug? Report it here with steps to reproduce.',
                'icon' => 'lucide:bug',
                'color' => 'red',
                'order' => 5,
                'is_active' => true,
            ],
            [
                'name' => 'Showcase',
                'slug' => 'showcase',
                'description' => 'Show off what you\'ve built! Share your projects, screenshots, and success stories.',
                'icon' => 'lucide:sparkles',
                'color' => 'orange',
                'order' => 6,
                'is_active' => true,
            ],
        ];

        foreach ($categories as $data) {
            Category::updateOrCreate(
                ['slug' => $data['slug']],
                $data
            );
        }
    }
}
