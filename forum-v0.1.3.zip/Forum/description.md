# Forum Module

A full-featured community forum module for LaraDashboard that enables discussions, Q&A, and community engagement.

## Overview

The Forum module provides a complete discussion platform where users can create topics, reply to discussions, and interact with community content. It includes both a public-facing forum interface and a comprehensive admin panel for moderation.

## Features

### For Users (Frontend)

- **Browse Categories** - Explore topics organized by categories with custom icons and colors
- **Create Topics** - Start new discussions with a rich text editor (supports images, formatting, links)
- **Reply to Topics** - Engage in conversations with threaded/nested replies
- **Like Content** - Like topics and replies to show appreciation
- **Search** - Find topics and discussions quickly with full-text search
- **User Profiles** - See topic authors and their activity
- **Solved Indicator** - Easily identify topics that have accepted solutions
- **Dark Mode** - Full dark mode support for comfortable reading

### For Administrators (Backend)

- **Dashboard** - Overview of forum activity and statistics
- **Category Management** - Create, edit, reorder, and manage forum categories
  - Custom icons (using Iconify)
  - Custom colors for visual distinction
  - Enable/disable categories
  - Drag-and-drop ordering
- **Topic Management** - Full control over all topics
  - Pin important topics to the top
  - Lock topics to prevent new replies
  - Mark topics as solved
  - Edit or delete any topic
- **Reply Management** - Moderate all replies
  - Mark replies as solutions
  - Edit or delete replies
  - Manage nested reply threads
- **Settings** - Configure forum behavior and appearance

### Technical Features

- **SEO-Friendly URLs** - Clean slugs for categories and topics
- **View Tracking** - Automatic view count for topics
- **Soft Deletes** - Replies use soft deletes for data safety
- **Optimized Queries** - Indexed database for fast performance
- **RESTful API** - API endpoints for external integrations
- **Livewire Powered** - Real-time updates without page refreshes

## Installation

This module is part of the LaraDashboard ecosystem.

```bash
# Enable the module
php artisan module:enable Forum

# Run migrations
php artisan module:migrate Forum

# Seed sample data (optional)
php artisan module:seed Forum
```

## Configuration

Configuration options can be found in `config/config.php`.

## Usage

### Frontend Routes

| URL | Description |
|-----|-------------|
| `/forums` | Forum homepage - list all categories |
| `/forums/search?q=keyword` | Search topics |
| `/forums/new` | Create a new topic |
| `/forums/{category}` | View topics in a category |
| `/forums/{category}/{topic}` | View a topic and its replies |

### Admin Routes

| URL | Description |
|-----|-------------|
| `/admin/forum` | Forum admin dashboard |
| `/admin/forum/categories` | Manage categories |
| `/admin/forum/topics` | Manage all topics |
| `/admin/forum/replies` | Manage all replies |
| `/admin/forum/settings` | Forum settings |

## Permissions

| Permission | Description |
|------------|-------------|
| `forum.dashboard` | Access forum admin dashboard |
| `forum.categories.view` | View categories |
| `forum.categories.create` | Create categories |
| `forum.categories.edit` | Edit categories |
| `forum.categories.delete` | Delete categories |
| `forum.topics.view` | View topics in admin |
| `forum.topics.create` | Create topics |
| `forum.topics.edit` | Edit any topic |
| `forum.topics.delete` | Delete topics |
| `forum.replies.view` | View replies in admin |
| `forum.replies.create` | Create replies |
| `forum.replies.edit` | Edit any reply |
| `forum.replies.delete` | Delete replies |
| `forum.settings` | Manage forum settings |

## Database Structure

- **forum_categories** - Forum categories/boards
- **forum_topics** - Discussion topics/threads
- **forum_replies** - Replies to topics (supports nesting)
- **forum_likes** - Likes on topics and replies (polymorphic)

## Screenshots

*Add screenshots of your forum here*

## License

This module is proprietary software. See LICENSE file for details.
