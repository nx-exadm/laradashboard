@props(['stats'])

<div class="mb-6 grid grid-cols-2 gap-4 md:grid-cols-4">
    @foreach($stats as $stat)
        @php
            $colors = [
                'primary' => 'bg-primary-50 text-primary-600 dark:bg-primary-900/20 dark:text-primary-400',
                'green' => 'bg-green-50 text-green-600 dark:bg-green-900/20 dark:text-green-400',
                'blue' => 'bg-blue-50 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400',
                'amber' => 'bg-amber-50 text-amber-600 dark:bg-amber-900/20 dark:text-amber-400',
                'rose' => 'bg-rose-50 text-rose-600 dark:bg-rose-900/20 dark:text-rose-400',
                'indigo' => 'bg-indigo-50 text-indigo-600 dark:bg-indigo-900/20 dark:text-indigo-400',
            ];
            $colorClass = $colors[$stat['color']] ?? $colors['primary'];
        @endphp
        <div class="flex items-center gap-3 rounded-xl bg-white p-4 shadow-sm dark:bg-gray-800">
            <div class="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg {{ $colorClass }}">
                <iconify-icon icon="{{ $stat['icon'] }}" class="text-2xl"></iconify-icon>
            </div>
            <div class="min-w-0">
                <p class="text-2xl font-bold text-gray-900 dark:text-white">{{ $stat['value'] }}</p>
                <p class="truncate text-sm text-gray-500 dark:text-gray-400">{{ $stat['label'] }}</p>
            </div>
        </div>
    @endforeach
</div>
