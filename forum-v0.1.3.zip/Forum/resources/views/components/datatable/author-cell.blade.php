@if($user)
<div class="flex items-center gap-2">
    <img
        src="{{ $user->avatar_url }}"
        alt="{{ $user->full_name }}"
        class="h-7 w-7 rounded-full object-cover"
    />
    <span class="truncate text-sm text-gray-700 dark:text-gray-300">{{ $user->full_name }}</span>
</div>
@else
<span class="text-sm text-gray-400 italic">{{ __('Unknown') }}</span>
@endif
