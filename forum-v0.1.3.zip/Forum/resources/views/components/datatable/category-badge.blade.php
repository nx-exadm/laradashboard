@if($category)
<span class="inline-flex items-center gap-1.5 rounded-full bg-purple-100 px-2.5 py-1 text-xs font-medium text-purple-700 dark:bg-purple-900/30 dark:text-purple-400">
    <iconify-icon icon="lucide:folder" class="text-sm"></iconify-icon>
    {{ $category->name }}
</span>
@else
<span class="text-sm text-gray-400 italic">{{ __('None') }}</span>
@endif
