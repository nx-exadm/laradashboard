<a href="{{ route('admin.forum.categories.edit', $item) }}" class="flex items-center gap-3 group">
    <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-100 dark:bg-primary-900/30">
        <iconify-icon icon="lucide:folder" class="h-5 w-5 text-primary-600 dark:text-primary-400"></iconify-icon>
    </div>
    <div class="min-w-0 flex-1">
        <div class="flex items-center gap-2">
            <p class="truncate font-medium text-gray-900 dark:text-white group-hover:text-primary-600 dark:group-hover:text-primary-400">{{ $item->name }}</p>
            @if($item->order > 0)
                <span class="inline-flex items-center rounded bg-gray-100 px-1.5 py-0.5 text-xs font-medium text-gray-600 dark:bg-gray-700 dark:text-gray-300">
                    #{{ $item->order }}
                </span>
            @endif
        </div>
        <p class="truncate text-sm text-gray-500 dark:text-gray-400">/{{ $item->slug }}</p>
        @if($item->description)
            <p class="mt-0.5 truncate text-xs text-gray-400 dark:text-gray-500">{{ Str::limit($item->description, 50) }}</p>
        @endif
    </div>
</a>
