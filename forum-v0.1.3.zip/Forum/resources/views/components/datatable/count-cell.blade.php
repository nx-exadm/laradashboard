<div class="text-center">
    <span class="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-sm font-medium {{ $count > 0 ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' : 'bg-gray-100 text-gray-500 dark:bg-gray-700 dark:text-gray-400' }}">
        <span>{{ number_format($count) }}</span>
    </span>
</div>
