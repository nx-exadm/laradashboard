<div class="flex justify-center">
    <span class="inline-flex items-center gap-1 {{ $likes > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-gray-400 dark:text-gray-500' }}">
        <iconify-icon icon="lucide:heart" class="text-base {{ $likes > 0 ? 'fill-current' : '' }}"></iconify-icon>
        <span class="text-sm font-medium">{{ number_format($likes) }}</span>
    </span>
</div>
