<div class="flex justify-center">
    <span class="inline-flex h-7 w-7 items-center justify-center rounded-md bg-gray-100 text-sm font-medium text-gray-700 dark:bg-gray-700 dark:text-gray-300">
        {{ $order }}
    </span>
</div>
