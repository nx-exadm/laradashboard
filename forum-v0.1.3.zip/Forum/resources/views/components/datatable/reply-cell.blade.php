<a href="{{ route('admin.forum.replies.edit', $item) }}" class="flex items-start gap-3 group">
    <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg {{ $item->is_solution ? 'bg-green-100 dark:bg-green-900/30' : 'bg-gray-100 dark:bg-gray-700' }}">
        <iconify-icon icon="{{ $item->is_solution ? 'lucide:check-circle-2' : 'lucide:message-square' }}" class="text-xl {{ $item->is_solution ? 'text-green-600 dark:text-green-400' : 'text-gray-500 dark:text-gray-400' }}"></iconify-icon>
    </div>
    <div class="min-w-0 flex-1">
        <p class="line-clamp-2 text-sm text-gray-700 dark:text-gray-300 group-hover:text-primary-600 dark:group-hover:text-primary-400">{{ Str::limit(strip_tags($item->content), 100) }}</p>
        @if($item->parent_id)
            <p class="mt-1 flex items-center gap-1 text-xs text-gray-400 dark:text-gray-500">
                <iconify-icon icon="lucide:corner-down-right" class="text-sm"></iconify-icon>
                {{ __('Reply to another reply') }}
            </p>
        @endif
    </div>
</a>
