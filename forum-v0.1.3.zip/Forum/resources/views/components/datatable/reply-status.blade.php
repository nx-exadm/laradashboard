<div class="flex justify-center">
    @if($isSolution)
        <span class="inline-flex items-center gap-1 rounded-full bg-green-100 px-2.5 py-1 text-xs font-medium text-green-700 dark:bg-green-900/30 dark:text-green-400">
            <iconify-icon icon="lucide:check" class="text-sm"></iconify-icon>
            {{ __('Solution') }}
        </span>
    @else
        <span class="text-xs text-gray-400 dark:text-gray-500">{{ __('Reply') }}</span>
    @endif
</div>
