@if($topic)
<div class="min-w-0">
    <p class="truncate text-sm font-medium text-gray-700 dark:text-gray-300">{{ Str::limit($topic->title, 30) }}</p>
    @if($topic->category)
        <p class="flex items-center gap-1 text-xs text-gray-400 dark:text-gray-500">
            <iconify-icon icon="lucide:folder" class="text-sm"></iconify-icon>
            {{ $topic->category->name }}
        </p>
    @endif
</div>
@else
<span class="text-sm italic text-gray-400">{{ __('Deleted topic') }}</span>
@endif
