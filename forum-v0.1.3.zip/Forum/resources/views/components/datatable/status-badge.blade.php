<div class="flex justify-center">
    @if($active)
        <span class="inline-flex items-center gap-1 rounded-full bg-green-100 px-2.5 py-1 text-xs font-medium text-green-700 dark:bg-green-900/30 dark:text-green-400">
            <span class="h-1.5 w-1.5 rounded-full bg-green-500"></span>
            {{ $activeLabel }}
        </span>
    @else
        <span class="inline-flex items-center gap-1 rounded-full bg-red-100 px-2.5 py-1 text-xs font-medium text-red-700 dark:bg-red-900/30 dark:text-red-400">
            <span class="h-1.5 w-1.5 rounded-full bg-red-500"></span>
            {{ $inactiveLabel }}
        </span>
    @endif
</div>
