<div class="text-sm">
    <p class="text-gray-700 dark:text-gray-300">{{ $date->diffForHumans() }}</p>
    <p class="text-xs text-gray-400 dark:text-gray-500">{{ $date->format('M d, Y') }}</p>
</div>
