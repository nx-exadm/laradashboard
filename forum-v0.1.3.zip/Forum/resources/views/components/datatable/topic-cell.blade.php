<a href="{{ route('admin.forum.topics.edit', $item) }}" class="flex items-start gap-3 group">
    <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-indigo-100 dark:bg-indigo-900/30">
        <iconify-icon icon="lucide:message-circle" class="h-5 w-5 text-indigo-600 dark:text-indigo-400"></iconify-icon>
    </div>
    <div class="min-w-0 flex-1">
        <p class="truncate font-medium text-gray-900 dark:text-white group-hover:text-primary-600 dark:group-hover:text-primary-400">{{ $item->title }}</p>
        <p class="mt-0.5 line-clamp-1 text-sm text-gray-500 dark:text-gray-400">{{ Str::limit(strip_tags($item->content), 60) }}</p>
    </div>
</a>
