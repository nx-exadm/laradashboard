<div class="flex flex-col gap-1">
    <div class="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400">
        <iconify-icon icon="lucide:eye" class="text-sm"></iconify-icon>
        <span>{{ number_format($views) }} {{ __('views') }}</span>
    </div>
    <div class="flex items-center gap-1 text-xs {{ $replies > 0 ? 'text-blue-600 dark:text-blue-400' : 'text-gray-500 dark:text-gray-400' }}">
        <iconify-icon icon="lucide:message-square" class="text-sm"></iconify-icon>
        <span>{{ number_format($replies) }} {{ __('replies') }}</span>
    </div>
</div>
