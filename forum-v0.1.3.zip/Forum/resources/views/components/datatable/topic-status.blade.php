<div class="flex flex-wrap gap-1">
    @if($isPinned)
        <span class="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-700 dark:bg-amber-900/30 dark:text-amber-400">
            <iconify-icon icon="lucide:pin" class="text-sm"></iconify-icon>
            {{ __('Pinned') }}
        </span>
    @endif

    @if($isLocked)
        <span class="inline-flex items-center gap-1 rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-700 dark:bg-red-900/30 dark:text-red-400">
            <iconify-icon icon="lucide:lock" class="text-sm"></iconify-icon>
            {{ __('Locked') }}
        </span>
    @endif

    @if($isSolved)
        <span class="inline-flex items-center gap-1 rounded-full bg-green-100 px-2 py-0.5 text-xs font-medium text-green-700 dark:bg-green-900/30 dark:text-green-400">
            <iconify-icon icon="lucide:check-circle" class="text-sm"></iconify-icon>
            {{ __('Solved') }}
        </span>
    @endif

    @if(!$isPinned && !$isLocked && !$isSolved)
        <span class="text-xs text-gray-400 dark:text-gray-500">{{ __('Open') }}</span>
    @endif
</div>
