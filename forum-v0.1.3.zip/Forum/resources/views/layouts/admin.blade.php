@extends('forum::layouts.master')

@section('forum-admin-content')
    <div class="space-y-6">
        <div>
            {{ $slot }}
        </div>
    </div>
@endsection
