@extends('forum::layouts.master')

@section('forum-admin-content')
    <div>
        {{-- Breadcrumbs are rendered by the page component --}}
        {{ $slot }}
    </div>
@endsection
