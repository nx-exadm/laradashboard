@php
    use App\Support\Facades\Hook;
    use Modules\Forum\Enums\ForumActionHook;

    $showForumHeader = filter_var(config('settings.forum_show_header', true), FILTER_VALIDATE_BOOLEAN);
    $showUserDropdown = filter_var(config('settings.forum_show_user_dropdown', true), FILTER_VALIDATE_BOOLEAN);
    $showForumFooter = filter_var(config('settings.forum_show_footer', true), FILTER_VALIDATE_BOOLEAN);
    $forumTitle = config('settings.forum_title') ?: __('Forum');
    $forumFooterText = config('settings.forum_footer_text') ?: '';

    // SEO defaults
    $seo = $seo ?? [];
    $seoTitle = $seo['title'] ?? (isset($title) ? $title . ' - ' . config('app.name') : $forumTitle . ' - ' . config('app.name'));
    $seoDescription = $seo['description'] ?? config('settings.forum_description') ?? '';
    $seoCanonical = $seo['canonical'] ?? url()->current();
    $seoRobots = $seo['robots'] ?? 'index, follow';
    $seoOg = $seo['og'] ?? [];
    $seoTwitter = $seo['twitter'] ?? [];
    $seoJsonLd = $seo['jsonLd'] ?? [];
@endphp
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="forum:scroll-smooth">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    {{-- Primary Meta Tags --}}
    <title>{{ $seoTitle }}</title>
    <meta name="title" content="{{ $seoTitle }}">
    @if($seoDescription)
        <meta name="description" content="{{ $seoDescription }}">
    @endif
    <meta name="robots" content="{{ $seoRobots }}">
    <link rel="canonical" href="{{ $seoCanonical }}">

    {{-- Open Graph / Facebook --}}
    <meta property="og:type" content="{{ $seoOg['type'] ?? 'website' }}">
    <meta property="og:url" content="{{ $seoOg['url'] ?? $seoCanonical }}">
    <meta property="og:title" content="{{ $seoOg['title'] ?? $seoTitle }}">
    @if($seoOg['description'] ?? $seoDescription)
        <meta property="og:description" content="{{ $seoOg['description'] ?? $seoDescription }}">
    @endif
    <meta property="og:site_name" content="{{ $seoOg['site_name'] ?? config('app.name') }}">
    @if(isset($seoOg['image']))
        <meta property="og:image" content="{{ $seoOg['image'] }}">
    @endif
    <meta property="og:locale" content="{{ str_replace('-', '_', app()->getLocale()) }}">

    {{-- Article specific OG tags --}}
    @if(isset($seoOg['article']))
        <meta property="article:published_time" content="{{ $seoOg['article']['published_time'] }}">
        <meta property="article:modified_time" content="{{ $seoOg['article']['modified_time'] }}">
        @if(isset($seoOg['article']['author']))
            <meta property="article:author" content="{{ $seoOg['article']['author'] }}">
        @endif
        @if(isset($seoOg['article']['section']))
            <meta property="article:section" content="{{ $seoOg['article']['section'] }}">
        @endif
    @endif

    {{-- Twitter Card --}}
    <meta name="twitter:card" content="{{ $seoTwitter['card'] ?? 'summary' }}">
    <meta name="twitter:url" content="{{ $seoOg['url'] ?? $seoCanonical }}">
    <meta name="twitter:title" content="{{ $seoTwitter['title'] ?? $seoTitle }}">
    @if($seoTwitter['description'] ?? $seoDescription)
        <meta name="twitter:description" content="{{ $seoTwitter['description'] ?? $seoDescription }}">
    @endif
    @if(isset($seoTwitter['image']))
        <meta name="twitter:image" content="{{ $seoTwitter['image'] }}">
    @endif

    {{-- JSON-LD Structured Data --}}
    @foreach($seoJsonLd as $schema)
        <script type="application/ld+json">
            {!! json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) !!}
        </script>
    @endforeach

    @vite(['resources/css/app.css', 'resources/js/app.js'])
    @vite(['modules/Forum/resources/assets/css/app.css'], 'build-forum')
    @livewireStyles

    {{-- Hook: Additional head content --}}
    {!! Hook::doAction(ForumActionHook::LAYOUT_HEAD) !!}
</head>
<body class="forum:bg-gray-50 forum:dark:bg-gray-900 forum:min-h-screen forum:flex forum:flex-col">
    {{-- Hook: Body start - inject content at the very top --}}
    {!! Hook::doAction(ForumActionHook::LAYOUT_BODY_START) !!}

    {{-- Hook: Before header - perfect for main site navbar --}}
    {!! Hook::doAction(ForumActionHook::LAYOUT_BEFORE_HEADER) !!}

    @if ($showForumHeader)
    {{-- Forum Header - matching LaraDashboard navbar padding --}}
    <header class="forum:bg-white forum:dark:bg-gray-800 forum:shadow-sm forum:border-b forum:border-gray-200 forum:dark:border-gray-700 forum:px-4 forum:lg:px-16">
        <div class="forum:container forum:mx-auto">
            <div class="forum:flex forum:justify-between forum:items-center forum:h-16">
                {{-- Logo / Title --}}
                <div class="forum:flex forum:items-center forum:gap-4">
                    <a href="{{ route('forum.index') }}" class="forum:flex forum:items-center forum:gap-2 forum:text-xl forum:font-bold forum:text-gray-900 forum:dark:text-white">
                        <iconify-icon icon="lucide:messages-square" class="forum:text-2xl forum:text-primary"></iconify-icon>
                        {{ $forumTitle }}
                    </a>
                </div>

                {{-- Search --}}
                <div class="forum:hidden forum:md:flex forum:flex-1 forum:max-w-md forum:mx-8">
                    <form action="{{ route('forum.search') }}" method="GET" class="forum:w-full">
                        <div class="forum:relative">
                            <input
                                type="search"
                                name="q"
                                placeholder="{{ __('Search topics...') }}"
                                value="{{ request('q') }}"
                                class="form-control forum:pl-10"
                            >
                            <iconify-icon icon="lucide:search" class="forum:absolute forum:left-3 forum:top-1/2 forum:-translate-y-1/2 forum:text-base forum:text-gray-400"></iconify-icon>
                        </div>
                    </form>
                </div>

                {{-- Actions --}}
                <div class="forum:flex forum:items-center forum:gap-3">
                    @auth
                        <a href="{{ route('forum.create') }}" class="btn-primary">
                            <iconify-icon icon="lucide:plus" class="forum:text-base"></iconify-icon>
                            {{ __('New Topic') }}
                        </a>
                        @if ($showUserDropdown)
                        <div class="forum:relative" x-data="{ open: false }">
                            <button @click="open = !open" class="forum:flex forum:items-center forum:gap-2 forum:text-gray-700 forum:dark:text-gray-300 forum:hover:text-gray-900 forum:dark:hover:text-white">
                                <span class="forum:w-8 forum:h-8 forum:rounded-full forum:bg-primary/10 forum:flex forum:items-center forum:justify-center forum:text-primary forum:font-medium">
                                    {{ strtoupper(substr(auth()->user()->full_name, 0, 1)) }}
                                </span>
                            </button>
                            <div x-show="open" @click.away="open = false" x-cloak class="forum:absolute forum:right-0 forum:mt-2 forum:w-48 forum:bg-white forum:dark:bg-gray-800 forum:rounded-lg forum:shadow-lg forum:border forum:border-gray-200 forum:dark:border-gray-700 forum:py-1 forum:z-50">
                                <a href="{{ route('admin.forum.dashboard') }}" class="forum:block forum:px-4 forum:py-2 forum:text-sm forum:text-gray-700 forum:dark:text-gray-300 forum:hover:bg-gray-100 forum:dark:hover:bg-gray-700">
                                    {{ __('Admin Panel') }}
                                </a>
                                <form method="POST" action="{{ route('logout') }}">
                                    @csrf
                                    <button type="submit" class="forum:w-full forum:text-left forum:px-4 forum:py-2 forum:text-sm forum:text-gray-700 forum:dark:text-gray-300 forum:hover:bg-gray-100 forum:dark:hover:bg-gray-700">
                                        {{ __('Logout') }}
                                    </button>
                                </form>
                            </div>
                        </div>
                        @endif
                    @else
                        <a href="{{ route('login') }}" class="link-secondary forum:text-sm forum:font-medium">
                            {{ __('Login') }}
                        </a>
                        @if (Route::has('register'))
                            <a href="{{ route('register') }}" class="btn-primary">
                                {{ __('Register') }}
                            </a>
                        @endif
                    @endauth
                </div>
            </div>
        </div>
    </header>
    @endif

    {{-- Hook: After header --}}
    {!! Hook::doAction(ForumActionHook::LAYOUT_AFTER_HEADER) !!}

    {{-- Hook: Before content --}}
    {!! Hook::doAction(ForumActionHook::LAYOUT_BEFORE_CONTENT) !!}

    {{-- Main Content - matching LaraDashboard navbar padding --}}
    <main class="forum:px-4 forum:lg:px-16 forum:py-6 forum:flex-1">
        <div class="forum:container forum:mx-auto">
            {{ $slot }}
        </div>
    </main>

    {{-- Hook: After content --}}
    {!! Hook::doAction(ForumActionHook::LAYOUT_AFTER_CONTENT) !!}

    {{-- Hook: Before footer --}}
    {!! Hook::doAction(ForumActionHook::LAYOUT_BEFORE_FOOTER) !!}

    @if ($showForumFooter)
    {{-- Forum Footer - matching LaraDashboard navbar padding --}}
    <footer class="forum:bg-white forum:dark:bg-gray-800 forum:border-t forum:border-gray-200 forum:dark:border-gray-700 forum:mt-auto forum:px-4 forum:lg:px-16 forum:py-6">
        <div class="forum:container forum:mx-auto">
            <div class="forum:flex forum:flex-col forum:md:flex-row forum:justify-between forum:items-center forum:gap-4">
                <p class="forum:text-sm forum:text-gray-500 forum:dark:text-gray-400">
                    @if($forumFooterText)
                        {!! nl2br(e($forumFooterText)) !!}
                    @else
                        &copy; {{ date('Y') }} {{ config('app.name') }}. {{ __('All rights reserved.') }}
                    @endif
                </p>
                <div class="forum:flex forum:items-center forum:gap-4">
                    <a href="{{ route('forum.index') }}" class="link-secondary forum:text-sm">
                        {{ $forumTitle }}
                    </a>
                </div>
            </div>
        </div>
    </footer>
    @endif

    {{-- Hook: After footer - perfect for main site footer --}}
    {!! Hook::doAction(ForumActionHook::LAYOUT_AFTER_FOOTER) !!}

    {{-- Hook: Body end --}}
    {!! Hook::doAction(ForumActionHook::LAYOUT_BODY_END) !!}

    @livewireScripts
    @stack('scripts')
</body>
</html>
