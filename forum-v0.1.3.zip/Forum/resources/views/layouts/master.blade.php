@extends('backend.layouts.app')

@section('title')
    @yield('forum-title', $breadcrumbs['title'] ?? __('Forum')) | {{ __('Forum') }} | {{ config('app.name') }}
@endsection

@push('styles')
    @vite(['modules/Forum/resources/assets/css/app.css'], 'build-forum')
@endpush

@section('admin-content')
    <div class="forum-module ld-container min-h-[80vh]">
        @yield('forum-admin-content')
    </div>
@endsection
