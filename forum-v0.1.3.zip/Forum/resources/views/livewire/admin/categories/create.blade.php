<div>
    {{-- Breadcrumbs Header --}}
    <x-breadcrumbs :breadcrumbs="$this->breadcrumbs" />

    {{-- Form --}}
    <form wire:submit="save" class="space-y-6">
        <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
            {{-- Main Content --}}
            <div class="lg:col-span-2 space-y-6">
                <x-card.card>
                    <x-slot name="header">{{ __('Basic Information') }}</x-slot>

                    <div class="space-y-6">
                        <x-inputs.input
                            wire:model.live.debounce.500ms="name"
                            name="name"
                            label="{{ __('Category Name') }}"
                            placeholder="{{ __('e.g., General Discussion') }}"
                            description="{{ __('The name that will be displayed to users.') }}"
                            :required="true"
                        />

                        <x-inputs.input
                            wire:model="slug"
                            name="slug"
                            label="{{ __('URL Slug') }}"
                            placeholder="{{ __('e.g., general-discussion') }}"
                            description="{{ __('Used in URLs. Auto-generated from name if left empty.') }}"
                            :required="true"
                        />

                        <div>
                            <label for="description" class="form-label">{{ __('Description') }}</label>
                            <textarea
                                wire:model="description"
                                id="description"
                                name="description"
                                rows="3"
                                placeholder="{{ __('Describe what this category is about...') }}"
                                class="form-control-textarea"
                            ></textarea>
                            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">{{ __('A brief description to help users understand this category.') }}</p>
                            @error('description')
                                <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>
                </x-card.card>
            </div>

            {{-- Sidebar --}}
            <div class="space-y-6">
                <x-card.card>
                    <x-slot name="header">{{ __('Appearance') }}</x-slot>

                    <div class="space-y-6">
                        <div>
                            <label for="icon" class="form-label">{{ __('Icon') }}</label>
                            <div class="flex items-center gap-3">
                                <div class="flex h-12 w-12 items-center justify-center rounded-lg bg-gray-100 dark:bg-gray-700">
                                    <iconify-icon icon="{{ $icon ?: 'lucide:folder' }}" class="text-2xl text-gray-600 dark:text-gray-300"></iconify-icon>
                                </div>
                                <input
                                    wire:model.live="icon"
                                    type="text"
                                    id="icon"
                                    name="icon"
                                    placeholder="lucide:folder"
                                    class="form-control flex-1"
                                />
                            </div>
                            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">{{ __('Use Iconify format (e.g., lucide:folder)') }}</p>
                            @error('icon')
                                <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                            @enderror
                        </div>

                        <div>
                            <label for="color" class="form-label">{{ __('Color') }}</label>
                            <div class="flex items-center gap-3">
                                <input
                                    type="color"
                                    wire:model.live="color"
                                    id="color_picker"
                                    class="h-10 w-10 cursor-pointer rounded border border-gray-300 dark:border-gray-600"
                                />
                                <input
                                    wire:model.live="color"
                                    type="text"
                                    id="color"
                                    name="color"
                                    placeholder="#6366f1"
                                    class="form-control flex-1"
                                />
                            </div>
                            @error('color')
                                <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>
                </x-card.card>

                <x-card.card>
                    <x-slot name="header">{{ __('Settings') }}</x-slot>

                    <div class="space-y-6">
                        <x-inputs.input
                            type="number"
                            wire:model="order"
                            name="order"
                            label="{{ __('Display Order') }}"
                            min="0"
                            description="{{ __('Lower numbers appear first.') }}"
                            :required="true"
                        />

                        <x-inputs.toggle
                            wire:model="is_active"
                            name="is_active"
                            label="{{ __('Active') }}"
                            description="{{ __('Inactive categories are hidden from users.') }}"
                        />
                    </div>
                </x-card.card>
            </div>
        </div>

        {{-- Submit --}}
        <div class="flex items-center gap-4">
            <a wire:navigate href="{{ route('admin.forum.categories.index') }}" class="btn-default">
                {{ __('Cancel') }}
            </a>
            <x-buttons.button type="submit" variant="primary" icon="lucide:save" loadingTarget="save">
                {{ __('Create Category') }}
            </x-buttons.button>
        </div>
    </form>
</div>
