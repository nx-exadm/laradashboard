<div>
    {{-- Breadcrumbs Header --}}
    <x-breadcrumbs :breadcrumbs="$this->breadcrumbs" />

    <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {{-- Main Content --}}
        <div class="lg:col-span-2 space-y-6">
            {{-- Category Header --}}
            <x-card.card>
                <div class="flex items-start gap-4">
                    <div
                        class="flex h-16 w-16 shrink-0 items-center justify-center rounded-xl"
                        style="background-color: {{ $this->category->color ?? '#6366f1' }}20;"
                    >
                        <iconify-icon
                            icon="{{ $this->category->icon ?: 'lucide:folder' }}"
                            class="text-3xl"
                            style="color: {{ $this->category->color ?? '#6366f1' }};"
                        ></iconify-icon>
                    </div>
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center gap-3">
                            <h2 class="text-xl font-bold text-gray-900 dark:text-white">{{ $this->category->name }}</h2>
                            @if($this->category->is_active)
                                <span class="inline-flex items-center gap-1 rounded-full bg-green-100 px-2.5 py-1 text-xs font-medium text-green-700 dark:bg-green-900/30 dark:text-green-400">
                                    <span class="h-1.5 w-1.5 rounded-full bg-green-500"></span>
                                    {{ __('Active') }}
                                </span>
                            @else
                                <span class="inline-flex items-center gap-1 rounded-full bg-red-100 px-2.5 py-1 text-xs font-medium text-red-700 dark:bg-red-900/30 dark:text-red-400">
                                    <span class="h-1.5 w-1.5 rounded-full bg-red-500"></span>
                                    {{ __('Inactive') }}
                                </span>
                            @endif
                        </div>
                        <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">/{{ $this->category->slug }}</p>
                        @if($this->category->description)
                            <p class="mt-2 text-gray-700 dark:text-gray-300">{{ $this->category->description }}</p>
                        @endif
                    </div>
                </div>

                {{-- Stats --}}
                <div class="mt-6 grid grid-cols-3 gap-4 border-t border-gray-200 pt-6 dark:border-gray-700">
                    <div class="text-center">
                        <p class="text-2xl font-bold text-gray-900 dark:text-white">{{ number_format($stats['topics']) }}</p>
                        <p class="text-sm text-gray-500 dark:text-gray-400">{{ __('Topics') }}</p>
                    </div>
                    <div class="text-center">
                        <p class="text-2xl font-bold text-gray-900 dark:text-white">{{ number_format($stats['replies']) }}</p>
                        <p class="text-sm text-gray-500 dark:text-gray-400">{{ __('Replies') }}</p>
                    </div>
                    <div class="text-center">
                        <p class="text-2xl font-bold text-gray-900 dark:text-white">{{ number_format($stats['views']) }}</p>
                        <p class="text-sm text-gray-500 dark:text-gray-400">{{ __('Views') }}</p>
                    </div>
                </div>
            </x-card.card>

            {{-- Recent Topics --}}
            <x-card.card>
                <x-slot name="header">
                    <div class="flex items-center justify-between">
                        <span>{{ __('Recent Topics') }}</span>
                        @if($stats['topics'] > 0)
                            <a href="{{ route('admin.forum.topics.index') }}?category={{ $this->category->id }}" class="text-sm font-normal text-primary-600 hover:text-primary-700 dark:text-primary-400">
                                {{ __('View all') }}
                            </a>
                        @endif
                    </div>
                </x-slot>

                @if($recentTopics->count() > 0)
                    <div class="divide-y divide-gray-200 dark:divide-gray-700">
                        @foreach($recentTopics as $topic)
                            <div class="flex items-center gap-4 py-3 first:pt-0 last:pb-0">
                                <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-700">
                                    @if($topic->user)
                                        <img
                                            src="{{ $topic->user->avatar_url }}"
                                            alt="{{ $topic->user->full_name }}"
                                            class="h-10 w-10 rounded-full object-cover"
                                        />
                                    @else
                                        <iconify-icon icon="lucide:user" class="text-xl text-gray-500"></iconify-icon>
                                    @endif
                                </div>
                                <div class="flex-1 min-w-0">
                                    <a href="{{ route('admin.forum.topics.show', $topic) }}" class="font-medium text-gray-900 hover:text-primary-600 dark:text-white dark:hover:text-primary-400">
                                        {{ $topic->title }}
                                    </a>
                                    <div class="mt-1 flex items-center gap-3 text-xs text-gray-500 dark:text-gray-400">
                                        <span>{{ $topic->user?->full_name ?? __('Unknown') }}</span>
                                        <span>&bull;</span>
                                        <span>{{ $topic->created_at->diffForHumans() }}</span>
                                        <span>&bull;</span>
                                        <span>{{ $topic->replies_count }} {{ __('replies') }}</span>
                                    </div>
                                </div>
                                <div class="flex items-center gap-2">
                                    @if($topic->is_pinned)
                                        <iconify-icon icon="lucide:pin" class="text-amber-500" title="{{ __('Pinned') }}"></iconify-icon>
                                    @endif
                                    @if($topic->is_locked)
                                        <iconify-icon icon="lucide:lock" class="text-red-500" title="{{ __('Locked') }}"></iconify-icon>
                                    @endif
                                    @if($topic->is_solved)
                                        <iconify-icon icon="lucide:check-circle" class="text-green-500" title="{{ __('Solved') }}"></iconify-icon>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                @else
                    <div class="py-8 text-center">
                        <iconify-icon icon="lucide:message-circle-off" class="text-4xl text-gray-300 dark:text-gray-600"></iconify-icon>
                        <p class="mt-2 text-gray-500 dark:text-gray-400">{{ __('No topics in this category yet.') }}</p>
                        <a href="{{ route('admin.forum.topics.create') }}" class="mt-4 inline-flex items-center gap-2 text-sm text-primary-600 hover:text-primary-700 dark:text-primary-400">
                            <iconify-icon icon="lucide:plus"></iconify-icon>
                            {{ __('Create first topic') }}
                        </a>
                    </div>
                @endif
            </x-card.card>
        </div>

        {{-- Sidebar --}}
        <div class="space-y-6">
            {{-- Details --}}
            <x-card.card>
                <x-slot name="header">{{ __('Details') }}</x-slot>

                <dl class="space-y-4">
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">{{ __('Display Order') }}</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">#{{ $this->category->order }}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">{{ __('Created') }}</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">{{ $this->category->created_at->format('M d, Y') }}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">{{ __('Last Updated') }}</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">{{ $this->category->updated_at->diffForHumans() }}</dd>
                    </div>
                </dl>
            </x-card.card>

            {{-- Actions --}}
            <x-card.card>
                <x-slot name="header">{{ __('Actions') }}</x-slot>

                <div class="space-y-3">
                    <a
                        href="{{ route('admin.forum.categories.edit', $this->category) }}"
                        class="flex w-full items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700"
                    >
                        <iconify-icon icon="lucide:pencil"></iconify-icon>
                        {{ __('Edit Category') }}
                    </a>

                    @if($stats['topics'] === 0)
                        <button
                            type="button"
                            wire:click="$dispatch('open-modal', { id: 'delete-category' })"
                            class="flex w-full items-center justify-center gap-2 rounded-lg border border-red-300 bg-white px-4 py-2.5 text-sm font-medium text-red-600 hover:bg-red-50 dark:border-red-800 dark:bg-gray-800 dark:text-red-400 dark:hover:bg-red-900/20"
                        >
                            <iconify-icon icon="lucide:trash-2"></iconify-icon>
                            {{ __('Delete Category') }}
                        </button>
                    @else
                        <div class="rounded-lg border border-amber-200 bg-amber-50 p-3 dark:border-amber-900 dark:bg-amber-900/20">
                            <p class="text-sm text-amber-700 dark:text-amber-400">
                                <iconify-icon icon="lucide:alert-triangle" class="mr-1"></iconify-icon>
                                {{ __('Cannot delete: category has topics') }}
                            </p>
                        </div>
                    @endif
                </div>
            </x-card.card>
        </div>
    </div>
</div>
