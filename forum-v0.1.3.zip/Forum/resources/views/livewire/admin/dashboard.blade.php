<div>
    {{-- Page Header --}}
    <div class="mb-6">
        <h2 class="text-xl font-semibold text-gray-700 dark:text-white/90 flex items-center gap-2">
            <iconify-icon icon="lucide:messages-square" class="text-primary"></iconify-icon>
            {{ __('Forum Dashboard') }}
        </h2>
        <p class="text-sm text-gray-500 dark:text-gray-400">
            {{ __('Overview of your forum activity and statistics.') }}
        </p>
    </div>

    {{-- Stats Cards --}}
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
        {{-- Total Topics --}}
        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-4 hover:shadow-lg transition-shadow cursor-pointer"
             onclick="window.location.href='{{ route('admin.forum.topics.index') }}'">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                    <iconify-icon icon="lucide:message-square" class="text-xl text-blue-600 dark:text-blue-400"></iconify-icon>
                </div>
                @if($stats['topicsGrowth'] != 0)
                    <span class="text-xs font-medium {{ $stats['topicsGrowth'] > 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400' }}">
                        {{ $stats['topicsGrowth'] > 0 ? '+' : '' }}{{ $stats['topicsGrowth'] }}%
                    </span>
                @endif
            </div>
            <div class="text-2xl font-bold text-gray-900 dark:text-white">{{ number_format($stats['totalTopics']) }}</div>
            <div class="text-sm text-gray-500 dark:text-gray-400">{{ __('Topics') }}</div>
        </div>

        {{-- Total Replies --}}
        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-4 hover:shadow-lg transition-shadow cursor-pointer"
             onclick="window.location.href='{{ route('admin.forum.replies.index') }}'">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                    <iconify-icon icon="lucide:messages-square" class="text-xl text-purple-600 dark:text-purple-400"></iconify-icon>
                </div>
                @if($stats['repliesGrowth'] != 0)
                    <span class="text-xs font-medium {{ $stats['repliesGrowth'] > 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400' }}">
                        {{ $stats['repliesGrowth'] > 0 ? '+' : '' }}{{ $stats['repliesGrowth'] }}%
                    </span>
                @endif
            </div>
            <div class="text-2xl font-bold text-gray-900 dark:text-white">{{ number_format($stats['totalReplies']) }}</div>
            <div class="text-sm text-gray-500 dark:text-gray-400">{{ __('Replies') }}</div>
        </div>

        {{-- Categories --}}
        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-4 hover:shadow-lg transition-shadow cursor-pointer"
             onclick="window.location.href='{{ route('admin.forum.categories.index') }}'">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 rounded-lg bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center">
                    <iconify-icon icon="lucide:folder" class="text-xl text-orange-600 dark:text-orange-400"></iconify-icon>
                </div>
            </div>
            <div class="text-2xl font-bold text-gray-900 dark:text-white">{{ number_format($stats['totalCategories']) }}</div>
            <div class="text-sm text-gray-500 dark:text-gray-400">{{ __('Categories') }}</div>
        </div>

        {{-- Total Views --}}
        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-4">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 rounded-lg bg-cyan-100 dark:bg-cyan-900/30 flex items-center justify-center">
                    <iconify-icon icon="lucide:eye" class="text-xl text-cyan-600 dark:text-cyan-400"></iconify-icon>
                </div>
            </div>
            <div class="text-2xl font-bold text-gray-900 dark:text-white">{{ number_format($stats['totalViews']) }}</div>
            <div class="text-sm text-gray-500 dark:text-gray-400">{{ __('Total Views') }}</div>
        </div>

        {{-- Solved Topics --}}
        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-4">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                    <iconify-icon icon="lucide:check-circle" class="text-xl text-green-600 dark:text-green-400"></iconify-icon>
                </div>
                <span class="text-xs font-medium text-green-600 dark:text-green-400">{{ $stats['solvedRate'] }}%</span>
            </div>
            <div class="text-2xl font-bold text-gray-900 dark:text-white">{{ number_format($stats['solvedTopics']) }}</div>
            <div class="text-sm text-gray-500 dark:text-gray-400">{{ __('Solved') }}</div>
        </div>

        {{-- Active Users --}}
        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-4">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 rounded-lg bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center">
                    <iconify-icon icon="lucide:users" class="text-xl text-pink-600 dark:text-pink-400"></iconify-icon>
                </div>
            </div>
            <div class="text-2xl font-bold text-gray-900 dark:text-white">{{ number_format($stats['activeUsers']) }}</div>
            <div class="text-sm text-gray-500 dark:text-gray-400">{{ __('Contributors') }}</div>
        </div>
    </div>

    {{-- Charts Row --}}
    <div class="grid grid-cols-12 gap-6 mb-6">
        {{-- Topic Activity Chart --}}
        <div class="col-span-12 lg:col-span-8">
            <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">{{ __('Topic Activity') }}</h3>
                    <span class="text-sm text-gray-500 dark:text-gray-400">{{ __('Last 30 days') }}</span>
                </div>
                <div class="p-6">
                    <div id="forumTopicChart" class="h-72"></div>
                </div>
            </div>
        </div>

        {{-- Top Categories --}}
        <div class="col-span-12 lg:col-span-4">
            <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden h-full">
                <div class="px-6 py-4 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">{{ __('Top Categories') }}</h3>
                    <a href="{{ route('admin.forum.categories.index') }}" class="text-sm text-primary hover:underline">{{ __('View all') }}</a>
                </div>
                <div class="p-4">
                    @forelse($topCategories as $category)
                        <div class="flex items-center justify-between py-3 {{ !$loop->last ? 'border-b border-gray-100 dark:border-gray-700' : '' }}">
                            <div class="flex items-center gap-3">
                                <div class="w-8 h-8 rounded-lg flex items-center justify-center" style="background-color: {{ $category->color ? 'var(--color-'.$category->color.'-100)' : '#f3f4f6' }}">
                                    <iconify-icon icon="{{ $category->icon ?: 'lucide:folder' }}" class="text-sm" style="color: {{ $category->color ? 'var(--color-'.$category->color.'-600)' : '#6b7280' }}"></iconify-icon>
                                </div>
                                <span class="text-sm font-medium text-gray-900 dark:text-white">{{ $category->name }}</span>
                            </div>
                            <span class="text-sm text-gray-500 dark:text-gray-400">{{ $category->topics_count }} {{ __('topics') }}</span>
                        </div>
                    @empty
                        <div class="py-8 text-center text-gray-500 dark:text-gray-400">
                            {{ __('No categories yet.') }}
                        </div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>

    {{-- Bottom Row --}}
    <div class="grid grid-cols-12 gap-6">
        {{-- Recent Topics --}}
        <div class="col-span-12 lg:col-span-6">
            <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">{{ __('Recent Topics') }}</h3>
                    <a href="{{ route('admin.forum.topics.index') }}" class="text-sm text-primary hover:underline">{{ __('View all') }}</a>
                </div>
                <div class="divide-y divide-gray-100 dark:divide-gray-700">
                    @forelse($recentTopics as $topic)
                        <a href="{{ route('admin.forum.topics.show', $topic) }}" class="block px-6 py-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                            <div class="flex items-start justify-between gap-4">
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-center gap-2 mb-1">
                                        @if($topic->is_pinned)
                                            <iconify-icon icon="lucide:pin" class="text-xs text-yellow-500"></iconify-icon>
                                        @endif
                                        @if($topic->is_solved)
                                            <iconify-icon icon="lucide:check-circle" class="text-xs text-green-500"></iconify-icon>
                                        @endif
                                        <h4 class="text-sm font-medium text-gray-900 dark:text-white truncate">{{ $topic->title }}</h4>
                                    </div>
                                    <div class="flex items-center gap-3 text-xs text-gray-500 dark:text-gray-400">
                                        <span>{{ $topic->user->full_name }}</span>
                                        <span>&middot;</span>
                                        <span>{{ $topic->category->name }}</span>
                                        <span>&middot;</span>
                                        <span>{{ $topic->created_at->diffForHumans() }}</span>
                                    </div>
                                </div>
                                <div class="flex items-center gap-3 text-xs text-gray-500 dark:text-gray-400">
                                    <span class="flex items-center gap-1">
                                        <iconify-icon icon="lucide:message-circle"></iconify-icon>
                                        {{ $topic->replies_count }}
                                    </span>
                                    <span class="flex items-center gap-1">
                                        <iconify-icon icon="lucide:eye"></iconify-icon>
                                        {{ $topic->views_count }}
                                    </span>
                                </div>
                            </div>
                        </a>
                    @empty
                        <div class="px-6 py-8 text-center text-gray-500 dark:text-gray-400">
                            {{ __('No topics yet.') }}
                        </div>
                    @endforelse
                </div>
            </div>
        </div>

        {{-- Recent Replies --}}
        <div class="col-span-12 lg:col-span-6">
            <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">{{ __('Recent Replies') }}</h3>
                    <a href="{{ route('admin.forum.replies.index') }}" class="text-sm text-primary hover:underline">{{ __('View all') }}</a>
                </div>
                <div class="divide-y divide-gray-100 dark:divide-gray-700">
                    @forelse($recentReplies as $reply)
                        <a href="{{ route('admin.forum.replies.show', $reply) }}" class="block px-6 py-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                            <div class="flex items-start gap-3">
                                <div class="shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-sm font-medium">
                                    {{ strtoupper(substr($reply->user->full_name, 0, 1)) }}
                                </div>
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-center gap-2 mb-1">
                                        <span class="text-sm font-medium text-gray-900 dark:text-white">{{ $reply->user->full_name }}</span>
                                        @if($reply->is_solution)
                                            <span class="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                                                {{ __('Solution') }}
                                            </span>
                                        @endif
                                    </div>
                                    <p class="text-sm text-gray-600 dark:text-gray-400 line-clamp-2">{{ Str::limit(strip_tags($reply->content), 100) }}</p>
                                    <div class="mt-1 text-xs text-gray-500 dark:text-gray-400">
                                        {{ __('on') }} <span class="font-medium">{{ Str::limit($reply->topic->title, 30) }}</span>
                                        &middot; {{ $reply->created_at->diffForHumans() }}
                                    </div>
                                </div>
                            </div>
                        </a>
                    @empty
                        <div class="px-6 py-8 text-center text-gray-500 dark:text-gray-400">
                            {{ __('No replies yet.') }}
                        </div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>

    {{-- Quick Actions --}}
    <div class="mt-6 flex flex-wrap gap-3">
        <a href="{{ route('admin.forum.categories.create') }}" class="inline-flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            <iconify-icon icon="lucide:folder-plus" class="text-lg"></iconify-icon>
            {{ __('New Category') }}
        </a>
        <a href="{{ route('admin.forum.topics.create') }}" class="inline-flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            <iconify-icon icon="lucide:message-square-plus" class="text-lg"></iconify-icon>
            {{ __('New Topic') }}
        </a>
        <a href="{{ route('admin.forum.settings') }}" class="inline-flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            <iconify-icon icon="lucide:settings" class="text-lg"></iconify-icon>
            {{ __('Settings') }}
        </a>
        @php
            $forumBaseUrl = config('settings.forum_base_url', '/forum') ?: '/forum';
        @endphp
        <a href="{{ url($forumBaseUrl) }}" target="_blank" class="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
            <iconify-icon icon="lucide:external-link" class="text-lg"></iconify-icon>
            {{ __('View Forum') }}
        </a>
    </div>
</div>

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const isDark = document.documentElement.classList.contains('dark');

    const chartOptions = {
        series: [{
            name: '{{ __("Topics") }}',
            data: @json($topicChartData['data'])
        }],
        chart: {
            type: 'area',
            height: 288,
            toolbar: { show: false },
            background: 'transparent',
        },
        colors: ['#6366f1'],
        fill: {
            type: 'gradient',
            gradient: {
                shadeIntensity: 1,
                opacityFrom: 0.4,
                opacityTo: 0.1,
                stops: [0, 90, 100]
            }
        },
        dataLabels: { enabled: false },
        stroke: {
            curve: 'smooth',
            width: 2
        },
        xaxis: {
            categories: @json($topicChartData['labels']),
            labels: {
                style: {
                    colors: isDark ? '#9ca3af' : '#6b7280',
                    fontSize: '11px'
                },
                rotate: -45,
                rotateAlways: true
            },
            axisBorder: { show: false },
            axisTicks: { show: false },
            tickAmount: 10
        },
        yaxis: {
            labels: {
                style: {
                    colors: isDark ? '#9ca3af' : '#6b7280',
                    fontSize: '11px'
                },
                formatter: function(val) {
                    return Math.floor(val);
                }
            }
        },
        grid: {
            borderColor: isDark ? '#374151' : '#e5e7eb',
            strokeDashArray: 4,
            padding: { left: 10, right: 10 }
        },
        tooltip: {
            theme: isDark ? 'dark' : 'light',
            y: {
                formatter: function(val) {
                    return val + ' {{ __("topics") }}';
                }
            }
        }
    };

    const chart = new ApexCharts(document.querySelector("#forumTopicChart"), chartOptions);
    chart.render();
});
</script>
@endpush
