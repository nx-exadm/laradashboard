<div>
    {{-- Breadcrumbs Header --}}
    <x-breadcrumbs :breadcrumbs="$this->breadcrumbs" />

    {{-- Form --}}
    <form wire:submit="save" class="space-y-6">
        <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
            {{-- Main Content --}}
            <div class="lg:col-span-2 space-y-6">
                <x-card.card>
                    <x-slot name="header">{{ __('Reply Content') }}</x-slot>

                    <div class="space-y-6">
                        <div>
                            <label for="content" class="form-label">{{ __('Content') }} <span class="text-red-500">*</span></label>
                            <textarea
                                wire:model.defer="content"
                                id="content"
                                name="content"
                                rows="12"
                                placeholder="{{ __('Write your reply content here...') }}"
                                class="form-control-textarea"
                            ></textarea>
                        </div>
                        @push('scripts')
                            <x-text-editor editorId="content" type="basic" height="350px" />
                        @endpush
                        <p class="text-sm text-gray-500 dark:text-gray-400">{{ __('Use the rich text editor to format your reply.') }}</p>
                        @error('content')
                            <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                        @enderror
                    </div>
                </x-card.card>
            </div>

            {{-- Sidebar --}}
            <div class="space-y-6">
                <x-card.card>
                    <x-slot name="header">{{ __('Publishing') }}</x-slot>

                    <div class="space-y-6">
                        <div>
                            <x-inputs.combobox
                                name="topic_id"
                                wire:model.live="topic_id"
                                label="{{ __('Topic') }}"
                                placeholder="{{ __('Select a topic...') }}"
                                :options="$topics->map(fn($topic) => [
                                    'value' => (string) $topic->id,
                                    'label' => Str::limit($topic->title, 50) . ($topic->category ? ' (' . $topic->category->name . ')' : '')
                                ])->toArray()"
                                :selected="$topic_id ? (string) $topic_id : null"
                                :searchable="true"
                                :required="true"
                            />
                            @error('topic_id')
                                <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                            @enderror
                        </div>

                        <div wire:ignore>
                            <x-inputs.combobox
                                name="user_id"
                                wire:model.defer="user_id"
                                label="{{ __('Author') }}"
                                placeholder="{{ __('Select an author...') }}"
                                :options="$users->map(fn($user) => [
                                    'value' => (string) $user->id,
                                    'label' => $user->full_name,
                                    'description' => $user->email
                                ])->toArray()"
                                :selected="$user_id ? (string) $user_id : null"
                                :searchable="true"
                                :required="true"
                            />
                        </div>
                        @error('user_id')
                            <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                        @enderror

                        @if($parentReplies->count() > 0)
                            <div wire:ignore>
                                <x-inputs.combobox
                                    name="parent_id"
                                    wire:model.defer="parent_id"
                                    label="{{ __('Reply To') }}"
                                    placeholder="{{ __('Top-level reply (none)') }}"
                                    :options="$parentReplies->map(fn($reply) => [
                                        'value' => (string) $reply->id,
                                        'label' => ($reply->user?->full_name ?? __('Unknown')) . ': ' . Str::limit(strip_tags($reply->content), 40)
                                    ])->toArray()"
                                    :selected="$parent_id ? (string) $parent_id : null"
                                    :searchable="true"
                                />
                                <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">{{ __('Select a reply to nest this reply under.') }}</p>
                            </div>
                            @error('parent_id')
                                <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                            @enderror
                        @endif
                    </div>
                </x-card.card>

                <x-card.card>
                    <x-slot name="header">{{ __('Options') }}</x-slot>

                    <div class="space-y-4">
                        <x-inputs.toggle
                            wire:model="is_solution"
                            name="is_solution"
                            label="{{ __('Mark as Solution') }}"
                            description="{{ __('This reply answers the topic question.') }}"
                        />
                    </div>
                </x-card.card>

                {{-- Selected Topic Preview --}}
                @if($topic_id)
                    @php
                        $selectedTopic = $topics->firstWhere('id', $topic_id);
                    @endphp
                    @if($selectedTopic)
                        <x-card.card>
                            <x-slot name="header">
                                <span class="flex items-center gap-2">
                                    <iconify-icon icon="lucide:message-circle"></iconify-icon>
                                    {{ __('Topic Preview') }}
                                </span>
                            </x-slot>

                            <div>
                                <h4 class="font-medium text-gray-900 dark:text-white">{{ $selectedTopic->title }}</h4>
                                <div class="mt-2 flex flex-wrap items-center gap-3 text-sm text-gray-500 dark:text-gray-400">
                                    @if($selectedTopic->category)
                                        <span class="inline-flex items-center gap-1">
                                            <iconify-icon icon="lucide:folder" class="text-sm"></iconify-icon>
                                            {{ $selectedTopic->category->name }}
                                        </span>
                                    @endif
                                    <span class="inline-flex items-center gap-1">
                                        <iconify-icon icon="lucide:message-square" class="text-sm"></iconify-icon>
                                        {{ $selectedTopic->replies_count ?? 0 }} {{ __('replies') }}
                                    </span>
                                </div>
                                @if($selectedTopic->is_solved)
                                    <span class="mt-2 inline-flex items-center gap-1 rounded-full bg-green-100 px-2.5 py-1 text-xs font-medium text-green-700 dark:bg-green-900/30 dark:text-green-400">
                                        <iconify-icon icon="lucide:check-circle" class="text-sm"></iconify-icon>
                                        {{ __('Solved') }}
                                    </span>
                                @endif
                            </div>
                        </x-card.card>
                    @endif
                @endif
            </div>
        </div>

        {{-- Submit --}}
        <div class="flex items-center gap-4">
            <a wire:navigate href="{{ route('admin.forum.replies.index') }}" class="btn-default">
                {{ __('Cancel') }}
            </a>
            <x-buttons.button type="submit" variant="primary" icon="lucide:save" loadingTarget="save">
                {{ __('Create Reply') }}
            </x-buttons.button>
        </div>
    </form>
</div>
