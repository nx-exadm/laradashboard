<div x-data="{ deleteModalOpen: false }">
    {{-- Breadcrumbs Header --}}
    <x-breadcrumbs :breadcrumbs="$this->breadcrumbs" />

    {{-- Form --}}
    <form wire:submit="save" class="space-y-6">
        <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
            {{-- Main Content --}}
            <div class="lg:col-span-2 space-y-6">
                <x-card.card>
                    <x-slot name="header">{{ __('Reply Content') }}</x-slot>

                    <div class="space-y-6">
                        <div>
                            <label for="content" class="form-label">{{ __('Content') }} <span class="text-red-500">*</span></label>
                            <textarea
                                wire:model.defer="content"
                                id="content"
                                name="content"
                                rows="12"
                                placeholder="{{ __('Write your reply content here...') }}"
                                class="form-control-textarea"
                            ></textarea>
                        </div>
                        @push('scripts')
                            <x-text-editor editorId="content" type="basic" height="350px" />
                        @endpush
                        <p class="text-sm text-gray-500 dark:text-gray-400">{{ __('Use the rich text editor to format your reply.') }}</p>
                        @error('content')
                            <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                        @enderror
                    </div>
                </x-card.card>

                {{-- Topic Context --}}
                @if($this->reply->topic)
                    <x-card.card>
                        <x-slot name="header">{{ __('Topic Context') }}</x-slot>

                        <a href="{{ route('admin.forum.topics.show', $this->reply->topic) }}" class="group block">
                            <h3 class="font-medium text-gray-900 group-hover:text-primary-600 dark:text-white dark:group-hover:text-primary-400">
                                {{ $this->reply->topic->title }}
                            </h3>
                            <div class="mt-2 flex flex-wrap items-center gap-3 text-sm text-gray-500 dark:text-gray-400">
                                @if($this->reply->topic->category)
                                    <span class="inline-flex items-center gap-1">
                                        <iconify-icon icon="lucide:folder" class="text-sm"></iconify-icon>
                                        {{ $this->reply->topic->category->name }}
                                    </span>
                                @endif
                                <span class="flex items-center gap-1">
                                    <iconify-icon icon="lucide:message-square" class="text-sm"></iconify-icon>
                                    {{ $this->reply->topic->replies_count }} {{ __('replies') }}
                                </span>
                                <span class="flex items-center gap-1">
                                    <iconify-icon icon="lucide:eye" class="text-sm"></iconify-icon>
                                    {{ $this->reply->topic->views_count }} {{ __('views') }}
                                </span>
                            </div>
                        </a>
                    </x-card.card>
                @endif
            </div>

            {{-- Sidebar --}}
            <div class="space-y-6">
                <x-card.card>
                    <x-slot name="header">{{ __('Publishing') }}</x-slot>

                    <div class="space-y-6">
                        <div>
                            <x-inputs.combobox
                                name="topic_id"
                                wire:model.live="topic_id"
                                label="{{ __('Topic') }}"
                                placeholder="{{ __('Select a topic...') }}"
                                :options="$topics->map(fn($topic) => [
                                    'value' => (string) $topic->id,
                                    'label' => Str::limit($topic->title, 50) . ($topic->category ? ' (' . $topic->category->name . ')' : '')
                                ])->toArray()"
                                :selected="$topic_id ? (string) $topic_id : null"
                                :searchable="true"
                                :required="true"
                            />
                            @error('topic_id')
                                <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                            @enderror
                        </div>

                        <div wire:ignore>
                            <x-inputs.combobox
                                name="user_id"
                                wire:model.defer="user_id"
                                label="{{ __('Author') }}"
                                placeholder="{{ __('Select an author...') }}"
                                :options="$users->map(fn($user) => [
                                    'value' => (string) $user->id,
                                    'label' => $user->full_name,
                                    'description' => $user->email
                                ])->toArray()"
                                :selected="$user_id ? (string) $user_id : null"
                                :searchable="true"
                                :required="true"
                            />
                        </div>
                        @error('user_id')
                            <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                        @enderror

                        @if($parentReplies->count() > 0)
                            <div wire:ignore>
                                <x-inputs.combobox
                                    name="parent_id"
                                    wire:model.defer="parent_id"
                                    label="{{ __('Reply To') }}"
                                    placeholder="{{ __('Top-level reply (none)') }}"
                                    :options="$parentReplies->map(fn($reply) => [
                                        'value' => (string) $reply->id,
                                        'label' => ($reply->user?->full_name ?? __('Unknown')) . ': ' . Str::limit(strip_tags($reply->content), 40)
                                    ])->toArray()"
                                    :selected="$parent_id ? (string) $parent_id : null"
                                    :searchable="true"
                                />
                                <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">{{ __('Select a reply to nest this reply under.') }}</p>
                            </div>
                            @error('parent_id')
                                <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                            @enderror
                        @endif
                    </div>
                </x-card.card>

                <x-card.card>
                    <x-slot name="header">{{ __('Status') }}</x-slot>

                    <div class="space-y-4">
                        <x-inputs.toggle
                            wire:model="is_solution"
                            name="is_solution"
                            label="{{ __('Mark as Solution') }}"
                            description="{{ __('This reply answers the topic question.') }}"
                        />
                    </div>
                </x-card.card>

                {{-- Stats (read-only) --}}
                <x-card.card>
                    <x-slot name="header">{{ __('Statistics') }}</x-slot>

                    <dl class="space-y-3">
                        <div class="flex items-center justify-between">
                            <dt class="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                                <iconify-icon icon="lucide:heart"></iconify-icon>
                                {{ __('Likes') }}
                            </dt>
                            <dd class="text-sm font-medium text-gray-900 dark:text-white">{{ number_format($this->reply->likes_count) }}</dd>
                        </div>
                        <div class="flex items-center justify-between">
                            <dt class="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                                <iconify-icon icon="lucide:calendar"></iconify-icon>
                                {{ __('Created') }}
                            </dt>
                            <dd class="text-sm font-medium text-gray-900 dark:text-white">{{ $this->reply->created_at->format('M d, Y') }}</dd>
                        </div>
                        <div class="flex items-center justify-between">
                            <dt class="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                                <iconify-icon icon="lucide:clock"></iconify-icon>
                                {{ __('Updated') }}
                            </dt>
                            <dd class="text-sm font-medium text-gray-900 dark:text-white">{{ $this->reply->updated_at->diffForHumans() }}</dd>
                        </div>
                    </dl>
                </x-card.card>
            </div>
        </div>

        {{-- Submit --}}
        <div class="flex items-center justify-between">
            <div class="flex items-center gap-4">
                <a wire:navigate href="{{ route('admin.forum.replies.index') }}" class="btn-default">
                    {{ __('Cancel') }}
                </a>
                <x-buttons.button type="submit" variant="primary" icon="lucide:save" loadingTarget="save">
                    {{ __('Save Changes') }}
                </x-buttons.button>
            </div>

            <x-buttons.button
                type="button"
                variant="danger"
                icon="lucide:trash-2"
                x-on:click="deleteModalOpen = true"
            >
                {{ __('Delete') }}
            </x-buttons.button>
        </div>
    </form>

    {{-- Delete Confirmation Modal --}}
    <x-modals.confirm-delete
        id="delete-reply-modal"
        title="{{ __('Delete Reply') }}"
        content="{{ __('Are you sure you want to delete this reply? This action cannot be undone.') }}"
        wireClick="delete"
    />

</div>
