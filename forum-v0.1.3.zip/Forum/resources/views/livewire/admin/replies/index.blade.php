<div>
    {{-- Breadcrumbs Header --}}
    <x-breadcrumbs :breadcrumbs="$this->breadcrumbs" />

    {{-- Stats Cards --}}
    @include('forum::components.admin-stats', ['stats' => $stats])

    {{-- Datatable --}}
    <livewire:forum::components.reply-datatable />
</div>
