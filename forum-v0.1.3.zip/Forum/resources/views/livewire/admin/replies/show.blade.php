<div>
    {{-- Breadcrumbs Header --}}
    <x-breadcrumbs :breadcrumbs="$this->breadcrumbs" />

    <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {{-- Main Content --}}
        <div class="lg:col-span-2 space-y-6">
            {{-- Reply Content --}}
            <x-card.card>
                <div class="flex items-start gap-4">
                    @if($this->reply->user)
                        <img
                            src="{{ $this->reply->user->avatar_url }}"
                            alt="{{ $this->reply->user->full_name }}"
                            class="h-12 w-12 rounded-full object-cover"
                        />
                    @else
                        <div class="flex h-12 w-12 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-700">
                            <iconify-icon icon="lucide:user" class="text-xl text-gray-500"></iconify-icon>
                        </div>
                    @endif
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center gap-2">
                            <span class="font-medium text-gray-900 dark:text-white">{{ $this->reply->user?->full_name ?? __('Unknown') }}</span>
                            <span class="text-sm text-gray-400">{{ $this->reply->created_at->diffForHumans() }}</span>
                            @if($this->reply->is_solution)
                                <span class="inline-flex items-center gap-1 rounded-full bg-green-100 px-2.5 py-1 text-xs font-medium text-green-700 dark:bg-green-900/30 dark:text-green-400">
                                    <iconify-icon icon="lucide:check-circle" class="text-sm"></iconify-icon>
                                    {{ __('Solution') }}
                                </span>
                            @endif
                        </div>
                        <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
                            {{ $this->reply->created_at->format('M d, Y \a\t H:i') }}
                        </p>
                    </div>
                </div>

                {{-- Content --}}
                <div class="mt-6 prose prose-sm dark:prose-invert max-w-none">
                    {!! $this->reply->content !!}
                </div>

                {{-- Stats --}}
                <div class="mt-6 flex items-center gap-6 border-t border-gray-200 pt-4 dark:border-gray-700">
                    <div class="flex items-center gap-2 text-sm {{ $this->reply->likes_count > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-gray-500 dark:text-gray-400' }}">
                        <iconify-icon icon="lucide:heart" class="text-base"></iconify-icon>
                        <span>{{ number_format($this->reply->likes_count) }} {{ __('likes') }}</span>
                    </div>
                </div>
            </x-card.card>

            {{-- Parent Reply (if nested) --}}
            @if($this->reply->parent)
                <x-card.card>
                    <x-slot name="header">
                        <span class="flex items-center gap-2">
                            <iconify-icon icon="lucide:corner-down-right"></iconify-icon>
                            {{ __('In Reply To') }}
                        </span>
                    </x-slot>

                    <div class="flex items-start gap-3">
                        @if($this->reply->parent->user)
                            <img
                                src="{{ $this->reply->parent->user->avatar_url }}"
                                alt="{{ $this->reply->parent->user->full_name }}"
                                class="h-8 w-8 rounded-full object-cover"
                            />
                        @else
                            <div class="flex h-8 w-8 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-700">
                                <iconify-icon icon="lucide:user" class="text-sm text-gray-500"></iconify-icon>
                            </div>
                        @endif
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center gap-2">
                                <span class="font-medium text-gray-900 dark:text-white">{{ $this->reply->parent->user?->full_name ?? __('Unknown') }}</span>
                                <span class="text-xs text-gray-400">{{ $this->reply->parent->created_at->diffForHumans() }}</span>
                            </div>
                            <div class="mt-1 text-sm text-gray-600 dark:text-gray-400 line-clamp-3">
                                {{ Str::limit(strip_tags($this->reply->parent->content), 200) }}
                            </div>
                            <a href="{{ route('admin.forum.replies.show', $this->reply->parent) }}" class="mt-2 inline-flex items-center gap-1 text-xs text-primary-600 hover:text-primary-700 dark:text-primary-400">
                                {{ __('View parent reply') }}
                                <iconify-icon icon="lucide:arrow-right"></iconify-icon>
                            </a>
                        </div>
                    </div>
                </x-card.card>
            @endif

            {{-- Topic Context --}}
            @if($this->reply->topic)
                <x-card.card>
                    <x-slot name="header">{{ __('Topic Context') }}</x-slot>

                    <a href="{{ route('admin.forum.topics.show', $this->reply->topic) }}" class="group block">
                        <h3 class="font-medium text-gray-900 group-hover:text-primary-600 dark:text-white dark:group-hover:text-primary-400">
                            {{ $this->reply->topic->title }}
                        </h3>
                        <div class="mt-2 flex flex-wrap items-center gap-3 text-sm text-gray-500 dark:text-gray-400">
                            @if($this->reply->topic->category)
                                <span class="inline-flex items-center gap-1">
                                    <iconify-icon icon="lucide:folder" class="text-sm"></iconify-icon>
                                    {{ $this->reply->topic->category->name }}
                                </span>
                            @endif
                            <span class="flex items-center gap-1">
                                <iconify-icon icon="lucide:message-square" class="text-sm"></iconify-icon>
                                {{ $this->reply->topic->replies_count }} {{ __('replies') }}
                            </span>
                            <span class="flex items-center gap-1">
                                <iconify-icon icon="lucide:eye" class="text-sm"></iconify-icon>
                                {{ $this->reply->topic->views_count }} {{ __('views') }}
                            </span>
                        </div>
                    </a>
                </x-card.card>
            @endif
        </div>

        {{-- Sidebar --}}
        <div class="space-y-6">
            {{-- Quick Actions --}}
            <x-card.card>
                <x-slot name="header">{{ __('Quick Actions') }}</x-slot>

                <div class="space-y-3">
                    <button
                        type="button"
                        wire:click="toggleSolution"
                        class="flex w-full items-center justify-between rounded-lg border px-4 py-2.5 text-sm font-medium transition-colors {{ $this->reply->is_solution ? 'border-green-300 bg-green-50 text-green-700 dark:border-green-800 dark:bg-green-900/20 dark:text-green-400' : 'border-gray-300 bg-white text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700' }}"
                    >
                        <span class="flex items-center gap-2">
                            <iconify-icon icon="lucide:check-circle"></iconify-icon>
                            {{ $this->reply->is_solution ? __('Remove Solution') : __('Mark as Solution') }}
                        </span>
                        @if($this->reply->is_solution)
                            <iconify-icon icon="lucide:check" class="text-green-600"></iconify-icon>
                        @endif
                    </button>
                </div>
            </x-card.card>

            {{-- Details --}}
            <x-card.card>
                <x-slot name="header">{{ __('Details') }}</x-slot>

                <dl class="space-y-4">
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">{{ __('Author') }}</dt>
                        <dd class="mt-1 flex items-center gap-2 text-sm text-gray-900 dark:text-white">
                            @if($this->reply->user)
                                <img
                                    src="{{ $this->reply->user->avatar_url }}"
                                    alt="{{ $this->reply->user->full_name }}"
                                    class="h-6 w-6 rounded-full object-cover"
                                />
                            @endif
                            {{ $this->reply->user?->full_name ?? __('Unknown') }}
                        </dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">{{ __('Created') }}</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">{{ $this->reply->created_at->format('M d, Y \a\t H:i') }}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">{{ __('Last Updated') }}</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">{{ $this->reply->updated_at->diffForHumans() }}</dd>
                    </div>
                </dl>
            </x-card.card>

            {{-- Actions --}}
            <x-card.card>
                <x-slot name="header">{{ __('Actions') }}</x-slot>

                <div class="space-y-3">
                    <a
                        href="{{ route('admin.forum.replies.edit', $this->reply) }}"
                        class="flex w-full items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700"
                    >
                        <iconify-icon icon="lucide:pencil"></iconify-icon>
                        {{ __('Edit Reply') }}
                    </a>

                    @if($this->reply->topic)
                        <a
                            href="{{ route('admin.forum.topics.show', $this->reply->topic) }}"
                            class="flex w-full items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700"
                        >
                            <iconify-icon icon="lucide:message-circle"></iconify-icon>
                            {{ __('View Topic') }}
                        </a>
                    @endif
                </div>
            </x-card.card>
        </div>
    </div>
</div>
