<div>
    {{-- Breadcrumbs Header --}}
    <x-breadcrumbs :breadcrumbs="$this->breadcrumbs" />

    <form wire:submit="save" class="space-y-4">
        {{-- Two Column Layout for General Settings --}}
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {{-- Left Column: URL & Branding --}}
            <x-card.card>
                <x-slot name="header">{{ __('URL & Branding') }}</x-slot>

                <div class="space-y-3">
                    <div class="grid grid-cols-2 gap-3">
                        <x-inputs.input
                            wire:model="forum_base_url"
                            name="forum_base_url"
                            label="{{ __('Base URL') }}"
                            placeholder="/forum"
                            :required="true"
                        />

                        <x-inputs.input
                            wire:model="forum_title"
                            name="forum_title"
                            label="{{ __('Title') }}"
                            placeholder="{{ __('Forum') }}"
                            :required="true"
                        />
                    </div>

                    <div>
                        <label for="forum_description" class="form-label">{{ __('Description') }}</label>
                        <textarea
                            wire:model="forum_description"
                            id="forum_description"
                            name="forum_description"
                            rows="2"
                            placeholder="{{ __('A short description for the forum homepage...') }}"
                            class="form-control-textarea"
                        ></textarea>
                        @error('forum_description')
                            <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                        @enderror
                    </div>

                    <div>
                        <label for="forum_footer_text" class="form-label">{{ __('Footer Text') }}</label>
                        <textarea
                            wire:model="forum_footer_text"
                            id="forum_footer_text"
                            name="forum_footer_text"
                            rows="2"
                            placeholder="{{ __('Custom footer text or copyright notice...') }}"
                            class="form-control-textarea"
                        ></textarea>
                        @error('forum_footer_text')
                            <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                        @enderror
                    </div>
                </div>
            </x-card.card>

            {{-- Right Column: Pagination & Layout --}}
            <div class="space-y-4">
                <x-card.card>
                    <x-slot name="header">{{ __('Pagination Data') }}</x-slot>

                    <div class="grid grid-cols-2 gap-3">
                        <x-inputs.input
                            type="number"
                            wire:model="topics_per_page"
                            name="topics_per_page"
                            label="{{ __('Topics per page') }}"
                            min="5"
                            max="100"
                            :required="true"
                        />

                        <x-inputs.input
                            type="number"
                            wire:model="replies_per_page"
                            name="replies_per_page"
                            label="{{ __('Replies per page') }}"
                            min="5"
                            max="100"
                            :required="true"
                        />
                    </div>
                </x-card.card>

                <x-card.card>
                    <x-slot name="header">{{ __('Layout') }}</x-slot>

                    <div class="space-y-2">
                        <x-inputs.toggle
                            wire:model="show_forum_header"
                            name="show_forum_header"
                            label="{{ __('Show forum header') }}"
                        />

                        <x-inputs.toggle
                            wire:model="show_user_dropdown"
                            name="show_user_dropdown"
                            label="{{ __('Show user dropdown menu') }}"
                        />

                        <x-inputs.toggle
                            wire:model="show_forum_footer"
                            name="show_forum_footer"
                            label="{{ __('Show forum footer') }}"
                        />

                        <x-inputs.toggle
                            wire:model="show_page_title"
                            name="show_page_title"
                            label="{{ __('Show page title') }}"
                        />
                    </div>
                </x-card.card>
            </div>
        </div>

        {{-- Options Grid: Access Control & Features Combined --}}
        <x-card.card>
            <x-slot name="header">{{ __('Options') }}</x-slot>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-3">
                {{-- Access Control --}}
                <div class="space-y-2">
                    <h4 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{{ __('Access') }}</h4>
                    <x-inputs.toggle
                        wire:model="allow_guests_to_view"
                        name="allow_guests_to_view"
                        label="{{ __('Allow guests to view') }}"
                    />
                    <x-inputs.toggle
                        wire:model="require_email_verification"
                        name="require_email_verification"
                        label="{{ __('Require email verification') }}"
                    />
                </div>

                {{-- Content Features --}}
                <div class="space-y-2">
                    <h4 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{{ __('Content') }}</h4>
                    <x-inputs.toggle
                        wire:model="enable_likes"
                        name="enable_likes"
                        label="{{ __('Enable likes') }}"
                    />
                    <x-inputs.toggle
                        wire:model="enable_solutions"
                        name="enable_solutions"
                        label="{{ __('Enable solutions') }}"
                    />
                </div>

                {{-- Display Features --}}
                <div class="space-y-2">
                    <h4 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{{ __('Display') }}</h4>
                    <x-inputs.toggle
                        wire:model="show_view_count"
                        name="show_view_count"
                        label="{{ __('Show view count') }}"
                    />
                    <x-inputs.toggle
                        wire:model="allow_nested_replies"
                        name="allow_nested_replies"
                        label="{{ __('Allow nested replies') }}"
                    />
                </div>
            </div>
        </x-card.card>

        {{-- Save Button --}}
        <div class="flex justify-start">
            <x-buttons.button type="submit" variant="primary" icon="lucide:save" loadingTarget="save">
                {{ __('Save Settings') }}
            </x-buttons.button>
        </div>
    </form>
</div>
