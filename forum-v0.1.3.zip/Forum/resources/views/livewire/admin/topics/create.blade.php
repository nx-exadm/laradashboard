<div>
    {{-- Breadcrumbs Header --}}
    <x-breadcrumbs :breadcrumbs="$this->breadcrumbs" />

    {{-- Form --}}
    <form wire:submit="save" class="space-y-6">
        <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
            {{-- Main Content --}}
            <div class="lg:col-span-2 space-y-6">
                <x-card.card>
                    <x-slot name="header">{{ __('Topic Content') }}</x-slot>

                    <div class="space-y-6">
                        <x-inputs.input
                            wire:model.live.debounce.500ms="title"
                            name="title"
                            label="{{ __('Title') }}"
                            placeholder="{{ __('Enter a descriptive title...') }}"
                            description="{{ __('A clear title helps users find your topic.') }}"
                            :required="true"
                        />

                        <x-inputs.input
                            wire:model="slug"
                            name="slug"
                            label="{{ __('URL Slug') }}"
                            placeholder="{{ __('topic-url-slug') }}"
                            description="{{ __('Auto-generated from title. Used in the URL.') }}"
                            :required="true"
                        />

                        <div>
                            <label for="content" class="form-label">{{ __('Content') }} <span class="text-red-500">*</span></label>
                            <textarea
                                wire:model.defer="content"
                                id="content"
                                name="content"
                                rows="12"
                                placeholder="{{ __('Write your topic content here...') }}"
                                class="form-control-textarea"
                            ></textarea>
                        </div>
                        @push('scripts')
                            <x-text-editor editorId="content" type="basic" height="350px" />
                        @endpush
                        <p class="text-sm text-gray-500 dark:text-gray-400">{{ __('Use the rich text editor to format your content.') }}</p>
                        @error('content')
                            <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                        @enderror
                    </div>
                </x-card.card>
            </div>

            {{-- Sidebar --}}
            <div class="space-y-6">
                <x-card.card>
                    <x-slot name="header">{{ __('Publishing') }}</x-slot>

                    <div class="space-y-6">
                        <div wire:ignore>
                            <x-inputs.combobox
                                name="category_id"
                                wire:model.defer="category_id"
                                label="{{ __('Category') }}"
                                placeholder="{{ __('Select a category...') }}"
                                :options="$categories->map(fn($category) => [
                                    'value' => (string) $category->id,
                                    'label' => $category->name
                                ])->toArray()"
                                :selected="$category_id ? (string) $category_id : null"
                                :searchable="true"
                                :required="true"
                            />
                        </div>
                        @error('category_id')
                            <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                        @enderror

                        <div wire:ignore>
                            <x-inputs.combobox
                                name="user_id"
                                wire:model.defer="user_id"
                                label="{{ __('Author') }}"
                                placeholder="{{ __('Select an author...') }}"
                                :options="$users->map(fn($user) => [
                                    'value' => (string) $user->id,
                                    'label' => $user->full_name,
                                    'description' => $user->email
                                ])->toArray()"
                                :selected="$user_id ? (string) $user_id : null"
                                :searchable="true"
                                :required="true"
                            />
                        </div>
                        @error('user_id')
                            <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                        @enderror
                    </div>
                </x-card.card>

                <x-card.card>
                    <x-slot name="header">{{ __('Options') }}</x-slot>

                    <div class="space-y-4">
                        <x-inputs.toggle
                            wire:model="is_pinned"
                            name="is_pinned"
                            label="{{ __('Pin Topic') }}"
                            description="{{ __('Pinned topics appear at the top of the list.') }}"
                        />

                        <x-inputs.toggle
                            wire:model="is_locked"
                            name="is_locked"
                            label="{{ __('Lock Topic') }}"
                            description="{{ __('Locked topics cannot receive new replies.') }}"
                        />
                    </div>
                </x-card.card>
            </div>
        </div>

        {{-- Submit --}}
        <div class="flex items-center gap-4">
            <a wire:navigate href="{{ route('admin.forum.topics.index') }}" class="btn-default">
                {{ __('Cancel') }}
            </a>
            <x-buttons.button type="submit" variant="primary" icon="lucide:save" loadingTarget="save">
                {{ __('Create Topic') }}
            </x-buttons.button>
        </div>
    </form>

</div>
