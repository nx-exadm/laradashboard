<div x-data="{ deleteModalOpen: false }">
    {{-- Breadcrumbs Header --}}
    <x-breadcrumbs :breadcrumbs="$this->breadcrumbs" />

    {{-- Form --}}
    <form wire:submit="save" class="space-y-6">
        <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
            {{-- Main Content --}}
            <div class="lg:col-span-2 space-y-6">
                <x-card.card>
                    <x-slot name="header">{{ __('Topic Content') }}</x-slot>

                    <div class="space-y-6">
                        <x-inputs.input
                            wire:model="title"
                            name="title"
                            label="{{ __('Title') }}"
                            placeholder="{{ __('Enter a descriptive title...') }}"
                            description="{{ __('A clear title helps users find your topic.') }}"
                            :required="true"
                        />

                        <x-inputs.input
                            wire:model="slug"
                            name="slug"
                            label="{{ __('URL Slug') }}"
                            placeholder="{{ __('topic-url-slug') }}"
                            description="{{ __('Changing this may break existing links.') }}"
                            :required="true"
                        />

                        <div>
                            <label for="content" class="form-label">{{ __('Content') }} <span class="text-red-500">*</span></label>
                            <textarea
                                wire:model.defer="content"
                                id="content"
                                name="content"
                                rows="12"
                                placeholder="{{ __('Write your topic content here...') }}"
                                class="form-control-textarea"
                            ></textarea>
                        </div>
                        @push('scripts')
                            <x-text-editor editorId="content" type="basic" height="350px" />
                        @endpush
                        <p class="text-sm text-gray-500 dark:text-gray-400">{{ __('Use the rich text editor to format your content.') }}</p>
                        @error('content')
                            <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                        @enderror
                    </div>
                </x-card.card>
            </div>

            {{-- Sidebar --}}
            <div class="space-y-6">
                <x-card.card>
                    <x-slot name="header">{{ __('Publishing') }}</x-slot>

                    <div class="space-y-6">
                        <div wire:ignore>
                            <x-inputs.combobox
                                name="category_id"
                                wire:model.defer="category_id"
                                label="{{ __('Category') }}"
                                placeholder="{{ __('Select a category...') }}"
                                :options="$categories->map(fn($category) => [
                                    'value' => (string) $category->id,
                                    'label' => $category->name
                                ])->toArray()"
                                :selected="$category_id ? (string) $category_id : null"
                                :searchable="true"
                                :required="true"
                            />
                        </div>
                        @error('category_id')
                            <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                        @enderror

                        <div wire:ignore>
                            <x-inputs.combobox
                                name="user_id"
                                wire:model.defer="user_id"
                                label="{{ __('Author') }}"
                                placeholder="{{ __('Select an author...') }}"
                                :options="$users->map(fn($user) => [
                                    'value' => (string) $user->id,
                                    'label' => $user->full_name,
                                    'description' => $user->email
                                ])->toArray()"
                                :selected="$user_id ? (string) $user_id : null"
                                :searchable="true"
                                :required="true"
                            />
                        </div>
                        @error('user_id')
                            <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                        @enderror
                    </div>
                </x-card.card>

                <x-card.card>
                    <x-slot name="header">{{ __('Status') }}</x-slot>

                    <div class="space-y-4">
                        <x-inputs.toggle
                            wire:model="is_pinned"
                            name="is_pinned"
                            label="{{ __('Pin Topic') }}"
                            description="{{ __('Pinned topics appear at the top of the list.') }}"
                        />

                        <x-inputs.toggle
                            wire:model="is_locked"
                            name="is_locked"
                            label="{{ __('Lock Topic') }}"
                            description="{{ __('Locked topics cannot receive new replies.') }}"
                        />

                        <x-inputs.toggle
                            wire:model="is_solved"
                            name="is_solved"
                            label="{{ __('Mark as Solved') }}"
                            description="{{ __('Indicates this topic has a solution.') }}"
                        />
                    </div>
                </x-card.card>

                {{-- Stats (read-only) --}}
                <x-card.card>
                    <x-slot name="header">{{ __('Statistics') }}</x-slot>

                    <dl class="space-y-3">
                        <div class="flex items-center justify-between">
                            <dt class="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                                <iconify-icon icon="lucide:eye"></iconify-icon>
                                {{ __('Views') }}
                            </dt>
                            <dd class="text-sm font-medium text-gray-900 dark:text-white">{{ number_format($this->topic->views_count) }}</dd>
                        </div>
                        <div class="flex items-center justify-between">
                            <dt class="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                                <iconify-icon icon="lucide:message-square"></iconify-icon>
                                {{ __('Replies') }}
                            </dt>
                            <dd class="text-sm font-medium text-gray-900 dark:text-white">{{ number_format($this->topic->replies_count) }}</dd>
                        </div>
                        <div class="flex items-center justify-between">
                            <dt class="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                                <iconify-icon icon="lucide:calendar"></iconify-icon>
                                {{ __('Created') }}
                            </dt>
                            <dd class="text-sm font-medium text-gray-900 dark:text-white">{{ $this->topic->created_at->format('M d, Y') }}</dd>
                        </div>
                    </dl>
                </x-card.card>
            </div>
        </div>

        {{-- Submit --}}
        <div class="flex items-center justify-between">
            <div class="flex items-center gap-4">
                <a wire:navigate href="{{ route('admin.forum.topics.index') }}" class="btn-default">
                    {{ __('Cancel') }}
                </a>
                <x-buttons.button type="submit" variant="primary" icon="lucide:save" loadingTarget="save">
                    {{ __('Save Changes') }}
                </x-buttons.button>
            </div>

            <x-buttons.button
                type="button"
                variant="danger"
                icon="lucide:trash-2"
                x-on:click="deleteModalOpen = true"
            >
                {{ __('Delete') }}
            </x-buttons.button>
        </div>
    </form>

    {{-- Delete Confirmation Modal --}}
    <x-modals.confirm-delete
        id="delete-topic-modal"
        title="{{ __('Delete Topic') }}"
        content="{{ __('Are you sure you want to delete this topic? This will also delete all replies.') }}"
        wireClick="delete"
    />

</div>
