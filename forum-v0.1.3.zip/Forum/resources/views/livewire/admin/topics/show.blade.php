<div>
    {{-- Breadcrumbs Header --}}
    <x-breadcrumbs :breadcrumbs="$this->breadcrumbs" />

    <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {{-- Main Content --}}
        <div class="lg:col-span-2 space-y-6">
            {{-- Topic Header --}}
            <x-card.card>
                <div class="flex items-start gap-4">
                    @if($this->topic->user)
                        <img
                            src="{{ $this->topic->user->avatar_url }}"
                            alt="{{ $this->topic->user->full_name }}"
                            class="h-12 w-12 rounded-full object-cover"
                        />
                    @else
                        <div class="flex h-12 w-12 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-700">
                            <iconify-icon icon="lucide:user" class="text-xl text-gray-500"></iconify-icon>
                        </div>
                    @endif
                    <div class="flex-1 min-w-0">
                        <h2 class="text-xl font-bold text-gray-900 dark:text-white">{{ $this->topic->title }}</h2>
                        <div class="mt-1 flex flex-wrap items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                            <span>{{ __('by') }} <strong>{{ $this->topic->user?->full_name ?? __('Unknown') }}</strong></span>
                            <span>&bull;</span>
                            <span>{{ $this->topic->created_at->format('M d, Y \a\t H:i') }}</span>
                            @if($this->topic->category)
                                <span>&bull;</span>
                                <a href="{{ route('admin.forum.categories.show', $this->topic->category) }}" class="inline-flex items-center gap-1 text-primary-600 hover:text-primary-700 dark:text-primary-400">
                                    <iconify-icon icon="lucide:folder" class="text-sm"></iconify-icon>
                                    {{ $this->topic->category->name }}
                                </a>
                            @endif
                        </div>

                        {{-- Status Badges --}}
                        <div class="mt-3 flex flex-wrap gap-2">
                            @if($this->topic->is_pinned)
                                <span class="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2.5 py-1 text-xs font-medium text-amber-700 dark:bg-amber-900/30 dark:text-amber-400">
                                    <iconify-icon icon="lucide:pin" class="text-sm"></iconify-icon>
                                    {{ __('Pinned') }}
                                </span>
                            @endif
                            @if($this->topic->is_locked)
                                <span class="inline-flex items-center gap-1 rounded-full bg-red-100 px-2.5 py-1 text-xs font-medium text-red-700 dark:bg-red-900/30 dark:text-red-400">
                                    <iconify-icon icon="lucide:lock" class="text-sm"></iconify-icon>
                                    {{ __('Locked') }}
                                </span>
                            @endif
                            @if($this->topic->is_solved)
                                <span class="inline-flex items-center gap-1 rounded-full bg-green-100 px-2.5 py-1 text-xs font-medium text-green-700 dark:bg-green-900/30 dark:text-green-400">
                                    <iconify-icon icon="lucide:check-circle" class="text-sm"></iconify-icon>
                                    {{ __('Solved') }}
                                </span>
                            @endif
                        </div>
                    </div>
                </div>

                {{-- Content --}}
                <div class="mt-6 prose prose-sm dark:prose-invert max-w-none">
                    {!! $this->topic->content !!}
                </div>

                {{-- Stats --}}
                <div class="mt-6 flex items-center gap-6 border-t border-gray-200 pt-4 dark:border-gray-700">
                    <div class="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                        <iconify-icon icon="lucide:eye" class="text-base"></iconify-icon>
                        <span>{{ number_format($this->topic->views_count) }} {{ __('views') }}</span>
                    </div>
                    <div class="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                        <iconify-icon icon="lucide:message-square" class="text-base"></iconify-icon>
                        <span>{{ number_format($this->topic->replies_count) }} {{ __('replies') }}</span>
                    </div>
                </div>
            </x-card.card>

            {{-- Replies --}}
            <x-card.card>
                <x-slot name="header">
                    <div class="flex items-center justify-between">
                        <span>{{ __('Replies') }} ({{ $this->topic->replies_count }})</span>
                        @if($this->topic->replies_count > 10)
                            <a href="{{ route('admin.forum.replies.index') }}?topic={{ $this->topic->id }}" class="text-sm font-normal text-primary-600 hover:text-primary-700 dark:text-primary-400">
                                {{ __('View all') }}
                            </a>
                        @endif
                    </div>
                </x-slot>

                @if($replies->count() > 0)
                    <div class="divide-y divide-gray-200 dark:divide-gray-700">
                        @foreach($replies as $reply)
                            <div class="py-4 first:pt-0 last:pb-0">
                                <div class="flex items-start gap-3">
                                    @if($reply->user)
                                        <img
                                            src="{{ $reply->user->avatar_url }}"
                                            alt="{{ $reply->user->full_name }}"
                                            class="h-8 w-8 rounded-full object-cover"
                                        />
                                    @else
                                        <div class="flex h-8 w-8 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-700">
                                            <iconify-icon icon="lucide:user" class="text-sm text-gray-500"></iconify-icon>
                                        </div>
                                    @endif
                                    <div class="flex-1 min-w-0">
                                        <div class="flex items-center gap-2">
                                            <span class="font-medium text-gray-900 dark:text-white">{{ $reply->user?->full_name ?? __('Unknown') }}</span>
                                            <span class="text-xs text-gray-400">{{ $reply->created_at->diffForHumans() }}</span>
                                            @if($reply->is_solution)
                                                <span class="inline-flex items-center gap-1 rounded-full bg-green-100 px-2 py-0.5 text-xs font-medium text-green-700 dark:bg-green-900/30 dark:text-green-400">
                                                    <iconify-icon icon="lucide:check"></iconify-icon>
                                                    {{ __('Solution') }}
                                                </span>
                                            @endif
                                        </div>
                                        <div class="mt-1 text-sm text-gray-700 dark:text-gray-300 prose prose-sm dark:prose-invert max-w-none">
                                            {!! Str::limit(strip_tags($reply->content), 200) !!}
                                        </div>
                                        <div class="mt-2 flex items-center gap-4">
                                            <span class="flex items-center gap-1 text-xs text-gray-400">
                                                <iconify-icon icon="lucide:heart" class="{{ $reply->likes_count > 0 ? 'text-rose-500' : '' }}"></iconify-icon>
                                                {{ $reply->likes_count }}
                                            </span>
                                            <a href="{{ route('admin.forum.replies.show', $reply) }}" class="text-xs text-primary-600 hover:text-primary-700 dark:text-primary-400">
                                                {{ __('View reply') }}
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                @else
                    <div class="py-8 text-center">
                        <iconify-icon icon="lucide:message-square-off" class="text-4xl text-gray-300 dark:text-gray-600"></iconify-icon>
                        <p class="mt-2 text-gray-500 dark:text-gray-400">{{ __('No replies yet.') }}</p>
                    </div>
                @endif
            </x-card.card>
        </div>

        {{-- Sidebar --}}
        <div class="space-y-6">
            {{-- Quick Actions --}}
            <x-card.card>
                <x-slot name="header">{{ __('Quick Actions') }}</x-slot>

                <div class="space-y-3">
                    <button
                        type="button"
                        wire:click="togglePin"
                        class="flex w-full items-center justify-between rounded-lg border px-4 py-2.5 text-sm font-medium transition-colors {{ $this->topic->is_pinned ? 'border-amber-300 bg-amber-50 text-amber-700 dark:border-amber-800 dark:bg-amber-900/20 dark:text-amber-400' : 'border-gray-300 bg-white text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700' }}"
                    >
                        <span class="flex items-center gap-2">
                            <iconify-icon icon="lucide:pin"></iconify-icon>
                            {{ $this->topic->is_pinned ? __('Unpin Topic') : __('Pin Topic') }}
                        </span>
                        @if($this->topic->is_pinned)
                            <iconify-icon icon="lucide:check" class="text-amber-600"></iconify-icon>
                        @endif
                    </button>

                    <button
                        type="button"
                        wire:click="toggleLock"
                        class="flex w-full items-center justify-between rounded-lg border px-4 py-2.5 text-sm font-medium transition-colors {{ $this->topic->is_locked ? 'border-red-300 bg-red-50 text-red-700 dark:border-red-800 dark:bg-red-900/20 dark:text-red-400' : 'border-gray-300 bg-white text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700' }}"
                    >
                        <span class="flex items-center gap-2">
                            <iconify-icon icon="lucide:{{ $this->topic->is_locked ? 'lock' : 'unlock' }}"></iconify-icon>
                            {{ $this->topic->is_locked ? __('Unlock Topic') : __('Lock Topic') }}
                        </span>
                        @if($this->topic->is_locked)
                            <iconify-icon icon="lucide:check" class="text-red-600"></iconify-icon>
                        @endif
                    </button>

                    <button
                        type="button"
                        wire:click="toggleSolved"
                        class="flex w-full items-center justify-between rounded-lg border px-4 py-2.5 text-sm font-medium transition-colors {{ $this->topic->is_solved ? 'border-green-300 bg-green-50 text-green-700 dark:border-green-800 dark:bg-green-900/20 dark:text-green-400' : 'border-gray-300 bg-white text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700' }}"
                    >
                        <span class="flex items-center gap-2">
                            <iconify-icon icon="lucide:check-circle"></iconify-icon>
                            {{ $this->topic->is_solved ? __('Mark Unsolved') : __('Mark Solved') }}
                        </span>
                        @if($this->topic->is_solved)
                            <iconify-icon icon="lucide:check" class="text-green-600"></iconify-icon>
                        @endif
                    </button>
                </div>
            </x-card.card>

            {{-- Details --}}
            <x-card.card>
                <x-slot name="header">{{ __('Details') }}</x-slot>

                <dl class="space-y-4">
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">{{ __('Slug') }}</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white font-mono">/{{ $this->topic->slug }}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">{{ __('Created') }}</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">{{ $this->topic->created_at->format('M d, Y \a\t H:i') }}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">{{ __('Last Updated') }}</dt>
                        <dd class="mt-1 text-sm text-gray-900 dark:text-white">{{ $this->topic->updated_at->diffForHumans() }}</dd>
                    </div>
                </dl>
            </x-card.card>

            {{-- Actions --}}
            <x-card.card>
                <x-slot name="header">{{ __('Actions') }}</x-slot>

                <div class="space-y-3">
                    <a
                        href="{{ route('admin.forum.topics.edit', $this->topic) }}"
                        class="flex w-full items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700"
                    >
                        <iconify-icon icon="lucide:pencil"></iconify-icon>
                        {{ __('Edit Topic') }}
                    </a>

                    <a
                        href="{{ route('forum.topic', ['category' => $this->topic->category?->slug ?? 'general', 'topic' => $this->topic->slug]) }}"
                        target="_blank"
                        class="flex w-full items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700"
                    >
                        <iconify-icon icon="lucide:external-link"></iconify-icon>
                        {{ __('View on Forum') }}
                    </a>
                </div>
            </x-card.card>
        </div>
    </div>
</div>
