<div>
    {{-- Breadcrumb --}}
    <nav class="forum:mb-6">
        <ol class="forum:flex forum:items-center forum:gap-2 forum:text-sm">
            <li>
                <a href="{{ route('forum.index') }}" class="link-secondary">
                    {{ __('Forum') }}
                </a>
            </li>
            <li class="forum:text-gray-400 forum:dark:text-gray-600">/</li>
            <li class="forum:text-gray-900 forum:dark:text-white forum:font-medium">{{ $category->name }}</li>
        </ol>
    </nav>

    {{-- Page Header --}}
    <div class="forum:mb-8 forum:flex forum:items-center forum:gap-4">
        <div class="forum:w-12 forum:h-12 forum:rounded-lg forum:bg-{{ $category->color }}-100 forum:dark:bg-{{ $category->color }}-900/30 forum:flex forum:items-center forum:justify-center">
            <iconify-icon icon="{{ $category->icon ?? 'lucide:folder' }}" class="forum:text-2xl forum:text-{{ $category->color }}-600 forum:dark:text-{{ $category->color }}-400"></iconify-icon>
        </div>
        <div>
            <h1 class="page-title">{{ $category->name }}</h1>
            @if($category->description)
                <p class="page-description">{{ $category->description }}</p>
            @endif
        </div>
    </div>

    {{-- Filters --}}
    <div class="forum:mb-6 forum:flex forum:items-center forum:gap-2">
        <span class="forum:text-sm forum:text-gray-500 forum:dark:text-gray-400">{{ __('Filter:') }}</span>
        <button wire:click="$set('filter', '')"
                class="forum:px-3 forum:py-1 forum:text-sm forum:rounded-full forum:transition-colors {{ $filter === '' ? 'forum:bg-primary/10 forum:text-primary' : 'forum:bg-gray-100 forum:dark:bg-gray-800 forum:text-gray-600 forum:dark:text-gray-400 forum:hover:bg-gray-200 forum:dark:hover:bg-gray-700' }}">
            {{ __('All') }}
        </button>
        <button wire:click="$set('filter', 'solved')"
                class="forum:inline-flex forum:items-center forum:gap-1 forum:px-3 forum:py-1 forum:text-sm forum:rounded-full forum:transition-colors {{ $filter === 'solved' ? 'forum:bg-green-100 forum:dark:bg-green-900/30 forum:text-green-700 forum:dark:text-green-300' : 'forum:bg-gray-100 forum:dark:bg-gray-800 forum:text-gray-600 forum:dark:text-gray-400 forum:hover:bg-gray-200 forum:dark:hover:bg-gray-700' }}">
            <iconify-icon icon="lucide:check-circle" class="forum:text-xs"></iconify-icon>
            {{ __('Solved') }}
        </button>
        <button wire:click="$set('filter', 'unsolved')"
                class="forum:inline-flex forum:items-center forum:gap-1 forum:px-3 forum:py-1 forum:text-sm forum:rounded-full forum:transition-colors {{ $filter === 'unsolved' ? 'forum:bg-orange-100 forum:dark:bg-orange-900/30 forum:text-orange-700 forum:dark:text-orange-300' : 'forum:bg-gray-100 forum:dark:bg-gray-800 forum:text-gray-600 forum:dark:text-gray-400 forum:hover:bg-gray-200 forum:dark:hover:bg-gray-700' }}">
            <iconify-icon icon="lucide:circle" class="forum:text-xs"></iconify-icon>
            {{ __('Unsolved') }}
        </button>
    </div>

    {{-- Topics List --}}
    <div class="card forum:overflow-hidden">
        @forelse($topics as $topic)
            <a href="{{ route('forum.topic', [$category->slug, $topic->slug]) }}" wire:key="topic-{{ $topic->id }}"
               class="forum:block forum:border-b forum:border-gray-200 forum:dark:border-gray-700 forum:last:border-b-0 forum:p-4 forum:hover:bg-gray-50 forum:dark:hover:bg-gray-700/50 forum:transition-colors">
                <div class="forum:flex forum:items-start forum:gap-4">
                    {{-- Author Avatar --}}
                    <div class="forum:shrink-0 forum:w-10 forum:h-10 forum:rounded-full forum:bg-primary/10 forum:flex forum:items-center forum:justify-center forum:text-primary forum:font-medium">
                        {{ strtoupper(substr($topic->user->full_name, 0, 1)) }}
                    </div>

                    {{-- Content --}}
                    <div class="forum:flex-1 forum:min-w-0">
                        <div class="forum:flex forum:items-center forum:gap-2 forum:flex-wrap">
                            {{-- Badges --}}
                            @if($topic->is_pinned)
                                <span class="badge-warning">
                                    <iconify-icon icon="lucide:pin" class="forum:text-xs forum:mr-1"></iconify-icon>
                                    {{ __('Pinned') }}
                                </span>
                            @endif
                            @if($topic->is_locked)
                                <span class="badge-danger">
                                    <iconify-icon icon="lucide:lock" class="forum:text-xs forum:mr-1"></iconify-icon>
                                    {{ __('Locked') }}
                                </span>
                            @endif
                            @if($topic->is_solved)
                                <span class="badge-success">
                                    <iconify-icon icon="lucide:check-circle" class="forum:text-xs forum:mr-1"></iconify-icon>
                                    {{ __('Solved') }}
                                </span>
                            @endif

                            {{-- Title --}}
                            <h3 class="forum:font-semibold forum:text-gray-900 forum:dark:text-white">
                                {{ $topic->title }}
                            </h3>
                        </div>

                        {{-- Meta --}}
                        <div class="forum:mt-1 forum:flex forum:items-center forum:gap-4 forum:text-sm forum:text-gray-500 forum:dark:text-gray-400">
                            <span>{{ __('by') }} <span class="forum:font-medium forum:text-gray-700 forum:dark:text-gray-300">{{ $topic->user->full_name }}</span></span>
                            <span>{{ $topic->created_at->diffForHumans() }}</span>
                        </div>
                    </div>

                    {{-- Stats --}}
                    <div class="forum:shrink-0 forum:flex forum:items-center forum:gap-4 forum:text-sm forum:text-gray-500 forum:dark:text-gray-400">
                        <div class="forum:flex forum:items-center forum:gap-1" title="{{ __('Replies') }}">
                            <iconify-icon icon="lucide:message-circle" class="forum:text-base"></iconify-icon>
                            <span>{{ $topic->replies_count }}</span>
                        </div>
                        <div class="forum:flex forum:items-center forum:gap-1" title="{{ __('Views') }}">
                            <iconify-icon icon="lucide:eye" class="forum:text-base"></iconify-icon>
                            <span>{{ $topic->views_count }}</span>
                        </div>
                        <div class="forum:flex forum:items-center forum:gap-1" title="{{ __('Likes') }}">
                            <iconify-icon icon="lucide:heart" class="forum:text-base"></iconify-icon>
                            <span>{{ $topic->likes_count }}</span>
                        </div>
                    </div>
                </div>

                {{-- Last Reply --}}
                @if($topic->lastReplyUser)
                    <div class="forum:mt-2 forum:ml-14 forum:text-sm forum:text-gray-500 forum:dark:text-gray-400">
                        {{ __('Last reply by') }}
                        <span class="forum:font-medium forum:text-gray-700 forum:dark:text-gray-300">{{ $topic->lastReplyUser->full_name }}</span>
                        {{ $topic->last_reply_at->diffForHumans() }}
                    </div>
                @endif
            </a>
        @empty
            <div class="forum:text-center forum:py-12">
                <iconify-icon icon="lucide:message-square" class="forum:text-5xl forum:mx-auto forum:text-gray-400"></iconify-icon>
                <h3 class="forum:mt-4 forum:text-lg forum:font-medium forum:text-gray-900 forum:dark:text-white">{{ __('No topics yet') }}</h3>
                <p class="forum:mt-2 forum:text-gray-500 forum:dark:text-gray-400">{{ __('Be the first to start a discussion!') }}</p>
                @auth
                    <a href="{{ route('forum.create.category', $category->slug) }}" class="btn-primary forum:mt-4">
                        <iconify-icon icon="lucide:plus" class="forum:text-base"></iconify-icon>
                        {{ __('Create Topic') }}
                    </a>
                @endauth
            </div>
        @endforelse
    </div>

    {{-- Pagination --}}
    @if($topics->hasPages())
        <div class="forum:mt-6">
            {{ $topics->links() }}
        </div>
    @endif
</div>
