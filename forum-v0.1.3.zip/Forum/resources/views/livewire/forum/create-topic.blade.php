<div>
    {{-- Breadcrumb --}}
    <nav class="forum:mb-6">
        <ol class="forum:flex forum:items-center forum:gap-2 forum:text-sm">
            <li>
                <a href="{{ route('forum.index') }}" class="link-secondary">
                    {{ __('Forum') }}
                </a>
            </li>
            <li class="forum:text-gray-400 forum:dark:text-gray-600">/</li>
            <li class="forum:text-gray-900 forum:dark:text-white forum:font-medium">{{ __('New Topic') }}</li>
        </ol>
    </nav>

    {{-- Page Header --}}
    <div class="forum:mb-8">
        <h1 class="page-title">{{ __('Create New Topic') }}</h1>
        <p class="page-description">{{ __('Start a new discussion in the forum.') }}</p>
    </div>

    {{-- Form --}}
    <div class="card">
        <div class="card-body">
            <form wire:submit="createTopic" class="forum:space-y-6">
                {{-- Category --}}
                <div wire:ignore>
                    <x-inputs.combobox
                        name="category_id"
                        label="{{ __('Category') }}"
                        placeholder="{{ __('Select a category...') }}"
                        :options="$categories->map(fn($category) => [
                            'value' => $category->id,
                            'label' => $category->name,
                            'description' => $category->description ? Str::limit($category->description, 50) : null
                        ])->toArray()"
                        :selected="$category_id"
                        :searchable="true"
                        :required="true"
                    />
                </div>
                @error('category_id')
                    <p class="forum:mt-1 forum:text-sm forum:text-red-600 forum:dark:text-red-400">{{ $message }}</p>
                @enderror

                {{-- Title --}}
                <div>
                    <label for="title" class="form-label">
                        {{ __('Title') }} <span class="forum:text-red-500">*</span>
                    </label>
                    <input
                        type="text"
                        wire:model="title"
                        id="title"
                        placeholder="{{ __('Enter a descriptive title for your topic...') }}"
                        class="form-control"
                    >
                    @error('title')
                        <p class="forum:mt-1 forum:text-sm forum:text-red-600 forum:dark:text-red-400">{{ $message }}</p>
                    @enderror
                </div>

                {{-- Content --}}
                <div>
                    <div wire:ignore>
                        <label for="content" class="form-label">
                            {{ __('Content') }} <span class="forum:text-red-500">*</span>
                        </label>
                        <textarea
                            wire:model.defer="content"
                            id="content"
                            rows="10"
                            placeholder="{{ __('Describe your topic in detail...') }}"
                            class="form-control-textarea"
                        ></textarea>
                        <x-text-editor editorId="content" type="basic" height="300px" :customToolbar="'undo redo | bold italic underline | alignleft aligncenter alignright | bullist numlist | link image media | removeformat'" />
                    </div>
                    @error('content')
                        <p class="forum:mt-1 forum:text-sm forum:text-red-600 forum:dark:text-red-400">{{ $message }}</p>
                    @enderror
                    <p class="forum:mt-1 forum:text-sm forum:text-gray-500 forum:dark:text-gray-400">
                        {{ __('Use the editor toolbar to format your content.') }}
                    </p>
                </div>

                {{-- Actions --}}
                <div class="forum:flex forum:items-center forum:justify-end forum:gap-4 forum:pt-4 forum:border-t forum:border-gray-200 forum:dark:border-gray-700">
                    <a href="{{ route('forum.index') }}" class="link-secondary forum:text-sm forum:font-medium">
                        {{ __('Cancel') }}
                    </a>
                    <button type="submit" class="btn-primary">
                        <iconify-icon icon="lucide:send" class="forum:text-base"></iconify-icon>
                        {{ __('Create Topic') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
