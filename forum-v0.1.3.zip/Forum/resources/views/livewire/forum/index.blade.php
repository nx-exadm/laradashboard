<div>
    {{-- Page Header --}}
    @if($showPageTitle || $forumDescription)
        <div class="forum:mb-8">
            @if($showPageTitle)
                <h1 class="page-title forum:text-3xl">{{ $forumTitle }}</h1>
            @endif
            @if($forumDescription)
                <p class="page-description">{{ $forumDescription }}</p>
            @endif
        </div>
    @endif

    {{-- Categories Grid --}}
    <div class="forum:space-y-4">
        @forelse($categories as $category)
            <a href="{{ route('forum.category', $category->slug) }}" wire:key="category-{{ $category->id }}"
               class="card forum:block forum:p-6 forum:hover:border-primary forum:transition-colors">
                <div class="forum:flex forum:items-start forum:gap-4">
                    {{-- Icon --}}
                    <div class="forum:shrink-0 forum:w-12 forum:h-12 forum:rounded-lg forum:bg-{{ $category->color }}-100 forum:dark:bg-{{ $category->color }}-900/30 forum:flex forum:items-center forum:justify-center">
                        <iconify-icon icon="{{ $category->icon ?? 'lucide:folder' }}" class="forum:text-2xl forum:text-{{ $category->color }}-600 forum:dark:text-{{ $category->color }}-400"></iconify-icon>
                    </div>

                    {{-- Content --}}
                    <div class="forum:flex-1 forum:min-w-0">
                        <div class="forum:flex forum:items-center forum:gap-3">
                            <h2 class="forum:text-lg forum:font-semibold forum:text-gray-900 forum:dark:text-white">
                                {{ $category->name }}
                            </h2>
                            <span class="badge">
                                {{ $category->topics_count }} {{ __('topics') }}
                            </span>
                        </div>

                        @if($category->description)
                            <p class="forum:mt-1 forum:text-sm forum:text-gray-600 forum:dark:text-gray-400 forum:line-clamp-2">
                                {{ $category->description }}
                            </p>
                        @endif

                        {{-- Last Activity --}}
                        @if($category->lastTopic)
                            <div class="forum:mt-3 forum:flex forum:items-center forum:gap-2 forum:text-sm forum:text-gray-500 forum:dark:text-gray-500">
                                <iconify-icon icon="lucide:message-circle" class="forum:text-base"></iconify-icon>
                                <span class="forum:truncate">
                                    {{ __('Last:') }}
                                    <span class="forum:font-medium forum:text-gray-700 forum:dark:text-gray-300">{{ Str::limit($category->lastTopic->title, 40) }}</span>
                                    {{ __('by') }}
                                    <span class="forum:text-gray-700 forum:dark:text-gray-300">{{ $category->lastTopic->user->full_name }}</span>
                                    {{ $category->lastTopic->created_at->diffForHumans() }}
                                </span>
                            </div>
                        @endif
                    </div>

                    {{-- Arrow --}}
                    <iconify-icon icon="lucide:chevron-right" class="forum:text-xl forum:text-gray-400 forum:shrink-0"></iconify-icon>
                </div>
            </a>
        @empty
            <div class="card forum:text-center forum:py-12">
                <iconify-icon icon="lucide:inbox" class="forum:text-5xl forum:mx-auto forum:text-gray-400"></iconify-icon>
                <h3 class="forum:mt-4 forum:text-lg forum:font-medium forum:text-gray-900 forum:dark:text-white">{{ __('No categories yet') }}</h3>
                <p class="forum:mt-2 forum:text-gray-500 forum:dark:text-gray-400">{{ __('Forum categories will appear here once created.') }}</p>
            </div>
        @endforelse
    </div>
</div>
