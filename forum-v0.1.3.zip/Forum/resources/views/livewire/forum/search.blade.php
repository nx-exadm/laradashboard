<div>
    {{-- Breadcrumb --}}
    <nav class="forum:mb-6">
        <ol class="forum:flex forum:items-center forum:gap-2 forum:text-sm">
            <li>
                <a href="{{ route('forum.index') }}" class="link-secondary">
                    {{ __('Forum') }}
                </a>
            </li>
            <li class="forum:text-gray-400 forum:dark:text-gray-600">/</li>
            <li class="forum:text-gray-900 forum:dark:text-white forum:font-medium">{{ __('Search') }}</li>
        </ol>
    </nav>

    {{-- Page Header --}}
    <div class="forum:mb-8">
        <h1 class="page-title">{{ __('Search Forum') }}</h1>
    </div>

    {{-- Search Input --}}
    <div class="forum:mb-8">
        <div class="forum:relative forum:max-w-2xl">
            <input
                type="search"
                wire:model.live.debounce.300ms="query"
                placeholder="{{ __('Search for topics...') }}"
                class="form-control forum:pl-12 forum:py-3 forum:text-lg"
            >
            <iconify-icon icon="lucide:search" class="forum:absolute forum:left-4 forum:top-1/2 forum:-translate-y-1/2 forum:text-xl forum:text-gray-400"></iconify-icon>
        </div>
        <p class="forum:mt-2 forum:text-sm forum:text-gray-500 forum:dark:text-gray-400">
            {{ __('Enter at least 3 characters to search.') }}
        </p>
    </div>

    {{-- Results --}}
    @if(strlen($query) >= 3)
        @if($topics instanceof \Illuminate\Pagination\LengthAwarePaginator && $topics->count() > 0)
            <div class="forum:mb-4 forum:text-sm forum:text-gray-500 forum:dark:text-gray-400">
                {{ __('Found :count results for ":query"', ['count' => $topics->total(), 'query' => $query]) }}
            </div>

            <div class="card forum:overflow-hidden">
                @foreach($topics as $topic)
                    <a href="{{ route('forum.topic', [$topic->category->slug, $topic->slug]) }}" wire:key="search-{{ $topic->id }}"
                       class="forum:block forum:border-b forum:border-gray-200 forum:dark:border-gray-700 forum:last:border-b-0 forum:p-4 forum:hover:bg-gray-50 forum:dark:hover:bg-gray-700/50 forum:transition-colors">
                        <div class="forum:flex forum:items-start forum:gap-4">
                            {{-- Category Badge --}}
                            <span class="badge-{{ $topic->category->color ?? 'secondary' }}">
                                {{ $topic->category->name }}
                            </span>

                            <div class="forum:flex-1 forum:min-w-0">
                                <div class="forum:flex forum:items-center forum:gap-2 forum:flex-wrap">
                                    @if($topic->is_solved)
                                        <span class="badge-success">
                                            <iconify-icon icon="lucide:check-circle" class="forum:text-xs forum:mr-1"></iconify-icon>
                                            {{ __('Solved') }}
                                        </span>
                                    @endif
                                    <h3 class="forum:font-semibold forum:text-gray-900 forum:dark:text-white">
                                        {{ $topic->title }}
                                    </h3>
                                </div>

                                <p class="forum:mt-1 forum:text-sm forum:text-gray-600 forum:dark:text-gray-400 forum:line-clamp-2">
                                    {{ $topic->excerpt }}
                                </p>

                                <div class="forum:mt-2 forum:flex forum:items-center forum:gap-4 forum:text-sm forum:text-gray-500 forum:dark:text-gray-400">
                                    <span>{{ __('by') }} <span class="forum:font-medium">{{ $topic->user->full_name }}</span></span>
                                    <span>{{ $topic->created_at->diffForHumans() }}</span>
                                    <span class="forum:flex forum:items-center forum:gap-1">
                                        <iconify-icon icon="lucide:message-circle" class="forum:text-base"></iconify-icon>
                                        {{ $topic->replies_count }}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </a>
                @endforeach
            </div>

            {{-- Pagination --}}
            @if($topics->hasPages())
                <div class="forum:mt-6">
                    {{ $topics->links() }}
                </div>
            @endif
        @else
            <div class="card forum:text-center forum:py-12">
                <iconify-icon icon="lucide:search-x" class="forum:text-5xl forum:mx-auto forum:text-gray-400"></iconify-icon>
                <h3 class="forum:mt-4 forum:text-lg forum:font-medium forum:text-gray-900 forum:dark:text-white">{{ __('No results found') }}</h3>
                <p class="forum:mt-2 forum:text-gray-500 forum:dark:text-gray-400">
                    {{ __('Try different keywords or check your spelling.') }}
                </p>
            </div>
        @endif
    @else
        <div class="card forum:text-center forum:py-12">
            <iconify-icon icon="lucide:search" class="forum:text-5xl forum:mx-auto forum:text-gray-400"></iconify-icon>
            <h3 class="forum:mt-4 forum:text-lg forum:font-medium forum:text-gray-900 forum:dark:text-white">{{ __('Start searching') }}</h3>
            <p class="forum:mt-2 forum:text-gray-500 forum:dark:text-gray-400">
                {{ __('Enter your search query above to find topics.') }}
            </p>
        </div>
    @endif
</div>
