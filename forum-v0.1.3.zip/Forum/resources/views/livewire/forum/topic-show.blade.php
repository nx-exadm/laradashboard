<div>
    {{-- Breadcrumb --}}
    <nav class="forum:mb-6">
        <ol class="forum:flex forum:items-center forum:gap-2 forum:text-sm forum:flex-wrap">
            <li>
                <a href="{{ route('forum.index') }}" class="link-secondary">
                    {{ __('Forum') }}
                </a>
            </li>
            <li class="forum:text-gray-400 forum:dark:text-gray-600">/</li>
            <li>
                <a href="{{ route('forum.category', $category->slug) }}" class="link-secondary">
                    {{ $category->name }}
                </a>
            </li>
            <li class="forum:text-gray-400 forum:dark:text-gray-600">/</li>
            <li class="forum:text-gray-900 forum:dark:text-white forum:font-medium forum:truncate forum:max-w-xs">{{ $topic->title }}</li>
        </ol>
    </nav>

    {{-- Topic --}}
    <article class="card forum:overflow-hidden forum:mb-6 forum:group">
        {{-- Topic Header --}}
        <div class="card-header">
            <div class="forum:flex forum:items-center forum:gap-4">
                {{-- Author Avatar --}}
                <div class="forum:shrink-0 forum:w-12 forum:h-12 forum:rounded-full forum:bg-primary/10 forum:flex forum:items-center forum:justify-center forum:text-primary forum:font-semibold forum:text-lg">
                    {{ strtoupper(substr($topic->user->full_name, 0, 1)) }}
                </div>

                {{-- Title and Meta --}}
                <div class="forum:flex-1 forum:min-w-0">
                    @if($editingTopic)
                        {{-- Edit Topic Form --}}
                        <form wire:submit="updateTopic" class="forum:space-y-3"
                            x-on:submit="if(editor) { @this.set('editingTopicContent', editor.getContent(), false); }"
                            x-data="{
                                editor: null,
                                init() {
                                    this.$nextTick(() => {
                                        if (typeof tinymce !== 'undefined') {
                                            this.initEditor();
                                        }
                                    });
                                },
                                initEditor() {
                                    const textarea = document.getElementById('editingTopicContent');
                                    if (!textarea || tinymce.get('editingTopicContent')) return;

                                    tinymce.init({
                                        selector: '#editingTopicContent',
                                        height: 250,
                                        menubar: false,
                                        plugins: 'autolink link image lists',
                                        toolbar: 'undo redo | bold italic underline | alignleft aligncenter alignright | bullist numlist | link image media | removeformat',
                                        skin: document.documentElement.classList.contains('dark') ? 'oxide-dark' : 'oxide',
                                        content_css: document.documentElement.classList.contains('dark') ? 'dark' : 'default',
                                        branding: false,
                                        promotion: false,
                                        statusbar: false,
                                        setup: (editor) => {
                                            this.editor = editor;
                                            editor.on('change keyup', () => {
                                                textarea.value = editor.getContent();
                                            });
                                        },
                                        init_instance_callback: (editor) => {
                                            editor.setContent(textarea.value || '');
                                            textarea.style.display = 'none';
                                        }
                                    });
                                },
                                destroy() {
                                    if (this.editor) {
                                        tinymce.remove(this.editor);
                                        this.editor = null;
                                    }
                                }
                            }"
                            x-init="init()"
                            @topic-edit-cancelled.window="destroy()"
                        >
                            <div>
                                <input
                                    type="text"
                                    wire:model="editingTopicTitle"
                                    class="form-control"
                                    placeholder="{{ __('Topic title') }}"
                                />
                                @error('editingTopicTitle')
                                    <p class="forum:mt-1 forum:text-sm forum:text-red-600 forum:dark:text-red-400">{{ $message }}</p>
                                @enderror
                            </div>
                            <div wire:ignore>
                                <textarea
                                    wire:model.defer="editingTopicContent"
                                    id="editingTopicContent"
                                    rows="4"
                                    class="form-control-textarea"
                                    placeholder="{{ __('Topic content') }}"
                                ></textarea>
                            </div>
                            @error('editingTopicContent')
                                <p class="forum:mt-1 forum:text-sm forum:text-red-600 forum:dark:text-red-400">{{ $message }}</p>
                            @enderror
                            <div class="forum:flex forum:items-center forum:gap-2">
                                <button type="submit" class="btn-primary btn-sm">
                                    <iconify-icon icon="lucide:check" class="forum:text-base"></iconify-icon>
                                    {{ __('Save') }}
                                </button>
                                <button type="button" wire:click="cancelEditTopic" class="btn-secondary btn-sm" @click="destroy()">
                                    {{ __('Cancel') }}
                                </button>
                            </div>
                        </form>
                    @else
                        <div class="forum:flex forum:items-center forum:gap-2 forum:flex-wrap">
                            <h1 class="page-title forum:!mb-0">
                                {{ $topic->title }}
                            </h1>
                            @if($topic->is_pinned)
                                <span class="badge-warning">
                                    <iconify-icon icon="lucide:pin" class="forum:text-xs forum:mr-1"></iconify-icon>
                                    {{ __('Pinned') }}
                                </span>
                            @endif
                            @if($topic->is_locked)
                                <span class="badge-danger">
                                    <iconify-icon icon="lucide:lock" class="forum:text-xs forum:mr-1"></iconify-icon>
                                    {{ __('Locked') }}
                                </span>
                            @endif
                            @if($topic->is_solved)
                                <span class="badge-success">
                                    <iconify-icon icon="lucide:check-circle" class="forum:text-xs forum:mr-1"></iconify-icon>
                                    {{ __('Solved') }}
                                </span>
                            @endif
                        </div>

                        <div class="forum:mt-1 forum:flex forum:items-center forum:gap-4 forum:text-sm forum:text-gray-500 forum:dark:text-gray-400">
                            <span class="forum:font-medium forum:text-gray-700 forum:dark:text-gray-300">{{ $topic->user->full_name }}</span>
                            <span>{{ $topic->created_at->format('M d, Y \a\t H:i') }}</span>
                            <span class="forum:flex forum:items-center forum:gap-1">
                                <iconify-icon icon="lucide:eye" class="forum:text-base"></iconify-icon>
                                {{ $topic->views_count }} {{ __('views') }}
                            </span>
                            @if($topic->updated_at->gt($topic->created_at))
                                <span class="forum:italic">{{ __('(edited)') }}</span>
                            @endif
                        </div>
                    @endif
                </div>

                {{-- Topic Author Actions (visible on hover) --}}
                @if(auth()->check() && $topic->user_id === auth()->id() && !$topic->is_locked && !$editingTopic)
                    <div class="forum:shrink-0 forum:flex forum:items-center forum:gap-2 forum:opacity-0 forum:group-hover:opacity-100 forum:transition-opacity">
                        <button wire:click="editTopic" class="forum:p-2 forum:text-gray-500 forum:hover:text-primary forum:transition-colors" title="{{ __('Edit') }}">
                            <iconify-icon icon="lucide:pencil" class="forum:text-lg"></iconify-icon>
                        </button>
                        <button wire:click="deleteTopic" wire:confirm="{{ __('Are you sure you want to delete this topic? This action cannot be undone.') }}" class="forum:p-2 forum:text-gray-500 forum:hover:text-red-600 forum:transition-colors" title="{{ __('Delete') }}">
                            <iconify-icon icon="lucide:trash-2" class="forum:text-lg"></iconify-icon>
                        </button>
                    </div>
                @endif
            </div>
        </div>

        {{-- Topic Content --}}
        @if(!$editingTopic)
            <div class="card-body">
                <div class="prose forum:max-w-none">
                    {!! \Modules\Forum\Helpers\ForumHelper::linkify($topic->content) !!}
                </div>
            </div>
        @endif

        {{-- Topic Actions --}}
        <div class="card-footer forum:bg-gray-50 forum:dark:bg-gray-700/50 forum:flex forum:items-center forum:justify-between">
            <div class="forum:flex forum:items-center forum:gap-4">
                {{-- Like Button --}}
                <button wire:click="toggleLikeTopic" class="forum:flex forum:items-center forum:gap-2 forum:text-sm {{ $topic->isLikedBy(auth()->user()) ? 'forum:text-red-600 forum:dark:text-red-400' : 'forum:text-gray-500 forum:dark:text-gray-400 forum:hover:text-red-600 forum:dark:hover:text-red-400' }} forum:transition-colors">
                    <iconify-icon icon="lucide:heart" class="forum:text-lg {{ $topic->isLikedBy(auth()->user()) ? 'forum:text-red-500' : '' }}"></iconify-icon>
                    <span>{{ $topic->likes_count }}</span>
                </button>

                {{-- Reply Count --}}
                <span class="forum:flex forum:items-center forum:gap-2 forum:text-sm forum:text-gray-500 forum:dark:text-gray-400">
                    <iconify-icon icon="lucide:message-circle" class="forum:text-lg"></iconify-icon>
                    <span>{{ $topic->replies_count }} {{ __('replies') }}</span>
                </span>
            </div>

            @if(auth()->check() && $topic->user_id === auth()->id() && $topic->is_solved)
                <button wire:click="unmarkAsSolved" class="link-secondary forum:text-sm">
                    {{ __('Unmark as solved') }}
                </button>
            @endif
        </div>
    </article>

    {{-- Replies --}}
    <div class="forum:space-y-4">
        <h2 class="section-title">
            {{ __('Replies') }} ({{ $topic->replies_count }})
        </h2>

        @forelse($replies as $reply)
            <div wire:key="reply-{{ $reply->id }}"
                 class="card forum:overflow-hidden forum:group/reply {{ $reply->is_solution ? 'forum:border-green-500 forum:dark:border-green-500' : '' }}">
                {{-- Solution Badge --}}
                @if($reply->is_solution)
                    <div class="forum:px-4 forum:py-2 forum:bg-green-50 forum:dark:bg-green-900/20 forum:border-b forum:border-green-200 forum:dark:border-green-800 forum:flex forum:items-center forum:gap-2 forum:text-green-700 forum:dark:text-green-300">
                        <iconify-icon icon="lucide:check-circle" class="forum:text-lg"></iconify-icon>
                        <span class="forum:font-medium">{{ __('Accepted Solution') }}</span>
                    </div>
                @endif

                <div class="forum:p-4">
                    <div class="forum:flex forum:items-start forum:gap-4">
                        {{-- Author Avatar --}}
                        <div class="forum:shrink-0 forum:w-10 forum:h-10 forum:rounded-full forum:bg-primary/10 forum:flex forum:items-center forum:justify-center forum:text-primary forum:font-medium">
                            {{ strtoupper(substr($reply->user->full_name, 0, 1)) }}
                        </div>

                        {{-- Content --}}
                        <div class="forum:flex-1 forum:min-w-0">
                            <div class="forum:flex forum:items-center forum:justify-between forum:gap-2">
                                <div class="forum:flex forum:items-center forum:gap-2 forum:text-sm forum:text-gray-500 forum:dark:text-gray-400">
                                    <span class="forum:font-medium forum:text-gray-900 forum:dark:text-white">{{ $reply->user->full_name }}</span>
                                    <span>&middot;</span>
                                    <span>{{ $reply->created_at->diffForHumans() }}</span>
                                    @if($reply->user_id === $topic->user_id)
                                        <span class="badge-primary">
                                            {{ __('Author') }}
                                        </span>
                                    @endif
                                    @if($reply->updated_at->gt($reply->created_at))
                                        <span class="forum:italic">{{ __('(edited)') }}</span>
                                    @endif
                                </div>

                                {{-- Reply Author Actions (visible on hover) --}}
                                @if(auth()->check() && $reply->user_id === auth()->id() && !$topic->is_locked)
                                    <div class="forum:flex forum:items-center forum:gap-2 forum:opacity-0 forum:group-hover/reply:opacity-100 forum:transition-opacity">
                                        <button wire:click="editReply({{ $reply->id }})" class="forum:p-1 forum:text-gray-500 forum:hover:text-primary forum:transition-colors" title="{{ __('Edit') }}">
                                            <iconify-icon icon="lucide:pencil" class="forum:text-sm"></iconify-icon>
                                        </button>
                                        <button wire:click="deleteReply({{ $reply->id }})" wire:confirm="{{ __('Are you sure you want to delete this reply?') }}" class="forum:p-1 forum:text-gray-500 forum:hover:text-red-600 forum:transition-colors" title="{{ __('Delete') }}">
                                            <iconify-icon icon="lucide:trash-2" class="forum:text-sm"></iconify-icon>
                                        </button>
                                    </div>
                                @endif
                            </div>

                            @if($editingReplyId === $reply->id)
                                {{-- Edit Reply Form --}}
                                <form wire:submit="updateReply" class="forum:mt-2 forum:space-y-3"
                                    x-data="{
                                        editor: null,
                                        editorId: 'editingReplyContent_{{ $reply->id }}',
                                        init() {
                                            this.$nextTick(() => {
                                                if (typeof tinymce !== 'undefined') {
                                                    this.initEditor();
                                                }
                                            });
                                        },
                                        initEditor() {
                                            const textarea = document.getElementById(this.editorId);
                                            if (!textarea || tinymce.get(this.editorId)) return;

                                            tinymce.init({
                                                selector: '#' + this.editorId,
                                                height: 200,
                                                menubar: false,
                                                plugins: 'autolink link image lists',
                                                toolbar: 'undo redo | bold italic underline | alignleft aligncenter alignright | bullist numlist | link image media | removeformat',
                                                skin: document.documentElement.classList.contains('dark') ? 'oxide-dark' : 'oxide',
                                                content_css: document.documentElement.classList.contains('dark') ? 'dark' : 'default',
                                                branding: false,
                                                promotion: false,
                                                statusbar: false,
                                                setup: (editor) => {
                                                    this.editor = editor;
                                                    editor.on('change keyup', () => {
                                                        textarea.value = editor.getContent();
                                                    });
                                                },
                                                init_instance_callback: (editor) => {
                                                    editor.setContent(textarea.value || '');
                                                    textarea.style.display = 'none';
                                                }
                                            });
                                        },
                                        destroy() {
                                            if (this.editor) {
                                                tinymce.remove(this.editor);
                                                this.editor = null;
                                            }
                                        }
                                    }"
                                    x-init="init()"
                                    x-on:submit="if(editor) { @this.set('editingReplyContent', editor.getContent(), false); }"
                                >
                                    <div wire:ignore>
                                        <textarea
                                            wire:model.defer="editingReplyContent"
                                            id="editingReplyContent_{{ $reply->id }}"
                                            rows="4"
                                            class="form-control-textarea"
                                            placeholder="{{ __('Reply content') }}"
                                        ></textarea>
                                    </div>
                                    @error('editingReplyContent')
                                        <p class="forum:mt-1 forum:text-sm forum:text-red-600 forum:dark:text-red-400">{{ $message }}</p>
                                    @enderror
                                    <div class="forum:flex forum:items-center forum:gap-2">
                                        <button type="submit" class="btn-primary btn-sm">
                                            <iconify-icon icon="lucide:check" class="forum:text-base"></iconify-icon>
                                            {{ __('Save') }}
                                        </button>
                                        <button type="button" wire:click="cancelEditReply" class="btn-secondary btn-sm" @click="destroy()">
                                            {{ __('Cancel') }}
                                        </button>
                                    </div>
                                </form>
                            @else
                                <div class="forum:mt-2 prose forum:max-w-none forum:text-gray-700 forum:dark:text-gray-300">
                                    {!! \Modules\Forum\Helpers\ForumHelper::linkify($reply->content) !!}
                                </div>
                            @endif

                            {{-- Reply Actions --}}
                            @if($editingReplyId !== $reply->id && $replyingTo !== $reply->id)
                                <div class="forum:mt-4 forum:flex forum:items-center forum:gap-4">
                                    {{-- Like --}}
                                    <button wire:click="toggleLikeReply({{ $reply->id }})" class="forum:flex forum:items-center forum:gap-1 forum:text-sm {{ $reply->isLikedBy(auth()->user()) ? 'forum:text-red-600 forum:dark:text-red-400' : 'forum:text-gray-500 forum:dark:text-gray-400 forum:hover:text-red-600 forum:dark:hover:text-red-400' }} forum:transition-colors">
                                        <iconify-icon icon="lucide:heart" class="forum:text-base {{ $reply->isLikedBy(auth()->user()) ? 'forum:text-red-500' : '' }}"></iconify-icon>
                                        <span>{{ $reply->likes_count }}</span>
                                    </button>

                                    {{-- Reply to this --}}
                                    @auth
                                        @if(!$topic->is_locked)
                                            <button wire:click="setReplyingTo({{ $reply->id }})" class="forum:flex forum:items-center forum:gap-1 forum:text-sm forum:text-gray-500 forum:dark:text-gray-400 forum:hover:text-primary forum:transition-colors">
                                                <iconify-icon icon="lucide:reply" class="forum:text-base"></iconify-icon>
                                                <span>{{ __('Reply') }}</span>
                                            </button>
                                        @endif
                                    @endauth

                                    {{-- Mark as Solution --}}
                                    @if(auth()->check() && $topic->user_id === auth()->id() && !$reply->is_solution && !$topic->is_solved)
                                        <button wire:click="markAsSolution({{ $reply->id }})" class="forum:flex forum:items-center forum:gap-1 forum:text-sm forum:text-gray-500 forum:dark:text-gray-400 forum:hover:text-green-600 forum:dark:hover:text-green-400 forum:transition-colors">
                                            <iconify-icon icon="lucide:check-circle" class="forum:text-base"></iconify-icon>
                                            <span>{{ __('Mark as solution') }}</span>
                                        </button>
                                    @endif
                                </div>
                            @endif

                            {{-- Inline Reply Form --}}
                            @if($replyingTo === $reply->id)
                                <div class="forum:mt-4 forum:pt-4 forum:border-t forum:border-gray-200 forum:dark:border-gray-700">
                                    <form wire:submit="submitReply" class="forum:space-y-3">
                                        <div class="forum:flex forum:items-center forum:gap-2 forum:text-sm forum:text-gray-600 forum:dark:text-gray-400 forum:mb-2">
                                            <iconify-icon icon="lucide:corner-down-right" class="forum:text-base"></iconify-icon>
                                            <span>{{ __('Replying to') }} <strong>{{ $reply->user->full_name }}</strong></span>
                                            <button type="button" wire:click="cancelReply" class="forum:ml-auto link-secondary forum:text-xs">
                                                {{ __('Cancel') }}
                                            </button>
                                        </div>
                                        <div>
                                            <textarea
                                                wire:model="replyContent"
                                                rows="3"
                                                placeholder="{{ __('Write your reply...') }}"
                                                class="form-control-textarea"
                                                x-init="$el.focus()"
                                            ></textarea>
                                            @error('replyContent')
                                                <p class="forum:mt-1 forum:text-sm forum:text-red-600 forum:dark:text-red-400">{{ $message }}</p>
                                            @enderror
                                        </div>
                                        <div class="forum:flex forum:justify-end">
                                            <button type="submit" class="btn-primary btn-sm">
                                                <iconify-icon icon="lucide:send" class="forum:text-base"></iconify-icon>
                                                {{ __('Post Reply') }}
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            @endif
                        </div>
                    </div>

                    {{-- Nested Replies --}}
                    @if($reply->children->count() > 0)
                        <div class="forum:mt-4 forum:ml-14 forum:space-y-4 forum:border-l-2 forum:border-gray-200 forum:dark:border-gray-700 forum:pl-4">
                            @foreach($reply->children as $child)
                                <div wire:key="reply-child-{{ $child->id }}" class="forum:flex forum:items-start forum:gap-3 forum:group/child">
                                    <div class="forum:shrink-0 forum:w-8 forum:h-8 forum:rounded-full forum:bg-gray-100 forum:dark:bg-gray-700 forum:flex forum:items-center forum:justify-center forum:text-gray-600 forum:dark:text-gray-400 forum:text-sm forum:font-medium">
                                        {{ strtoupper(substr($child->user->full_name, 0, 1)) }}
                                    </div>
                                    <div class="forum:flex-1 forum:min-w-0">
                                        <div class="forum:flex forum:items-center forum:justify-between forum:gap-2">
                                            <div class="forum:flex forum:items-center forum:gap-2 forum:text-sm forum:text-gray-500 forum:dark:text-gray-400">
                                                <span class="forum:font-medium forum:text-gray-900 forum:dark:text-white">{{ $child->user->full_name }}</span>
                                                <span>&middot;</span>
                                                <span>{{ $child->created_at->diffForHumans() }}</span>
                                                @if($child->updated_at->gt($child->created_at))
                                                    <span class="forum:italic">{{ __('(edited)') }}</span>
                                                @endif
                                            </div>

                                            {{-- Child Reply Author Actions (visible on hover) --}}
                                            @if(auth()->check() && $child->user_id === auth()->id() && !$topic->is_locked)
                                                <div class="forum:flex forum:items-center forum:gap-1 forum:opacity-0 forum:group-hover/child:opacity-100 forum:transition-opacity">
                                                    <button wire:click="editReply({{ $child->id }})" class="forum:p-1 forum:text-gray-500 forum:hover:text-primary forum:transition-colors" title="{{ __('Edit') }}">
                                                        <iconify-icon icon="lucide:pencil" class="forum:text-xs"></iconify-icon>
                                                    </button>
                                                    <button wire:click="deleteReply({{ $child->id }})" wire:confirm="{{ __('Are you sure you want to delete this reply?') }}" class="forum:p-1 forum:text-gray-500 forum:hover:text-red-600 forum:transition-colors" title="{{ __('Delete') }}">
                                                        <iconify-icon icon="lucide:trash-2" class="forum:text-xs"></iconify-icon>
                                                    </button>
                                                </div>
                                            @endif
                                        </div>

                                        @if($editingReplyId === $child->id)
                                            {{-- Edit Child Reply Form --}}
                                            <form wire:submit="updateReply" class="forum:mt-2 forum:space-y-2"
                                                x-data="{
                                                    editor: null,
                                                    editorId: 'editingChildReplyContent_{{ $child->id }}',
                                                    init() {
                                                        this.$nextTick(() => {
                                                            if (typeof tinymce !== 'undefined') {
                                                                this.initEditor();
                                                            }
                                                        });
                                                    },
                                                    initEditor() {
                                                        const textarea = document.getElementById(this.editorId);
                                                        if (!textarea || tinymce.get(this.editorId)) return;

                                                        tinymce.init({
                                                            selector: '#' + this.editorId,
                                                            height: 150,
                                                            menubar: false,
                                                            plugins: 'autolink link image lists',
                                                            toolbar: 'undo redo | bold italic underline | bullist numlist | link | removeformat',
                                                            skin: document.documentElement.classList.contains('dark') ? 'oxide-dark' : 'oxide',
                                                            content_css: document.documentElement.classList.contains('dark') ? 'dark' : 'default',
                                                            branding: false,
                                                            promotion: false,
                                                            statusbar: false,
                                                            setup: (editor) => {
                                                                this.editor = editor;
                                                                editor.on('change keyup', () => {
                                                                    textarea.value = editor.getContent();
                                                                });
                                                            },
                                                            init_instance_callback: (editor) => {
                                                                editor.setContent(textarea.value || '');
                                                                textarea.style.display = 'none';
                                                            }
                                                        });
                                                    },
                                                    destroy() {
                                                        if (this.editor) {
                                                            tinymce.remove(this.editor);
                                                            this.editor = null;
                                                        }
                                                    }
                                                }"
                                                x-init="init()"
                                                x-on:submit="if(editor) { @this.set('editingReplyContent', editor.getContent(), false); }"
                                            >
                                                <div wire:ignore>
                                                    <textarea
                                                        wire:model.defer="editingReplyContent"
                                                        id="editingChildReplyContent_{{ $child->id }}"
                                                        rows="3"
                                                        class="form-control-textarea forum:text-sm"
                                                        placeholder="{{ __('Reply content') }}"
                                                    ></textarea>
                                                </div>
                                                @error('editingReplyContent')
                                                    <p class="forum:mt-1 forum:text-xs forum:text-red-600 forum:dark:text-red-400">{{ $message }}</p>
                                                @enderror
                                                <div class="forum:flex forum:items-center forum:gap-2">
                                                    <button type="submit" class="btn-primary btn-sm forum:text-xs forum:px-2 forum:py-1">
                                                        {{ __('Save') }}
                                                    </button>
                                                    <button type="button" wire:click="cancelEditReply" class="btn-secondary btn-sm forum:text-xs forum:px-2 forum:py-1" @click="destroy()">
                                                        {{ __('Cancel') }}
                                                    </button>
                                                </div>
                                            </form>
                                        @else
                                            <div class="forum:mt-1 forum:text-gray-700 forum:dark:text-gray-300">
                                                {!! \Modules\Forum\Helpers\ForumHelper::linkify($child->content) !!}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>
        @empty
            <div class="card forum:text-center forum:py-8">
                <iconify-icon icon="lucide:message-square" class="forum:text-4xl forum:mx-auto forum:text-gray-400"></iconify-icon>
                <p class="forum:mt-3 forum:text-gray-500 forum:dark:text-gray-400">{{ __('No replies yet. Be the first to respond!') }}</p>
            </div>
        @endforelse

        {{-- Pagination --}}
        @if($replies->hasPages())
            <div class="forum:mt-4">
                {{ $replies->links() }}
            </div>
        @endif
    </div>

    {{-- Reply Form (only for new top-level replies) --}}
    @auth
        @if($topic->is_locked)
            <div class="alert alert-warning forum:mt-6">
                <iconify-icon icon="lucide:lock" class="forum:text-lg forum:shrink-0"></iconify-icon>
                <span>{{ __('This topic is locked. No new replies can be added.') }}</span>
            </div>
        @elseif(!$replyingTo)
            <div class="card forum:mt-6">
                <div class="card-body">
                    <h3 class="section-title forum:mb-4">
                        {{ __('Leave a reply') }}
                    </h3>

                    <form wire:submit="submitReply">
                        <div class="forum:mb-4" wire:ignore>
                            <textarea
                                wire:model.defer="replyContent"
                                id="replyContent"
                                rows="4"
                                placeholder="{{ __('Write your reply...') }}"
                                class="form-control-textarea"
                            ></textarea>
                            <x-text-editor editorId="replyContent" type="basic" height="200px" :customToolbar="'undo redo | bold italic underline | alignleft aligncenter alignright | bullist numlist | link image media | removeformat'" />
                        </div>
                        @error('replyContent')
                            <p class="forum:mt-1 forum:text-sm forum:text-red-600 forum:dark:text-red-400">{{ $message }}</p>
                        @enderror

                        <div class="forum:flex forum:justify-end">
                            <button type="submit" class="btn-primary">
                                <iconify-icon icon="lucide:send" class="forum:text-base"></iconify-icon>
                                {{ __('Post Reply') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        @endif
    @else
        <div class="card forum:mt-6 forum:text-center">
            <div class="card-body">
                <p class="forum:text-gray-600 forum:dark:text-gray-400">
                    {{ __('Please') }}
                    <a href="{{ route('login') }}" class="link forum:font-medium">{{ __('login') }}</a>
                    {{ __('to reply to this topic.') }}
                </p>
            </div>
        </div>
    @endauth
</div>
