<?php

use App\Models\Setting;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use Modules\Forum\Livewire\Admin\Dashboard;
use Modules\Forum\Livewire\Admin\Settings;
use Modules\Forum\Livewire\Admin\Categories\Create as CategoryCreate;
use Modules\Forum\Livewire\Admin\Categories\Edit as CategoryEdit;
use Modules\Forum\Livewire\Admin\Categories\Index as CategoryIndex;
use Modules\Forum\Livewire\Admin\Categories\Show as CategoryShow;
use Modules\Forum\Livewire\Admin\Topics\Create as TopicCreate;
use Modules\Forum\Livewire\Admin\Topics\Edit as TopicEdit;
use Modules\Forum\Livewire\Admin\Topics\Index as TopicIndex;
use Modules\Forum\Livewire\Admin\Topics\Show as TopicShow;
use Modules\Forum\Livewire\Admin\Replies\Create as ReplyCreate;
use Modules\Forum\Livewire\Admin\Replies\Edit as ReplyEdit;
use Modules\Forum\Livewire\Admin\Replies\Index as ReplyIndex;
use Modules\Forum\Livewire\Admin\Replies\Show as ReplyShow;
use Modules\Forum\Livewire\Forum\Index as ForumIndex;
use Modules\Forum\Livewire\Forum\CategoryShow as ForumCategoryShow;
use Modules\Forum\Livewire\Forum\TopicShow as ForumTopicShow;
use Modules\Forum\Livewire\Forum\CreateTopic as ForumCreateTopic;
use Modules\Forum\Livewire\Forum\Search as ForumSearch;

/*
|--------------------------------------------------------------------------
| Helper to get forum base URL (loads from DB if config not yet available)
|--------------------------------------------------------------------------
*/
$getForumBaseUrl = function (): string {
    // First try config (faster, works when settings already loaded)
    $url = config('settings.forum_base_url');
    if ($url) {
        return trim($url, '/');
    }

    // Fallback: load directly from database
    try {
        if (Schema::hasTable('settings')) {
            $setting = Setting::where('option_name', 'forum_base_url')->first();
            if ($setting) {
                return trim($setting->option_value, '/');
            }
        }
    } catch (\Exception $e) {
        // Database not available
    }

    return 'forum';
};

/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'verified'])
    ->prefix('admin/forum')
    ->as('admin.forum.')
    ->group(function () {
        Route::get('/', fn () => redirect()->route('admin.forum.dashboard'));
        Route::get('dashboard', Dashboard::class)->name('dashboard');
        Route::get('settings', Settings::class)->name('settings');

        Route::get('categories', CategoryIndex::class)->name('categories.index');
        Route::get('categories/create', CategoryCreate::class)->name('categories.create');
        Route::get('categories/{category}', CategoryShow::class)->name('categories.show');
        Route::get('categories/{category}/edit', CategoryEdit::class)->name('categories.edit');

        Route::get('topics', TopicIndex::class)->name('topics.index');
        Route::get('topics/create', TopicCreate::class)->name('topics.create');
        Route::get('topics/{topic}', TopicShow::class)->name('topics.show');
        Route::get('topics/{topic}/edit', TopicEdit::class)->name('topics.edit');

        Route::get('replies', ReplyIndex::class)->name('replies.index');
        Route::get('replies/create', ReplyCreate::class)->name('replies.create');
        Route::get('replies/{reply}', ReplyShow::class)->name('replies.show');
        Route::get('replies/{reply}/edit', ReplyEdit::class)->name('replies.edit');
    });

/*
|--------------------------------------------------------------------------
| Public Forum Routes
|--------------------------------------------------------------------------
*/
Route::prefix($getForumBaseUrl())
    ->as('forum.')
    ->group(function () {
        // Forum index - list all categories
        Route::get('/', ForumIndex::class)->name('index');

        // Search
        Route::get('search', ForumSearch::class)->name('search');

        // Create new topic (requires auth)
        Route::get('new', ForumCreateTopic::class)->name('create')->middleware('auth');
        Route::get('new/{category}', ForumCreateTopic::class)->name('create.category')->middleware('auth');

        // Category - list topics
        Route::get('{category:slug}', ForumCategoryShow::class)->name('category');

        // Topic - show topic with replies
        Route::get('{category:slug}/{topic:slug}', ForumTopicShow::class)->name('topic');
    });
