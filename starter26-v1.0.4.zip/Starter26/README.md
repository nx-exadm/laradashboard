# Starter26

Starter26 is a modern frontend starter theme for Lara Dashboard, built with Livewire, Alpine.js, and Tailwind CSS.

## Features

- **Navbar** - Responsive navigation with mobile menu and dark mode toggle
- **Home Page** - Hero section with featured and recent posts
- **About Us Page** - Team members, stats, and company values
- **Contact Us Page** - Contact form with validation
- **Posts Page** - Filterable, searchable posts grid with pagination
- **Single Post Page** - Full article view with related posts and social sharing
- **Category Page** - Browse posts by category
- **Tag Page** - Browse posts by tag
- **Search Page** - Real-time search functionality
- **Generic Page** - Support for custom static pages
- **Footer** - Links, newsletter signup, and social links
- **Responsive Design** - Mobile-first, works on all devices
- **Dark Mode** - System preference detection with manual toggle
- **Multi-language Support** - All strings use Laravel's translation system

## Technology Stack

- **Livewire 3** - Full-page components with wire:navigate for SPA-like experience
- **Alpine.js** - Lightweight JavaScript for interactivity
- **Tailwind CSS v4** - With `st26:` prefix to avoid conflicts
- **Iconify** - Modern icon library with Lucide icons

## Installation

The module is automatically loaded when enabled. Make sure to build the assets:

```bash
cd modules/starter26
npm install
npm run build
```

Or from the root directory:

```bash
npm run build --prefix modules/starter26
```

## Configuration

Edit `config/config.php` to customize:

```php
return [
    // URL prefix for routes (empty = root level)
    'route_prefix' => env('STARTER26_ROUTE_PREFIX', ''),

    'theme' => [
        'dark_mode' => true,
        'posts_per_page' => 12,
        'newsletter' => true,
    ],
];
```

## Routes

| Route | Name | Description |
|-------|------|-------------|
| `/` | `starter26.home` | Home page |
| `/about` | `starter26.about` | About page |
| `/contact` | `starter26.contact` | Contact page |
| `/posts` | `starter26.posts` | Posts listing |
| `/post/{slug}` | `starter26.post` | Single post |
| `/category/{slug}` | `starter26.category` | Category archive |
| `/tag/{slug}` | `starter26.tag` | Tag archive |
| `/search` | `starter26.search` | Search page |
| `/page/{slug}` | `starter26.page` | Generic page |

## Hooks & Filters

The theme supports WordPress-like hooks for customization:

### Filters

- `starter26_nav_items` - Customize navigation items
- `starter26_footer_links` - Customize footer links
- `starter26_social_links` - Customize social media links
- `starter26_team_members` - Customize about page team members
- `starter26_about_stats` - Customize about page statistics
- `starter26_contact_info` - Customize contact information

### Actions

- `starter26_contact_form_submitted` - Triggered when contact form is submitted

## Customization

### Tailwind CSS

All Tailwind classes use the `st26:` prefix. For example:

```html
<div class="st26:bg-white st26:p-4 st26:rounded-lg">
    Content
</div>
```

### Components

Override Blade components by publishing them:

```bash
php artisan vendor:publish --tag=starter26-module-views
```

## License

MIT License
