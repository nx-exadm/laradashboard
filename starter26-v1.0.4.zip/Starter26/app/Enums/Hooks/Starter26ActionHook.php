<?php

declare(strict_types=1);

namespace Modules\Starter26\Enums\Hooks;

enum Starter26ActionHook: string
{
    // Posts
    case POST_VIEWED = 'starter26.action.post_viewed';
    case SEARCH_PERFORMED = 'starter26.action.search_performed';

    // Page lifecycle
    case PAGE_LOADED = 'starter26.action.page_loaded';
}
