<?php

declare(strict_types=1);

namespace Modules\Starter26\Enums\Hooks;

enum Starter26FilterHook: string
{
    // Navigation
    case NAV_ITEMS = 'starter26.filter.nav_items';
    case FOOTER_LINKS = 'starter26.filter.footer_links';
    case SOCIAL_LINKS = 'starter26.filter.social_links';

    // About page
    case TEAM_MEMBERS = 'starter26.filter.team_members';
    case ABOUT_STATS = 'starter26.filter.about_stats';

    // Posts
    case POSTS_QUERY = 'starter26.filter.posts_query';
    case SINGLE_POST_RELATED = 'starter26.filter.single_post_related';

    // Layout
    case HEAD_BEFORE = 'starter26.filter.head_before';
    case HEAD_AFTER = 'starter26.filter.head_after';
    case BODY_START = 'starter26.filter.body_start';
    case BODY_END = 'starter26.filter.body_end';
    case NAVBAR_BEFORE = 'starter26.filter.navbar_before';
    case NAVBAR_AFTER = 'starter26.filter.navbar_after';
    case FOOTER_BEFORE = 'starter26.filter.footer_before';
    case FOOTER_AFTER = 'starter26.filter.footer_after';
}
