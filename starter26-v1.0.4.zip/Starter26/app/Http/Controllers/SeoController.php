<?php

declare(strict_types=1);

namespace Modules\Starter26\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Models\Term;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Schema;

/**
 * Generates robots.txt and sitemap.xml for the Starter26 frontend.
 *
 * Both endpoints are read-only, cached, and defensive about the
 * presence of core models (Post/Term) so the module keeps working
 * even if it's ever booted stand-alone or the schema changes.
 */
class SeoController extends Controller
{
    /**
     * How long to cache the generated sitemap, in seconds.
     */
    private const CACHE_TTL = 3600;

    /**
     * GET /robots.txt
     */
    public function robots(): Response
    {
        $disallow = [
            '/admin',
            '/login',
            '/register',
            '/password',
            '/email',
            '/logout',
            '/profile',
            '/livewire',
            '/api',
            '/sanctum',
            '/install',
            '/screenshot-login',
            '/demo-preview',
        ];

        $lines = ['User-agent: *'];

        foreach ($disallow as $path) {
            $lines[] = "Disallow: {$path}";
        }

        $lines[] = 'Allow: /';
        $lines[] = '';
        $lines[] = 'Sitemap: ' . url('/sitemap.xml');

        return response(implode("\n", $lines), 200)
            ->header('Content-Type', 'text/plain; charset=UTF-8');
    }

    /**
     * GET /sitemap.xml
     */
    public function sitemap(): Response
    {
        $xml = Cache::remember('starter26.sitemap.xml', self::CACHE_TTL, function () {
            return $this->buildSitemap();
        });

        return response($xml, 200)
            ->header('Content-Type', 'application/xml; charset=UTF-8');
    }

    /**
     * Build the <urlset> XML string.
     */
    private function buildSitemap(): string
    {
        $urls = collect();

        // Static, always-present routes.
        $urls->push($this->url(url('/'), now(), 'daily', '1.0'));

        if (\Illuminate\Support\Facades\Route::has('starter26.search')) {
            $urls->push($this->url(route('starter26.search'), null, 'weekly', '0.3'));
        }

        // Blog listing page (e.g. /blog).
        $blogSlug = config('settings.blog_url_prefix', 'blog');

        if (\Illuminate\Support\Facades\Route::has('starter26.posts')) {
            $urls->push($this->url(route('starter26.posts'), null, 'daily', '0.8'));
        }

        // Published posts + published generic pages.
        if (class_exists(Post::class) && Schema::hasTable((new Post())->getTable())) {
            $this->publishedPosts('post')->each(function (Post $post) use ($urls) {
                if (\Illuminate\Support\Facades\Route::has('starter26.post')) {
                    $urls->push($this->url(
                        route('starter26.post', $post->slug),
                        $post->updated_at,
                        'weekly',
                        '0.7'
                    ));
                }
            });

            $this->publishedPosts('page')->each(function (Post $page) use ($urls, $blogSlug) {
                // Skip reserved slugs already covered above.
                if (in_array($page->slug, ['home', $blogSlug], true)) {
                    return;
                }

                $urls->push($this->url(
                    url('/' . ltrim($page->slug, '/')),
                    $page->updated_at,
                    'monthly',
                    '0.6'
                ));
            });
        }

        // Category / tag archives.
        if (class_exists(Term::class) && Schema::hasTable((new Term())->getTable())) {
            $this->terms('category')->each(function (Term $term) use ($urls) {
                if (\Illuminate\Support\Facades\Route::has('starter26.category')) {
                    $urls->push($this->url(
                        route('starter26.category', $term->slug),
                        $term->updated_at ?? null,
                        'weekly',
                        '0.5'
                    ));
                }
            });

            $this->terms('tag')->each(function (Term $term) use ($urls) {
                if (\Illuminate\Support\Facades\Route::has('starter26.tag')) {
                    $urls->push($this->url(
                        route('starter26.tag', $term->slug),
                        $term->updated_at ?? null,
                        'weekly',
                        '0.4'
                    ));
                }
            });
        }

        return $this->wrap($urls);
    }

    /**
     * Published posts/pages of a given post_type, defensive about
     * columns that may not exist on a customized schema.
     */
    private function publishedPosts(string $postType): \Illuminate\Support\Collection
    {
        $table = (new Post())->getTable();

        $query = Post::query();

        if (Schema::hasColumn($table, 'post_type')) {
            $query->where('post_type', $postType);
        }

        if (Schema::hasColumn($table, 'status')) {
            $query->where('status', 'published');
        }

        return $query->get(['slug', 'updated_at']);
    }

    /**
     * Terms (categories/tags) for a given taxonomy.
     */
    private function terms(string $taxonomy): \Illuminate\Support\Collection
    {
        $table = (new Term())->getTable();

        $query = Term::query();

        if (Schema::hasColumn($table, 'taxonomy')) {
            $query->where('taxonomy', $taxonomy);
        }

        $columns = array_values(array_filter(
            ['slug', 'updated_at'],
            fn (string $column) => Schema::hasColumn($table, $column)
        ));

        return $query->get($columns ?: ['*']);
    }

    /**
     * Build a single <url> entry.
     */
    private function url(string $loc, $lastmod, string $changefreq, string $priority): string
    {
        $lastmodTag = '';

        if ($lastmod) {
            $date = $lastmod instanceof \DateTimeInterface
                ? $lastmod
                : \Illuminate\Support\Carbon::parse((string) $lastmod);

            $lastmodTag = '<lastmod>' . $date->toAtomString() . '</lastmod>';
        }

        return '<url>'
            . '<loc>' . e($loc) . '</loc>'
            . $lastmodTag
            . '<changefreq>' . $changefreq . '</changefreq>'
            . '<priority>' . $priority . '</priority>'
            . '</url>';
    }

    /**
     * Wrap a collection of <url> strings in a <urlset>, deduping by loc.
     */
    private function wrap(\Illuminate\Support\Collection $urls): string
    {
        $unique = $urls->unique(function (string $entry) {
            preg_match('#<loc>(.*?)</loc>#', $entry, $m);

            return $m[1] ?? $entry;
        });

        return '<?xml version="1.0" encoding="UTF-8"?>'
            . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
            . $unique->implode('')
            . '</urlset>';
    }
}
