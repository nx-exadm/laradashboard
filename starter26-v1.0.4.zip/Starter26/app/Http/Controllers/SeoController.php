<?php

declare(strict_types=1);

namespace Modules\Starter26\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Models\Term;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Schema;

/**
 * Generates robots.txt and sitemap.xml for the Starter26 frontend.
 *
 * Both endpoints are read-only, cached, and defensive about the
 * presence of core models (Post/Term) so the module keeps working
 * even if it's ever booted stand-alone or the schema changes.
 */
class SeoController extends Controller
{
    /**
     * How long to cache the generated sitemap, in seconds.
     */
    private const CACHE_TTL = 3600;

    /**
     * Contact address surfaced in robots.txt and the sitemap's
     * human-readable stylesheet, per common webmaster convention.
     */
    private const CONTACT_EMAIL = 'info@ncs.norielix.com';

    /**
     * Slugs that should use a non-default changefreq (e.g. pages that
     * update often, like a notices/announcements page).
     */
    private const CHANGEFREQ_OVERRIDES = [
        'notices' => 'daily',
    ];

    /**
     * Slugs that should use a non-default priority (0.0–1.0). Anything
     * not listed here falls back to the type-based default (see
     * buildSitemap()).
     */
    private const PRIORITY_OVERRIDES = [
        'notices' => '1.0',
    ];

    /**
     * GET /robots.txt
     */
    public function robots(): Response
    {
        $disallow = [
            '/admin',
            '/login',
            '/register',
            '/password',
            '/email',
            '/logout',
            '/profile',
            '/livewire',
            '/api',
            '/sanctum',
            '/install',
            '/screenshot-login',
            '/demo-preview',
        ];

        $lines = [
            '# Contact: ' . self::CONTACT_EMAIL,
            'User-agent: *',
        ];

        foreach ($disallow as $path) {
            $lines[] = "Disallow: {$path}";
        }

        $lines[] = 'Allow: /';
        $lines[] = '';
        $lines[] = 'Sitemap: ' . url('/sitemap.xml');

        return response(implode("\n", $lines), 200)
            ->header('Content-Type', 'text/plain; charset=UTF-8');
    }

    /**
     * GET /sitemap.xml
     */
    public function sitemap(): Response
    {
        $xml = Cache::remember('starter26.sitemap.xml', self::CACHE_TTL, function () {
            return $this->buildSitemap();
        });

        return response($xml, 200)
            ->header('Content-Type', 'application/xml; charset=UTF-8');
    }

    /**
     * GET /sitemap.xsl
     *
     * Human-readable rendering of the sitemap when opened directly in a
     * browser. Purely cosmetic — search engines ignore this and parse
     * the raw XML regardless.
     */
    public function sitemapStylesheet(): Response
    {
        $xsl = <<<'XSL'
<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:sm="http://www.sitemaps.org/schemas/sitemap/0.9">
<xsl:output method="html" encoding="UTF-8" indent="yes"/>
<xsl:template match="/">
<html>
<head>
<title>Norielix — Sitemap</title>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<style>
:root {
  --nx-blue: #1e40af;
  --nx-blue-dark: #1e3a8a;
  --nx-border: #e5e7eb;
  --nx-muted: #6b7280;
  --nx-bg: #f9fafb;
}
* { box-sizing: border-box; }
body {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  margin: 0;
  color: #111827;
  background: #ffffff;
}
.nx-header {
  display: flex;
  align-items: center;
  gap: 0.85rem;
  padding: 1.75rem 2rem;
  border-bottom: 1px solid var(--nx-border);
  background: linear-gradient(180deg, #f9fafb 0%, #ffffff 100%);
}
.nx-logo { width: 40px; height: 40px; flex-shrink: 0; }
.nx-title { font-size: 1.1rem; font-weight: 600; margin: 0; color: #111827; }
.nx-subtitle { margin: 0.15rem 0 0; font-size: 0.85rem; color: var(--nx-muted); }
.nx-wrap { padding: 1.5rem 2rem 2.5rem; }
.nx-stats {
  display: flex;
  gap: 0.75rem;
  margin-bottom: 1.25rem;
  flex-wrap: wrap;
}
.nx-stat {
  background: var(--nx-bg);
  border: 1px solid var(--nx-border);
  border-radius: 10px;
  padding: 0.6rem 1rem;
  font-size: 0.8rem;
  color: var(--nx-muted);
}
.nx-stat strong { color: #111827; font-size: 1rem; display: block; }
.nx-search {
  width: 100%;
  max-width: 320px;
  padding: 0.5rem 0.75rem;
  border: 1px solid var(--nx-border);
  border-radius: 8px;
  font-size: 0.85rem;
  margin-bottom: 1rem;
  display: block;
}
table { border-collapse: collapse; width: 100%; font-size: 0.85rem; }
thead th {
  text-align: left;
  padding: 0.6rem 0.85rem;
  background: var(--nx-bg);
  border-bottom: 1px solid var(--nx-border);
  font-weight: 600;
  color: #374151;
  cursor: pointer;
  user-select: none;
  white-space: nowrap;
}
thead th:hover { color: var(--nx-blue); }
tbody td {
  padding: 0.55rem 0.85rem;
  border-bottom: 1px solid var(--nx-border);
  vertical-align: top;
}
tbody tr:hover { background: #f8fafc; }
a.nx-loc { color: var(--nx-blue); text-decoration: none; word-break: break-all; }
a.nx-loc:hover { text-decoration: underline; }
.nx-badge {
  display: inline-block;
  padding: 0.1rem 0.5rem;
  border-radius: 999px;
  background: #eff6ff;
  color: var(--nx-blue-dark);
  font-size: 0.72rem;
  font-weight: 600;
  white-space: nowrap;
}
.nx-priority {
  display: inline-block;
  height: 6px;
  border-radius: 3px;
  background: var(--nx-blue);
  vertical-align: middle;
}
.nx-priority-cell { display: flex; align-items: center; gap: 0.4rem; }
.nx-footer {
  padding: 1.25rem 2rem 2rem;
  font-size: 0.75rem;
  color: var(--nx-muted);
  border-top: 1px solid var(--nx-border);
}
</style>
</head>
<body>
<div class="nx-header">
<svg class="nx-logo" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
<rect width="40" height="40" rx="8" fill="#1e40af"/>
<path d="M12 30V10L22 22V10H28V30L18 18V30H12Z" fill="white"/>
</svg>
<div>
<p class="nx-title">Norielix — XML Sitemap</p>
<p class="nx-subtitle">This file is generated automatically for search engines. <xsl:value-of select="count(sm:urlset/sm:url)"/> URLs listed below.</p>
</div>
</div>
<div class="nx-wrap">
<div class="nx-stats">
<div class="nx-stat"><strong><xsl:value-of select="count(sm:urlset/sm:url)"/></strong>Total URLs</div>
<div class="nx-stat"><strong><xsl:value-of select="count(sm:urlset/sm:url[sm:changefreq='daily'])"/></strong>Updated daily</div>
<div class="nx-stat"><strong><xsl:value-of select="count(sm:urlset/sm:url[sm:changefreq='weekly'])"/></strong>Updated weekly</div>
<div class="nx-stat"><strong><xsl:value-of select="count(sm:urlset/sm:url[sm:changefreq='monthly'])"/></strong>Updated monthly</div>
</div>
<input type="text" class="nx-search" id="nxFilter" placeholder="Filter URLs..." onkeyup="nxFilterRows()"/>
<table id="nxTable">
<thead>
<tr>
<th onclick="nxSort(0)">URL</th>
<th onclick="nxSort(1)">Last modified</th>
<th onclick="nxSort(2)">Frequency</th>
<th onclick="nxSort(3)">Priority</th>
</tr>
</thead>
<tbody>
<xsl:for-each select="sm:urlset/sm:url">
<xsl:sort select="sm:priority" order="descending"/>
<tr>
<td><a class="nx-loc" href="{sm:loc}"><xsl:value-of select="sm:loc"/></a></td>
<td><xsl:value-of select="substring(sm:lastmod, 1, 10)"/></td>
<td><span class="nx-badge"><xsl:value-of select="sm:changefreq"/></span></td>
<td>
<div class="nx-priority-cell">
<xsl:variable name="pct" select="sm:priority * 100"/>
<span class="nx-priority" style="width: {$pct}px;"></span>
<xsl:value-of select="sm:priority"/>
</div>
</td>
</tr>
</xsl:for-each>
</tbody>
</table>
</div>
<div class="nx-footer">
Generated by Norielix &#8226; Powered by Laravel &amp; Starter26 &#8226; Contact: info@ncs.norielix.com &#8226; This page is for humans; search engines read the raw XML.
</div>
<script>
function nxFilterRows() {
  var q = document.getElementById('nxFilter').value.toLowerCase();
  var rows = document.querySelectorAll('#nxTable tbody tr');
  for (var i = 0; i < rows.length; i++) {
    var text = rows[i].innerText.toLowerCase();
    rows[i].style.display = text.indexOf(q) !== -1 ? '' : 'none';
  }
}
function nxSort(col) {
  var table = document.getElementById('nxTable');
  var tbody = table.querySelector('tbody');
  var rows = Array.prototype.slice.call(tbody.querySelectorAll('tr'));
  var asc = table.getAttribute('data-sort-col') !== String(col) || table.getAttribute('data-sort-dir') !== 'asc';
  rows.sort(function (a, b) {
    var av = a.children[col].innerText.trim();
    var bv = b.children[col].innerText.trim();
    var an = parseFloat(av), bn = parseFloat(bv);
    var cmp = (!isNaN(an) && !isNaN(bn)) ? an - bn : av.localeCompare(bv);
    return asc ? cmp : -cmp;
  });
  rows.forEach(function (r) { tbody.appendChild(r); });
  table.setAttribute('data-sort-col', String(col));
  table.setAttribute('data-sort-dir', asc ? 'asc' : 'desc');
}
</script>
</body>
</html>
</xsl:template>
</xsl:stylesheet>
XSL;

        return response($xsl, 200)
            ->header('Content-Type', 'application/xml; charset=UTF-8');
    }

    /**
     * Build the <urlset> XML string.
     */
    private function buildSitemap(): string
    {
        $urls = collect();

        // Static, always-present routes.
        $urls->push($this->url(url('/'), now(), 'daily', '1.0'));

        // Note: /search and the /blog listing are intentionally excluded —
        // search results aren't unique indexable content, and the blog
        // index is reachable from the homepage/nav so it doesn't need a
        // separate sitemap entry.
        $blogSlug = config('settings.blog_url_prefix', 'blog');

        // Published posts + published generic pages.
        if (class_exists(Post::class) && Schema::hasTable((new Post())->getTable())) {
            $this->publishedPosts('post')->each(function (Post $post) use ($urls) {
                if (\Illuminate\Support\Facades\Route::has('starter26.post')) {
                    $urls->push($this->url(
                        route('starter26.post', $post->slug),
                        $post->updated_at,
                        'weekly',
                        '0.7'
                    ));
                }
            });

            $this->publishedPosts('page')->each(function (Post $page) use ($urls, $blogSlug) {
                // Skip reserved slugs already covered above.
                if (in_array($page->slug, ['home', $blogSlug], true)) {
                    return;
                }

                $urls->push($this->url(
                    url('/' . ltrim($page->slug, '/')),
                    $page->updated_at,
                    self::CHANGEFREQ_OVERRIDES[$page->slug] ?? 'monthly',
                    self::PRIORITY_OVERRIDES[$page->slug] ?? '0.6'
                ));
            });
        }

        // Category / tag archives.
        if (class_exists(Term::class) && Schema::hasTable((new Term())->getTable())) {
            $this->terms('category')->each(function (Term $term) use ($urls) {
                if (\Illuminate\Support\Facades\Route::has('starter26.category')) {
                    $urls->push($this->url(
                        route('starter26.category', $term->slug),
                        $term->updated_at ?? null,
                        'weekly',
                        '0.5'
                    ));
                }
            });

            $this->terms('tag')->each(function (Term $term) use ($urls) {
                if (\Illuminate\Support\Facades\Route::has('starter26.tag')) {
                    $urls->push($this->url(
                        route('starter26.tag', $term->slug),
                        $term->updated_at ?? null,
                        'weekly',
                        '0.4'
                    ));
                }
            });
        }

        return $this->wrap($urls);
    }

    /**
     * Published posts/pages of a given post_type, defensive about
     * columns that may not exist on a customized schema.
     */
    private function publishedPosts(string $postType): \Illuminate\Support\Collection
    {
        $table = (new Post())->getTable();

        $query = Post::query();

        if (Schema::hasColumn($table, 'post_type')) {
            $query->where('post_type', $postType);
        }

        if (Schema::hasColumn($table, 'status')) {
            $query->where('status', 'published');
        }

        return $query->get(['slug', 'updated_at']);
    }

    /**
     * Terms (categories/tags) for a given taxonomy.
     */
    private function terms(string $taxonomy): \Illuminate\Support\Collection
    {
        $table = (new Term())->getTable();

        $query = Term::query();

        if (Schema::hasColumn($table, 'taxonomy')) {
            $query->where('taxonomy', $taxonomy);
        }

        $columns = array_values(array_filter(
            ['slug', 'updated_at'],
            fn (string $column) => Schema::hasColumn($table, $column)
        ));

        return $query->get($columns ?: ['*']);
    }

    /**
     * Build a single <url> entry.
     */
    private function url(string $loc, $lastmod, string $changefreq, string $priority): string
    {
        $lastmodTag = '';

        if ($lastmod) {
            $date = $lastmod instanceof \DateTimeInterface
                ? $lastmod
                : \Illuminate\Support\Carbon::parse((string) $lastmod);

            $lastmodTag = '<lastmod>' . $date->toAtomString() . '</lastmod>';
        }

        return '<url>'
            . '<loc>' . e($loc) . '</loc>'
            . $lastmodTag
            . '<changefreq>' . $changefreq . '</changefreq>'
            . '<priority>' . $priority . '</priority>'
            . '</url>';
    }

    /**
     * Wrap a collection of <url> strings in a <urlset>, deduping by loc.
     */
    private function wrap(\Illuminate\Support\Collection $urls): string
    {
        $unique = $urls->unique(function (string $entry) {
            preg_match('#<loc>(.*?)</loc>#', $entry, $m);

            return $m[1] ?? $entry;
        });

        return '<?xml version="1.0" encoding="UTF-8"?>'
            . '<?xml-stylesheet type="text/xsl" href="' . e(url('/sitemap.xsl')) . '"?>'
            . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
            . $unique->implode('')
            . '</urlset>';
    }
}
