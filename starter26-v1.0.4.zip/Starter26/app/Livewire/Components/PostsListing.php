<?php

declare(strict_types=1);

namespace Modules\Starter26\Livewire\Components;

use App\Livewire\Components\BasePostsListing;
use Illuminate\View\View;

class PostsListing extends BasePostsListing
{
    public string $postRoute = 'starter26.post';

    public function render(): View
    {
        return view('starter26::livewire.components.posts-listing');
    }
}
