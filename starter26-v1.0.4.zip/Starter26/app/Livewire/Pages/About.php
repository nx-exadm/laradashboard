<?php

declare(strict_types=1);

namespace Modules\Starter26\Livewire\Pages;

use App\Models\Post;
use App\Support\Facades\Hook;
use Illuminate\Support\Str;
use Illuminate\View\View;
use Livewire\Component;
use Modules\Starter26\Enums\Hooks\Starter26FilterHook;

class About extends Component
{
    /**
     * Page builder version of the about page (if exists).
     */
    public ?Post $page = null;

    /**
     * Whether to use page builder content.
     */
    public bool $usePageBuilder = false;

    /**
     * Team members (can be populated from settings or database).
     */
    public array $teamMembers = [];

    /**
     * Features/stats to display.
     */
    public array $stats = [];

    /**
     * Mount the component.
     */
    public function mount(): void
    {
        // Check if there's a page builder version of the about page
        if (class_exists(Post::class)) {
            $this->page = Post::query()
                ->where('slug', 'about')
                ->where('post_type', 'page')
                ->where('status', 'published')
                ->first();

            // Use page builder if the page has design_json content
            if ($this->page && !empty($this->page->design_json)) {
                $this->usePageBuilder = true;

                return;
            }
        }

        // Default team members (fallback when not using page builder)
        $defaultTeamMembers = [
            [
                'name' => 'John Doe',
                'role' => __('Founder & CEO'),
                'image' => null,
                'bio' => __('Passionate about building great products.'),
            ],
            [
                'name' => 'Jane Smith',
                'role' => __('Lead Developer'),
                'image' => null,
                'bio' => __('Full-stack developer with 10+ years experience.'),
            ],
            [
                'name' => 'Mike Johnson',
                'role' => __('Designer'),
                'image' => null,
                'bio' => __('Creating beautiful user experiences.'),
            ],
        ];

        // Default stats
        $defaultStats = [
            ['value' => '1000+', 'label' => __('Users')],
            ['value' => '500+', 'label' => __('Articles')],
            ['value' => '50+', 'label' => __('Categories')],
            ['value' => '99%', 'label' => __('Satisfaction')],
        ];

        // Apply filters
        $this->teamMembers = Hook::applyFilters(Starter26FilterHook::TEAM_MEMBERS, $defaultTeamMembers);
        $this->stats = Hook::applyFilters(Starter26FilterHook::ABOUT_STATS, $defaultStats);
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View
    {
        // If using page builder, render the page builder version
        if ($this->usePageBuilder && $this->page) {
            return view('starter26::livewire.pages.about-builder', [
                'page' => $this->page,
            ])->layout('starter26::layouts.app', [
                'title' => $this->page->title . ' - ' . config('app.name'),
                'description' => Str::limit(strip_tags($this->page->content), 160),
            ]);
        }

        return view('starter26::livewire.pages.about')
            ->layout('starter26::layouts.app', [
                'title' => __('About Us') . ' - ' . config('app.name'),
                'description' => __('Learn more about our team and mission.'),
            ]);
    }
}
