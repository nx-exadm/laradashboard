<?php

declare(strict_types=1);

namespace Modules\Starter26\Livewire\Pages;

use App\Livewire\Pages\BaseTaxonomyArchive;
use App\Models\Term;
use Illuminate\View\View;

class Category extends BaseTaxonomyArchive
{
    protected string $taxonomy = 'category';

    /**
     * Public alias so the view can use $category->name etc.
     */
    public ?Term $category = null;

    public function mount(string $slug): void
    {
        parent::mount($slug);
        $this->category = $this->term;
    }

    public function render(): View
    {
        return $this->renderWithLayout(
            'starter26::livewire.pages.category',
            $this->seo()->forTerm($this->term, 'category')
        );
    }
}
