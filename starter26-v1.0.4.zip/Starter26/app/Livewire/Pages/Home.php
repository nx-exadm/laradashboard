<?php

declare(strict_types=1);

namespace Modules\Starter26\Livewire\Pages;

use App\Livewire\Pages\BaseHomePage;
use Illuminate\View\View;

class Home extends BaseHomePage
{
    public function render(): View
    {
        return $this->renderWithLayout(
            'starter26::livewire.pages.home',
            $this->seo()->forHomepage($this->page)
        );
    }
}
