<?php

declare(strict_types=1);

namespace Modules\Starter26\Livewire\Pages;

use App\Livewire\Pages\BaseContentPage;
use Illuminate\View\View;

class Page extends BaseContentPage
{
    public function render(): View
    {
        return $this->renderWithLayout(
            'starter26::livewire.pages.page',
            $this->seo()->forPage($this->page)
        );
    }
}
