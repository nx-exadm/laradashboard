<?php

declare(strict_types=1);

namespace Modules\Starter26\Livewire\Pages;

use App\Livewire\Pages\BasePostsArchive;
use Illuminate\View\View;

class Posts extends BasePostsArchive
{
    public function render(): View
    {
        return $this->renderWithLayout(
            'starter26::livewire.pages.posts',
            $this->seo()->forBlogListing($this->blogPage)
        );
    }
}
