<?php

declare(strict_types=1);

namespace Modules\Starter26\Livewire\Pages;

use App\Livewire\Pages\BaseSearchPage;
use Illuminate\View\View;

class Search extends BaseSearchPage
{
    public function render(): View
    {
        return $this->renderWithLayout(
            'starter26::livewire.pages.search',
            $this->seo()->forSearch($this->query)
        );
    }
}
