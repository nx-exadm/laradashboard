<?php

declare(strict_types=1);

namespace Modules\Starter26\Livewire\Pages;

use App\Livewire\Pages\BaseSinglePost;
use Illuminate\View\View;

class SinglePost extends BaseSinglePost
{
    public function render(): View
    {
        return $this->renderWithLayout(
            'starter26::livewire.pages.single-post',
            $this->seo()->forPost($this->post),
            [
                'relatedPosts' => $this->relatedPosts,
                'previousPost' => $this->previousPost,
                'nextPost' => $this->nextPost,
            ]
        );
    }
}
