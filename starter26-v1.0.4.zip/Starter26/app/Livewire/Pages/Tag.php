<?php

declare(strict_types=1);

namespace Modules\Starter26\Livewire\Pages;

use App\Livewire\Pages\BaseTaxonomyArchive;
use App\Models\Term;
use Illuminate\View\View;

class Tag extends BaseTaxonomyArchive
{
    protected string $taxonomy = 'tag';

    /**
     * Public alias so the view can use $tag->name etc.
     */
    public ?Term $tag = null;

    public function mount(string $slug): void
    {
        parent::mount($slug);
        $this->tag = $this->term;
    }

    public function render(): View
    {
        return $this->renderWithLayout(
            'starter26::livewire.pages.tag',
            $this->seo()->forTerm($this->term, 'tag')
        );
    }
}
