<?php

namespace Modules\Starter26\Providers;

use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class RouteServiceProvider extends ServiceProvider
{
    protected string $name = 'Starter26';

    /**
     * Called before routes are registered.
     *
     * Register any model bindings or pattern based filters.
     */
    public function boot(): void
    {
        parent::boot();
    }

    /**
     * Define the routes for the application.
     */
    public function map(): void
    {
        $this->mapApiRoutes();

        // IMPORTANT: web routes are ALWAYS registered so that route names
        // like 'starter26.home' exist for URL generation (route(), navbar,
        // footer, menu seeders, etc.) no matter what config('settings.*')
        // resolves to at the moment routes are cached/booted.
        //
        // Previously this was gated by `if ($this->isActiveTheme())`, which
        // meant the entire route group could silently vanish if
        // `php artisan route:cache` ran before migrations/settings were
        // ready (e.g. on a fresh deploy) -> RouteNotFoundException even
        // though the very same request had just matched a sibling route
        // like 'starter26.search'. The "only serve this theme's frontend
        // when it's active" rule is now enforced per-request inside the
        // route group instead, which is evaluated fresh on every request
        // and is immune to route-cache timing.
        $this->mapWebRoutes();
    }

    /**
     * Check if this theme module is the active theme.
     */
    protected function isActiveTheme(): bool
    {
        $activeTheme = config('settings.active_theme', '');

        // If no active theme is set, allow loading (backwards compatibility)
        if (empty($activeTheme)) {
            return true;
        }

        return strtolower($activeTheme) === 'starter26';
    }

    /**
     * Define the "web" routes for the application.
     *
     * These routes all receive session state, CSRF protection, etc.
     * Route names are always available; visiting them when this theme is
     * not the active theme returns 404 at request time instead of the
     * route simply not existing.
     */
    protected function mapWebRoutes(): void
    {
        Route::middleware('web')
            ->group(function () {
                Route::middleware([$this->activeThemeGuard()])
                    ->group(module_path($this->name, '/routes/web.php'));
            });
    }

    /**
     * Closure-based middleware that 404s requests when this theme isn't
     * active, checked fresh on every request (not at route-cache time).
     */
    protected function activeThemeGuard(): \Closure
    {
        return function (Request $request, \Closure $next) {
            if (! $this->isActiveTheme()) {
                throw new NotFoundHttpException;
            }

            return $next($request);
        };
    }

    /**
     * Define the "api" routes for the application.
     *
     * These routes are typically stateless.
     */
    protected function mapApiRoutes(): void
    {
        Route::middleware('api')->prefix('api')->name('api.')->group(module_path($this->name, '/routes/api.php'));
    }
}
