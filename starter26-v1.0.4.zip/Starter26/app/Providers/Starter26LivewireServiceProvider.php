<?php

namespace Modules\Starter26\Providers;

use Illuminate\Support\ServiceProvider;
use Livewire\Livewire;
use Modules\Starter26\Livewire\Components\PostsListing;
use Modules\Starter26\Livewire\Pages\Category;
use Modules\Starter26\Livewire\Pages\Home;
use Modules\Starter26\Livewire\Pages\Page;
use Modules\Starter26\Livewire\Pages\Posts;
use Modules\Starter26\Livewire\Pages\Search;
use Modules\Starter26\Livewire\Pages\SinglePost;
use Modules\Starter26\Livewire\Pages\Tag;

class Starter26LivewireServiceProvider extends ServiceProvider
{
    /**
     * Register the service provider.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        $this->registerLivewireComponents();
    }

    /**
     * Register Livewire components.
     */
    protected function registerLivewireComponents(): void
    {
        // Page components
        Livewire::component('starter26::pages.home', Home::class);
        Livewire::component('starter26::pages.posts', Posts::class);
        Livewire::component('starter26::pages.single-post', SinglePost::class);
        Livewire::component('starter26::pages.page', Page::class);
        Livewire::component('starter26::pages.category', Category::class);
        Livewire::component('starter26::pages.tag', Tag::class);
        Livewire::component('starter26::pages.search', Search::class);

        // Embeddable components
        Livewire::component('starter26::components.posts-listing', PostsListing::class);
    }
}
