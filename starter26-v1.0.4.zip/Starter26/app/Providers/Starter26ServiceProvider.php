<?php

namespace Modules\Starter26\Providers;

use App\Enums\Hooks\AdminFilterHook;
use App\Models\Menu;
use App\Models\Post;
use App\Support\Facades\Hook;
use App\Support\Facades\Theme;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;
use Nwidart\Modules\Traits\PathNamespace;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

class Starter26ServiceProvider extends ServiceProvider
{
    use PathNamespace;

    protected string $name = 'Starter26';

    protected string $nameLower = 'starter26';

    /**
     * Boot the application events.
     */
    public function boot(): void
    {
        $this->registerCommands();
        $this->registerCommandSchedules();
        $this->registerTranslations();
        $this->registerConfig();
        $this->registerViews();
        $this->loadMigrationsFrom(module_path($this->name, 'database/migrations'));

        if (function_exists('ld_add_filter')) {
            ld_add_filter(AdminFilterHook::ADMIN_SITE_ONLY, function () {
                return false;
            });
        }

        $this->registerDefaultSettings();
        $this->registerFrontendUrlFilter();
        $this->registerToolbarItems();
    }

    /**
     * Register the service provider.
     */
    public function register(): void
    {
        $this->app->register(EventServiceProvider::class);
        $this->app->register(RouteServiceProvider::class);
        $this->app->register(Starter26LivewireServiceProvider::class);
    }

    /**
     * Register default settings values.
     */
    protected function registerDefaultSettings(): void
    {
        Theme::registerDefaults([
            'blog_url_prefix' => 'blog',
            'posts_per_page' => '12',
            'footer_description' => 'A modern starter theme built with Livewire, Alpine.js, and Tailwind CSS.',
        ]);
    }

    /**
     * Register the frontend URL filter so the core Post model
     * can resolve theme-specific frontend URLs.
     */
    protected function registerFrontendUrlFilter(): void
    {
        Hook::addFilter(AdminFilterHook::POST_FRONTEND_URL, function (?string $url, Post $post) {
            return match ($post->post_type) {
                'page' => url('/' . $post->slug),
                'post' => route('starter26.post', $post->slug),
                default => $url,
            };
        }, 10, 2);
    }

    /**
     * Register toolbar items for menu editing via the core toolbar.
     */
    protected function registerToolbarItems(): void
    {
        Hook::addFilter(AdminFilterHook::FRONTEND_TOOLBAR_ITEMS, function (array $items) {
            $primaryMenu = Menu::forLocation('primary');

            if ($primaryMenu) {
                $items[] = [
                    'id' => 'edit-navbar',
                    'label' => __('Edit Navbar'),
                    'url' => route('admin.menus.builder', $primaryMenu),
                    'icon' => 'lucide:navigation',
                    'position' => 'left',
                    'priority' => 50,
                    'permission' => null,
                    'separator' => false,
                ];
            }

            $footerMenu = Menu::forLocation('footer');

            if ($footerMenu) {
                $items[] = [
                    'id' => 'edit-footer',
                    'label' => __('Edit Footer'),
                    'url' => route('admin.menus.builder', $footerMenu),
                    'icon' => 'lucide:panel-bottom',
                    'position' => 'left',
                    'priority' => 55,
                    'permission' => null,
                    'separator' => false,
                ];
            }

            return $items;
        }, 20);
    }

    /**
     * Register commands in the format of Command::class
     */
    protected function registerCommands(): void
    {
        // $this->commands([]);
    }

    /**
     * Register command Schedules.
     */
    protected function registerCommandSchedules(): void
    {
        // $this->app->booted(function () {
        //     $schedule = $this->app->make(Schedule::class);
        //     $schedule->command('inspire')->hourly();
        // });
    }

    /**
     * Register translations.
     */
    public function registerTranslations(): void
    {
        $langPath = resource_path('lang/modules/' . $this->nameLower);

        if (is_dir($langPath)) {
            $this->loadTranslationsFrom($langPath, $this->nameLower);
            $this->loadJsonTranslationsFrom($langPath);
        } else {
            $this->loadTranslationsFrom(module_path($this->name, 'lang'), $this->nameLower);
            $this->loadJsonTranslationsFrom(module_path($this->name, 'lang'));
        }
    }

    /**
     * Register config.
     */
    protected function registerConfig(): void
    {
        $configPath = module_path($this->name, config('modules.paths.generator.config.path'));

        if (is_dir($configPath)) {
            $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($configPath));

            foreach ($iterator as $file) {
                if ($file->isFile() && $file->getExtension() === 'php') {
                    $config = str_replace($configPath . DIRECTORY_SEPARATOR, '', $file->getPathname());
                    $config_key = str_replace([DIRECTORY_SEPARATOR, '.php'], ['.', ''], $config);
                    $segments = explode('.', $this->nameLower . '.' . $config_key);

                    // Remove duplicated adjacent segments
                    $normalized = [];
                    foreach ($segments as $segment) {
                        if (end($normalized) !== $segment) {
                            $normalized[] = $segment;
                        }
                    }

                    $key = ($config === 'config.php') ? $this->nameLower : implode('.', $normalized);

                    $this->publishes([$file->getPathname() => config_path($config)], 'config');
                    $this->merge_config_from($file->getPathname(), $key);
                }
            }
        }
    }

    /**
     * Merge config from the given path recursively.
     */
    protected function merge_config_from(string $path, string $key): void
    {
        $existing = config($key, []);
        $module_config = require $path;

        config([$key => array_replace_recursive($existing, $module_config)]);
    }

    /**
     * Register views.
     */
    public function registerViews(): void
    {
        $viewPath = resource_path('views/modules/' . $this->nameLower);
        $sourcePath = module_path($this->name, 'resources/views');

        $this->publishes([$sourcePath => $viewPath], ['views', $this->nameLower . '-module-views']);

        $this->loadViewsFrom(array_merge($this->getPublishableViewPaths(), [$sourcePath]), $this->nameLower);

        Blade::componentNamespace(config('modules.namespace') . '\\' . $this->name . '\\View\\Components', $this->nameLower);
    }

    /**
     * Get the services provided by the provider.
     */
    public function provides(): array
    {
        return [];
    }

    private function getPublishableViewPaths(): array
    {
        $paths = [];
        foreach (config('view.paths') as $path) {
            if (is_dir($path . '/modules/' . $this->nameLower)) {
                $paths[] = $path . '/modules/' . $this->nameLower;
            }
        }

        return $paths;
    }
}
