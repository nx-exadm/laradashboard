<?php

declare(strict_types=1);

namespace Modules\Starter26\Support;

class ContentSanitizer
{
    private static array $cache = [];

    /**
     * Classes editors commonly emit that hard-code a near-black text color.
     * Stripped so the theme's own light/dark color rules take over instead.
     */
    private static array $forcedDarkClasses = [
        'text-black',
        'text-gray-900',
        'text-gray-800',
        'text-gray-700',
        'text-neutral-900',
        'text-neutral-800',
        'text-slate-900',
        'text-slate-800',
        'text-zinc-900',
        'text-stone-900',
    ];

    /**
     * Tags whose inline "color" we never touch, because the theme
     * intentionally lets these keep an author-chosen color.
     */
    private static array $excludedTags = ['a'];

    /**
     * Strip forced text colors (inline style="color:...", legacy
     * <font color>, and hard-coded dark utility classes) from
     * admin-entered HTML so it always inherits the theme's light/dark
     * text color instead of fighting it.
     */
    public static function clean(?string $html): string
    {
        if ($html === null || trim($html) === '') {
            return '';
        }

        $key = md5($html);
        if (isset(self::$cache[$key])) {
            return self::$cache[$key];
        }

        $previous = libxml_use_internal_errors(true);

        $dom = new \DOMDocument('1.0', 'UTF-8');
        $dom->loadHTML(
            '<?xml encoding="utf-8" ?><div id="__csroot__">' . $html . '</div>',
            LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
        );

        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        $root = $dom->getElementById('__csroot__');

        if (! $root) {
            // DOM parsing failed entirely — return the original untouched
            // rather than risk mangling the content.
            return self::$cache[$key] = $html;
        }

        self::stripFontColorAttributes($dom);
        self::stripInlineTextColor($root);
        self::stripForcedColorClasses($root);

        $out = '';
        foreach (iterator_to_array($root->childNodes) as $child) {
            $out .= $dom->saveHTML($child);
        }

        return self::$cache[$key] = $out;
    }

    private static function stripFontColorAttributes(\DOMDocument $dom): void
    {
        foreach (iterator_to_array($dom->getElementsByTagName('font')) as $font) {
            /** @var \DOMElement $font */
            if ($font->hasAttribute('color')) {
                $font->removeAttribute('color');
            }
        }
    }

    private static function stripInlineTextColor(\DOMElement $root): void
    {
        $xpath = new \DOMXPath($root->ownerDocument);

        foreach ($xpath->query('.//*[@style]', $root) as $el) {
            /** @var \DOMElement $el */
            if (in_array(strtolower($el->tagName), self::$excludedTags, true)) {
                continue;
            }

            $cleaned = self::stripColorDeclaration($el->getAttribute('style'));

            if ($cleaned === '') {
                $el->removeAttribute('style');
            } else {
                $el->setAttribute('style', $cleaned);
            }
        }
    }

    private static function stripColorDeclaration(string $style): string
    {
        $kept = [];

        foreach (explode(';', $style) as $decl) {
            $decl = trim($decl);
            if ($decl === '') {
                continue;
            }

            $parts = explode(':', $decl, 2);
            $prop = strtolower(trim($parts[0] ?? ''));

            // Exact match only — this correctly leaves background-color,
            // border-color, outline-color, etc. untouched. A substring
            // match like [style*="color"] can't make this distinction,
            // which is what CSS-only fixes run into.
            if ($prop === 'color') {
                continue;
            }

            $kept[] = $decl;
        }

        return implode('; ', $kept);
    }

    private static function stripForcedColorClasses(\DOMElement $root): void
    {
        $xpath = new \DOMXPath($root->ownerDocument);

        foreach ($xpath->query('.//*[@class]', $root) as $el) {
            /** @var \DOMElement $el */
            $classes = preg_split('/\s+/', trim($el->getAttribute('class')));
            $classes = array_filter($classes, function (string $class) {
                if (in_array($class, self::$forcedDarkClasses, true)) {
                    return false;
                }

                // Arbitrary-value Tailwind text color utilities, e.g. text-[#000000]
                if (preg_match('/^text-\[.+\]$/', $class)) {
                    return false;
                }

                return true;
            });

            if (empty($classes)) {
                $el->removeAttribute('class');
            } else {
                $el->setAttribute('class', implode(' ', $classes));
            }
        }
    }
}
