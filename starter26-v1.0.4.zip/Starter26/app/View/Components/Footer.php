<?php

declare(strict_types=1);

namespace Modules\Starter26\View\Components;

use App\Support\Facades\Hook;
use App\View\Concerns\HasMenuData;
use App\View\Concerns\HasSiteIdentity;
use App\View\Concerns\HasSocialLinks;
use Illuminate\View\Component;
use Illuminate\View\View;
use Modules\Starter26\Enums\Hooks\Starter26FilterHook;

class Footer extends Component
{
    use HasMenuData;
    use HasSiteIdentity;
    use HasSocialLinks;

    public array $footerColumns;

    public array $socialLinks;

    public string $footerDescription;

    public string $copyrightText;

    public function __construct()
    {
        $this->loadSiteIdentity();

        $this->footerDescription = config(
            'settings.footer_description',
            __('A modern starter theme built with Livewire, Alpine.js, and Tailwind CSS.')
        );

        $copyrightTemplate = config(
            'settings.copyright_text',
            '© {year} ' . $this->siteName . '. ' . __('All rights reserved.')
        );
        $this->copyrightText = str_replace('{year}', date('Y'), $copyrightTemplate);

        $this->footerColumns = $this->loadFooterColumnsWithFallback();
        $this->socialLinks = $this->loadSocialLinks();
    }

    protected function loadFooterColumnsWithFallback(): array
    {
        $columns = $this->loadFooterColumns();

        if (empty($columns)) {
            $defaultFooterLinks = [
                [
                    'title' => __('Quick Links'),
                    'links' => [
                        ['label' => __('Home'), 'route' => 'starter26.home'],
                        ['label' => __('Posts'), 'route' => 'starter26.posts'],
                    ],
                    'isMenu' => false,
                ],
                [
                    'title' => __('Categories'),
                    'links' => [
                        ['label' => __('Technology'), 'url' => '/category/technology'],
                        ['label' => __('Business'), 'url' => '/category/business'],
                        ['label' => __('Lifestyle'), 'url' => '/category/lifestyle'],
                    ],
                    'isMenu' => false,
                ],
            ];

            $columns = Hook::applyFilters(Starter26FilterHook::FOOTER_LINKS, $defaultFooterLinks);
        }

        return $columns;
    }

    public function render(): View
    {
        return view('starter26::components.footer');
    }
}
