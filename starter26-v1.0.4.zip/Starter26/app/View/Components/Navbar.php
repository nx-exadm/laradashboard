<?php

declare(strict_types=1);

namespace Modules\Starter26\View\Components;

use App\Support\Facades\Hook;
use App\View\Concerns\HasMenuData;
use App\View\Concerns\HasSiteIdentity;
use Illuminate\Support\Collection;
use Illuminate\View\Component;
use Illuminate\View\View;
use Modules\Starter26\Enums\Hooks\Starter26FilterHook;

class Navbar extends Component
{
    use HasMenuData;
    use HasSiteIdentity;

    public Collection $menuItems;

    public function __construct()
    {
        $this->loadSiteIdentity();

        $this->menuItems = $this->loadMenuItems('primary');

        if ($this->menuItems->isEmpty()) {
            $defaultNavItems = [
                ['label' => __('Home'), 'route' => 'starter26.home', 'icon' => 'lucide:home'],
                ['label' => __('Posts'), 'route' => 'starter26.posts', 'icon' => 'lucide:newspaper'],
                ['label' => __('About'), 'url' => url('/about'), 'icon' => 'lucide:info'],
                ['label' => __('Admin Login'), 'url' => url('/admin'), 'icon' => 'lucide:lock'],
            ];

            $this->menuItems = collect(Hook::applyFilters(Starter26FilterHook::NAV_ITEMS, $defaultNavItems));
        }
    }

    public function render(): View
    {
        return view('starter26::components.navbar');
    }
}
