<?php

return [
    'name' => 'Starter26',

    /*
    |--------------------------------------------------------------------------
    | Route Prefix
    |--------------------------------------------------------------------------
    |
    | The URL prefix for all Starter26 frontend routes.
    | Leave empty for root-level routes (e.g., /about)
    | Set to 'blog' for prefixed routes (e.g., /blog/about)
    |
    */
    'route_prefix' => env('STARTER26_ROUTE_PREFIX', ''),

    /*
    |--------------------------------------------------------------------------
    | Theme Settings
    |--------------------------------------------------------------------------
    |
    | General theme configuration options.
    |
    */
    'theme' => [
        // Enable dark mode toggle
        'dark_mode' => true,

        // Default posts per page
        'posts_per_page' => 12,

        // Enable newsletter subscription form in footer
        'newsletter' => true,
    ],

    /*
    |--------------------------------------------------------------------------
    | SEO Settings
    |--------------------------------------------------------------------------
    |
    | Default SEO settings for the theme.
    |
    */
    'seo' => [
        'site_name' => env('APP_NAME', 'Starter26'),
        'separator' => ' - ',
    ],
];
