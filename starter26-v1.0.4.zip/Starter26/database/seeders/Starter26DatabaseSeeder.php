<?php

namespace Modules\Starter26\Database\Seeders;

use Illuminate\Database\Seeder;

class Starter26DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $this->call([
            Starter26PageSeeder::class,
            Starter26MenuSeeder::class,
            Starter26SettingsSeeder::class,
        ]);
    }
}
