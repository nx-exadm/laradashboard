<?php

namespace Modules\Starter26\Database\Seeders;

use App\Models\Menu;
use App\Services\MenuService;
use Illuminate\Database\Seeder;

class Starter26MenuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $menuService = app(MenuService::class);

        // Primary Navigation
        $primaryMenu = Menu::where('location', 'primary')->first();
        if (! $primaryMenu) {
            $primaryMenu = $menuService->createMenu([
                'name' => 'Primary Navigation',
                'location' => 'primary',
                'description' => 'Main site navigation',
                'status' => 'active',
            ]);

            $menuService->createMenuItem($primaryMenu, [
                'label' => 'Home',
                'type' => 'route',
                'target' => 'starter26.home',
                'icon' => 'lucide:home',
                'position' => 0,
            ]);

            $menuService->createMenuItem($primaryMenu, [
                'label' => 'Blog',
                'type' => 'route',
                'target' => 'starter26.posts',
                'icon' => 'lucide:newspaper',
                'position' => 1,
            ]);

            $menuService->createMenuItem($primaryMenu, [
                'label' => 'About',
                'type' => 'page',
                'target' => '/about',
                'icon' => 'lucide:info',
                'position' => 2,
            ]);

            $menuService->createMenuItem($primaryMenu, [
                'label' => 'Contact',
                'type' => 'page',
                'target' => '/contact',
                'icon' => 'lucide:mail',
                'position' => 3,
            ]);

            $menuService->createMenuItem($primaryMenu, [
                'label' => 'Admin Login',
                'type' => 'custom',
                'target' => '/admin',
                'icon' => 'lucide:lock',
                'position' => 4,
            ]);
        }

        // Footer Column 1
        $footer1 = Menu::where('location', 'footer-1')->first();
        if (! $footer1) {
            $footer1 = $menuService->createMenu([
                'name' => 'Quick Links',
                'location' => 'footer-1',
                'description' => 'Footer quick links',
                'status' => 'active',
            ]);

            $menuService->createMenuItem($footer1, [
                'label' => 'Home',
                'type' => 'route',
                'target' => 'starter26.home',
                'position' => 0,
            ]);

            $menuService->createMenuItem($footer1, [
                'label' => 'Blog',
                'type' => 'route',
                'target' => 'starter26.posts',
                'position' => 1,
            ]);

            $menuService->createMenuItem($footer1, [
                'label' => 'About',
                'type' => 'page',
                'target' => '/about',
                'position' => 2,
            ]);

            $menuService->createMenuItem($footer1, [
                'label' => 'Contact',
                'type' => 'page',
                'target' => '/contact',
                'position' => 3,
            ]);
        }

        // Footer Column 2
        $footer2 = Menu::where('location', 'footer-2')->first();
        if (! $footer2) {
            $footer2 = $menuService->createMenu([
                'name' => 'Resources',
                'location' => 'footer-2',
                'description' => 'Footer resources',
                'status' => 'active',
            ]);

            $menuService->createMenuItem($footer2, [
                'label' => 'Search',
                'type' => 'route',
                'target' => 'starter26.search',
                'position' => 0,
            ]);

            $menuService->createMenuItem($footer2, [
                'label' => 'Experimental',
                'type' => 'page',
                'target' => '/experimental',
                'position' => 1,
            ]);
        }
    }
}
