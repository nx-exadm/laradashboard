<?php

namespace Modules\Starter26\Database\Seeders;

use App\Models\Post;
use App\Services\Builder\DesignJsonRenderer;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Auth;

class Starter26PageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $userId = Auth::id() ?? 1;

        $this->seedPage($userId, 'home', 'Home', $this->getHomepageBlocks());
        $this->seedPage($userId, 'about', 'About Us', $this->getAboutPageBlocks(), 'We are a team of passionate developers and writers dedicated to sharing knowledge that helps the community build better software.');
        $this->seedPage($userId, 'blog', 'Blog', $this->getBlogPageBlocks(), 'Explore our collection of articles, tutorials, and stories crafted to help you build better software.');
        $this->seedPage($userId, 'contact', 'Contact Us', $this->getContactPageBlocks(), 'Have a question, suggestion, or just want to say hello? We would love to hear from you.');
        $this->seedPage($userId, 'experimental', 'Experimental Page', $this->getExperimentalPageBlocks(), 'A showcase of LaraDashboard page builder capabilities with all block types.', ['width' => '100%', 'contentPadding' => '0px', 'contentMargin' => '0px']);
    }

    /**
     * Seed a page with proper editor-compatible format.
     */
    protected function seedPage(int $userId, string $slug, string $title, array $blocks, ?string $excerpt = null, array $canvasOverrides = []): void
    {
        $existing = Post::where('slug', $slug)->where('post_type', 'page')->first();
        if ($existing) {
            return;
        }

        $designJson = [
            'blocks' => $blocks,
            'canvasSettings' => array_merge([
                'width' => '100%',
                'maxWidth' => '1280px',
                'backgroundColor' => '#ffffff',
                'textColor' => '#1f2937',
                'fontSize' => '16px',
                'lineHeight' => '1.6',
                'contentPadding' => '0px',
                'fontFamily' => 'system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif',
            ], $canvasOverrides),
            'version' => 1,
        ];

        // Generate content HTML from blocks
        $content = app(DesignJsonRenderer::class)->render($blocks, 'page');

        Post::create([
            'user_id' => $userId,
            'post_type' => 'page',
            'title' => $title,
            'slug' => $slug,
            'excerpt' => $excerpt,
            'content' => $content,
            'design_json' => $designJson,
            'status' => 'published',
            'published_at' => now(),
        ]);
    }

    /**
     * Generate a unique block ID matching editor format.
     */
    protected static function blockId(): string
    {
        return 'block_' . substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'), 0, 8);
    }

    /**
     * Dark gradient hero section reused across all pages.
     */
    protected function heroSection(string $heading, string $subtitle, array $extraChildren = []): array
    {
        $children = [
            [
                'id' => self::blockId(),
                'type' => 'heading',
                'props' => [
                    'text' => $heading,
                    'level' => 'h1',
                    'align' => 'center',
                    'color' => '#ffffff',
                    'fontSize' => '48px',
                    'fontWeight' => 'bold',
                    'lineHeight' => '1.1',
                    'layoutStyles' => ['margin' => ['bottom' => '20px']],
                ],
            ],
            [
                'id' => self::blockId(),
                'type' => 'text',
                'props' => [
                    'content' => $subtitle,
                    'align' => 'center',
                    'color' => '#94a3b8',
                    'fontSize' => '20px',
                    'lineHeight' => '1.7',
                ],
            ],
            ...$extraChildren,
        ];

        return [
            'id' => self::blockId(),
            'type' => 'section',
            'props' => [
                'fullWidth' => true,
                'contentAlign' => 'center',
                'backgroundType' => 'gradient',
                'backgroundColor' => '#0f172a',
                'gradientFrom' => '#0f172a',
                'gradientTo' => '#1e3a5f',
                'gradientDirection' => 'to-br',
                'containerMaxWidth' => '1280px',
                'layoutStyles' => [
                    'padding' => ['top' => '80px', 'left' => '24px', 'right' => '24px', 'bottom' => '80px'],
                ],
                'children' => [$children],
            ],
        ];
    }

    /**
     * CTA gradient section reused across pages.
     */
    protected function ctaSection(string $heading, string $subtitle, string $buttonText, string $buttonUrl): array
    {
        return [
            'id' => self::blockId(),
            'type' => 'section',
            'props' => [
                'fullWidth' => true,
                'contentAlign' => 'center',
                'backgroundType' => 'gradient',
                'gradientFrom' => '#1e40af',
                'gradientTo' => '#7c3aed',
                'gradientDirection' => 'to-r',
                'containerMaxWidth' => '1280px',
                'layoutStyles' => [
                    'padding' => ['top' => '64px', 'left' => '24px', 'right' => '24px', 'bottom' => '64px'],
                ],
                'children' => [[
                    [
                        'id' => self::blockId(),
                        'type' => 'heading',
                        'props' => [
                            'text' => $heading,
                            'level' => 'h2',
                            'align' => 'center',
                            'color' => '#ffffff',
                            'fontSize' => '32px',
                            'fontWeight' => 'bold',
                            'layoutStyles' => ['margin' => ['bottom' => '16px']],
                        ],
                    ],
                    [
                        'id' => self::blockId(),
                        'type' => 'text',
                        'props' => [
                            'content' => $subtitle,
                            'align' => 'center',
                            'color' => '#c7d2fe',
                            'fontSize' => '18px',
                            'lineHeight' => '1.6',
                            'layoutStyles' => ['margin' => ['bottom' => '28px']],
                        ],
                    ],
                    [
                        'id' => self::blockId(),
                        'type' => 'button',
                        'props' => [
                            'text' => $buttonText,
                            'link' => $buttonUrl,
                            'align' => 'center',
                            'fontSize' => '17px',
                            'textColor' => '#1e40af',
                            'fontWeight' => '600',
                            'borderRadius' => '8px',
                            'backgroundColor' => '#ffffff',
                            'layoutStyles' => [
                                'padding' => ['top' => '14px', 'left' => '32px', 'right' => '32px', 'bottom' => '14px'],
                            ],
                        ],
                    ],
                ]],
            ],
        ];
    }

    /**
     * Get homepage block structure.
     */
    protected function getHomepageBlocks(): array
    {
        return [
            // Hero with CTA button
            $this->heroSection(
                'Build Something Amazing',
                'We share insights, tutorials, and stories to help developers and creators build better products. Join thousands of readers who trust our content.',
                [
                    [
                        'id' => self::blockId(),
                        'type' => 'button',
                        'props' => [
                            'text' => 'Explore Articles',
                            'link' => '/blog',
                            'align' => 'center',
                            'fontSize' => '17px',
                            'textColor' => '#ffffff',
                            'fontWeight' => '600',
                            'borderRadius' => '8px',
                            'backgroundColor' => '#3b82f6',
                            'layoutStyles' => [
                                'margin' => ['top' => '24px'],
                                'padding' => ['top' => '14px', 'left' => '32px', 'right' => '32px', 'bottom' => '14px'],
                            ],
                        ],
                    ],
                ]
            ),
            // Stats
            [
                'id' => self::blockId(),
                'type' => 'section',
                'props' => [
                    'fullWidth' => true,
                    'contentAlign' => 'center',
                    'backgroundType' => 'solid',
                    'backgroundColor' => '#ffffff',
                    'containerMaxWidth' => '1280px',
                    'layoutStyles' => [
                        'padding' => ['top' => '48px', 'left' => '24px', 'right' => '24px', 'bottom' => '48px'],
                    ],
                    'children' => [[
                        [
                            'id' => self::blockId(),
                            'type' => 'columns',
                            'props' => [
                                'columns' => 4,
                                'gap' => '24px',
                                'verticalAlign' => 'center',
                                'children' => [
                                    [['id' => self::blockId(), 'type' => 'stats-item', 'props' => ['value' => '50', 'suffix' => '+', 'label' => 'Articles Published', 'valueColor' => '#3b82f6', 'valueSize' => '42px', 'labelColor' => '#64748b', 'align' => 'center']]],
                                    [['id' => self::blockId(), 'type' => 'stats-item', 'props' => ['value' => '10K', 'suffix' => '+', 'label' => 'Monthly Readers', 'valueColor' => '#8b5cf6', 'valueSize' => '42px', 'labelColor' => '#64748b', 'align' => 'center']]],
                                    [['id' => self::blockId(), 'type' => 'stats-item', 'props' => ['value' => '5K', 'suffix' => '+', 'label' => 'Community Members', 'valueColor' => '#10b981', 'valueSize' => '42px', 'labelColor' => '#64748b', 'align' => 'center']]],
                                    [['id' => self::blockId(), 'type' => 'stats-item', 'props' => ['value' => '99', 'suffix' => '%', 'label' => 'Satisfaction Rate', 'valueColor' => '#f59e0b', 'valueSize' => '42px', 'labelColor' => '#64748b', 'align' => 'center']]],
                                ],
                            ],
                        ],
                    ]],
                ],
            ],
            // Features
            [
                'id' => self::blockId(),
                'type' => 'section',
                'props' => [
                    'fullWidth' => true,
                    'contentAlign' => 'center',
                    'backgroundType' => 'solid',
                    'backgroundColor' => '#f8fafc',
                    'containerMaxWidth' => '1280px',
                    'layoutStyles' => [
                        'padding' => ['top' => '72px', 'left' => '24px', 'right' => '24px', 'bottom' => '72px'],
                    ],
                    'children' => [[
                        ['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'Why Read Our Blog?', 'level' => 'h2', 'align' => 'center', 'color' => '#0f172a', 'fontSize' => '36px', 'fontWeight' => 'bold', 'layoutStyles' => ['margin' => ['bottom' => '12px']]]],
                        ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => 'Quality content that helps you grow as a developer and build better software.', 'align' => 'center', 'color' => '#64748b', 'fontSize' => '18px', 'lineHeight' => '1.6', 'layoutStyles' => ['margin' => ['bottom' => '48px']]]],
                        [
                            'id' => self::blockId(),
                            'type' => 'columns',
                            'props' => [
                                'columns' => 3,
                                'gap' => '32px',
                                'verticalAlign' => 'start',
                                'children' => [
                                    [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:code-2', 'iconSize' => '28px', 'iconColor' => '#3b82f6', 'iconBackgroundColor' => '#dbeafe', 'iconBackgroundShape' => 'rounded', 'title' => 'In-Depth Tutorials', 'titleColor' => '#0f172a', 'description' => 'Step-by-step guides covering modern frameworks, best practices, and real-world patterns you can apply today.', 'descriptionColor' => '#64748b', 'align' => 'center']]],
                                    [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:lightbulb', 'iconSize' => '28px', 'iconColor' => '#8b5cf6', 'iconBackgroundColor' => '#ede9fe', 'iconBackgroundShape' => 'rounded', 'title' => 'Expert Insights', 'titleColor' => '#0f172a', 'description' => 'Perspectives from experienced developers on architecture decisions, tooling choices, and career growth.', 'descriptionColor' => '#64748b', 'align' => 'center']]],
                                    [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:users', 'iconSize' => '28px', 'iconColor' => '#10b981', 'iconBackgroundColor' => '#d1fae5', 'iconBackgroundShape' => 'rounded', 'title' => 'Community Driven', 'titleColor' => '#0f172a', 'description' => 'Content shaped by what our community needs. We listen, learn, and deliver articles that matter to you.', 'descriptionColor' => '#64748b', 'align' => 'center']]],
                                ],
                            ],
                        ],
                    ]],
                ],
            ],
            // Services / What We Do
            [
                'id' => self::blockId(),
                'type' => 'section',
                'props' => [
                    'fullWidth' => true,
                    'contentAlign' => 'center',
                    'backgroundType' => 'solid',
                    'backgroundColor' => '#ffffff',
                    'containerMaxWidth' => '1280px',
                    'layoutStyles' => [
                        'padding' => ['top' => '72px', 'left' => '24px', 'right' => '24px', 'bottom' => '72px'],
                    ],
                    'children' => [[
                        ['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'What We Do', 'level' => 'h2', 'align' => 'center', 'color' => '#0f172a', 'fontSize' => '36px', 'fontWeight' => 'bold', 'layoutStyles' => ['margin' => ['bottom' => '12px']]]],
                        ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => 'We help developers and teams build better software through practical content and tools.', 'align' => 'center', 'color' => '#64748b', 'fontSize' => '18px', 'lineHeight' => '1.6', 'layoutStyles' => ['margin' => ['bottom' => '48px']]]],
                        [
                            'id' => self::blockId(),
                            'type' => 'columns',
                            'props' => [
                                'columns' => 4,
                                'gap' => '24px',
                                'verticalAlign' => 'start',
                                'children' => [
                                    [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:book-open', 'iconSize' => '28px', 'iconColor' => '#3b82f6', 'iconBackgroundColor' => '#dbeafe', 'iconBackgroundShape' => 'rounded', 'title' => 'Technical Writing', 'titleColor' => '#0f172a', 'description' => 'In-depth articles and tutorials on modern web development frameworks and tools.', 'descriptionColor' => '#64748b', 'align' => 'center']]],
                                    [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:package', 'iconSize' => '28px', 'iconColor' => '#8b5cf6', 'iconBackgroundColor' => '#ede9fe', 'iconBackgroundShape' => 'rounded', 'title' => 'Open Source', 'titleColor' => '#0f172a', 'description' => 'Free tools, packages, and starter kits to accelerate your development workflow.', 'descriptionColor' => '#64748b', 'align' => 'center']]],
                                    [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:graduation-cap', 'iconSize' => '28px', 'iconColor' => '#10b981', 'iconBackgroundColor' => '#d1fae5', 'iconBackgroundShape' => 'rounded', 'title' => 'Learning Paths', 'titleColor' => '#0f172a', 'description' => 'Structured guides from beginner to advanced, covering full-stack development topics.', 'descriptionColor' => '#64748b', 'align' => 'center']]],
                                    [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:headphones', 'iconSize' => '28px', 'iconColor' => '#f59e0b', 'iconBackgroundColor' => '#fef3c7', 'iconBackgroundShape' => 'rounded', 'title' => 'Community Support', 'titleColor' => '#0f172a', 'description' => 'Active community forum where you can ask questions and share knowledge.', 'descriptionColor' => '#64748b', 'align' => 'center']]],
                                ],
                            ],
                        ],
                    ]],
                ],
            ],
            // About Us snippet
            [
                'id' => self::blockId(),
                'type' => 'section',
                'props' => [
                    'fullWidth' => true,
                    'contentAlign' => 'center',
                    'backgroundType' => 'solid',
                    'backgroundColor' => '#f8fafc',
                    'containerMaxWidth' => '900px',
                    'layoutStyles' => [
                        'padding' => ['top' => '72px', 'left' => '24px', 'right' => '24px', 'bottom' => '72px'],
                    ],
                    'children' => [[
                        ['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'About Us', 'level' => 'h2', 'align' => 'center', 'color' => '#0f172a', 'fontSize' => '36px', 'fontWeight' => 'bold', 'layoutStyles' => ['margin' => ['bottom' => '20px']]]],
                        ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => 'We are a small team of developers and writers who believe great documentation and tutorials make the difference between a good developer and a great one. Since 2020, we have been crafting content that cuts through the noise and delivers real, actionable knowledge.', 'align' => 'center', 'color' => '#475569', 'fontSize' => '17px', 'lineHeight' => '1.8', 'layoutStyles' => ['margin' => ['bottom' => '24px']]]],
                        [
                            'id' => self::blockId(),
                            'type' => 'button',
                            'props' => [
                                'text' => 'Learn More About Us',
                                'link' => '/about',
                                'align' => 'center',
                                'fontSize' => '16px',
                                'textColor' => '#ffffff',
                                'fontWeight' => '600',
                                'borderRadius' => '8px',
                                'backgroundColor' => '#3b82f6',
                                'layoutStyles' => [
                                    'padding' => ['top' => '12px', 'left' => '28px', 'right' => '28px', 'bottom' => '12px'],
                                ],
                            ],
                        ],
                    ]],
                ],
            ],
            // Latest Posts
            [
                'id' => self::blockId(),
                'type' => 'latest-posts',
                'props' => [
                    'layout' => 'grid',
                    'columns' => 3,
                    'showDate' => true,
                    'postRoute' => 'starter26.post',
                    'showImage' => true,
                    'postsCount' => 6,
                    'showAuthor' => false,
                    'headingText' => 'Latest Articles',
                    'showExcerpt' => true,
                    'layoutStyles' => [
                        'padding' => ['top' => '64px', 'left' => '24px', 'right' => '24px', 'bottom' => '64px'],
                    ],
                ],
            ],
            // Testimonials
            [
                'id' => self::blockId(),
                'type' => 'section',
                'props' => [
                    'fullWidth' => true,
                    'contentAlign' => 'center',
                    'backgroundType' => 'solid',
                    'backgroundColor' => '#f8fafc',
                    'containerMaxWidth' => '1280px',
                    'layoutStyles' => [
                        'padding' => ['top' => '72px', 'left' => '24px', 'right' => '24px', 'bottom' => '72px'],
                    ],
                    'children' => [[
                        ['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'What Our Readers Say', 'level' => 'h2', 'align' => 'center', 'color' => '#0f172a', 'fontSize' => '36px', 'fontWeight' => 'bold', 'layoutStyles' => ['margin' => ['bottom' => '12px']]]],
                        ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => 'Trusted by thousands of developers around the world.', 'align' => 'center', 'color' => '#64748b', 'fontSize' => '18px', 'lineHeight' => '1.6', 'layoutStyles' => ['margin' => ['bottom' => '48px']]]],
                        [
                            'id' => self::blockId(),
                            'type' => 'columns',
                            'props' => [
                                'columns' => 3,
                                'gap' => '24px',
                                'verticalAlign' => 'start',
                                'children' => [
                                    [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:quote', 'iconSize' => '24px', 'iconColor' => '#3b82f6', 'iconBackgroundColor' => '#dbeafe', 'iconBackgroundShape' => 'rounded', 'title' => 'Sarah Chen', 'titleColor' => '#0f172a', 'titleSize' => '16px', 'description' => '"The tutorials here are incredibly thorough. I went from struggling with Laravel to building production apps in just a few months. Highly recommended!"', 'descriptionColor' => '#475569', 'descriptionSize' => '15px', 'align' => 'left', 'layoutStyles' => ['background' => ['color' => '#ffffff'], 'padding' => ['top' => '24px', 'left' => '24px', 'right' => '24px', 'bottom' => '24px'], 'border' => ['radius' => ['topLeft' => '12px', 'topRight' => '12px', 'bottomLeft' => '12px', 'bottomRight' => '12px']]]]]],
                                    [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:quote', 'iconSize' => '24px', 'iconColor' => '#8b5cf6', 'iconBackgroundColor' => '#ede9fe', 'iconBackgroundShape' => 'rounded', 'title' => 'Marcus Johnson', 'titleColor' => '#0f172a', 'titleSize' => '16px', 'description' => '"Finally, a tech blog that does not just scratch the surface. The architecture articles helped me redesign our entire backend. Our team performance improved significantly."', 'descriptionColor' => '#475569', 'descriptionSize' => '15px', 'align' => 'left', 'layoutStyles' => ['background' => ['color' => '#ffffff'], 'padding' => ['top' => '24px', 'left' => '24px', 'right' => '24px', 'bottom' => '24px'], 'border' => ['radius' => ['topLeft' => '12px', 'topRight' => '12px', 'bottomLeft' => '12px', 'bottomRight' => '12px']]]]]],
                                    [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:quote', 'iconSize' => '24px', 'iconColor' => '#10b981', 'iconBackgroundColor' => '#d1fae5', 'iconBackgroundShape' => 'rounded', 'title' => 'Priya Patel', 'titleColor' => '#0f172a', 'titleSize' => '16px', 'description' => '"I subscribe to a dozen dev newsletters, but this is the only one I read every single issue. The quality is consistently excellent and the insights are always practical."', 'descriptionColor' => '#475569', 'descriptionSize' => '15px', 'align' => 'left', 'layoutStyles' => ['background' => ['color' => '#ffffff'], 'padding' => ['top' => '24px', 'left' => '24px', 'right' => '24px', 'bottom' => '24px'], 'border' => ['radius' => ['topLeft' => '12px', 'topRight' => '12px', 'bottomLeft' => '12px', 'bottomRight' => '12px']]]]]],
                                ],
                            ],
                        ],
                    ]],
                ],
            ],
            // FAQ
            [
                'id' => self::blockId(),
                'type' => 'section',
                'props' => [
                    'fullWidth' => true,
                    'contentAlign' => 'center',
                    'backgroundType' => 'solid',
                    'backgroundColor' => '#ffffff',
                    'containerMaxWidth' => '800px',
                    'layoutStyles' => [
                        'padding' => ['top' => '72px', 'left' => '24px', 'right' => '24px', 'bottom' => '72px'],
                    ],
                    'children' => [[
                        ['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'Frequently Asked Questions', 'level' => 'h2', 'align' => 'center', 'color' => '#0f172a', 'fontSize' => '32px', 'fontWeight' => 'bold', 'layoutStyles' => ['margin' => ['bottom' => '40px']]]],
                        ['id' => self::blockId(), 'type' => 'accordion', 'props' => [
                            'items' => [
                                ['title' => 'Is this blog free to read?', 'content' => 'Yes! All our articles and tutorials are completely free. We believe knowledge should be accessible to everyone, regardless of their budget.'],
                                ['title' => 'How often do you publish new content?', 'content' => 'We publish 2-3 new articles per week. Subscribe to our newsletter to get notified when new content is available.'],
                                ['title' => 'Can I contribute as a guest author?', 'content' => 'Absolutely! We welcome guest contributions from experienced developers. Send us your article idea and a brief outline via our contact page.'],
                                ['title' => 'Do you offer premium or paid content?', 'content' => 'Currently all our content is free. We may introduce premium courses or workshops in the future, but our blog will always remain free.'],
                            ],
                            'independentToggle' => false,
                            'defaultOpenIndex' => 0,
                            'borderColor' => '#e2e8f0',
                            'borderRadius' => '10px',
                            'headerPadding' => '20px',
                            'contentPadding' => '20px',
                            'titleFontSize' => '16px',
                            'contentFontSize' => '15px',
                            'itemGap' => '12px',
                        ]],
                    ]],
                ],
            ],
            // CTA
            $this->ctaSection(
                'Ready to Level Up?',
                'Start exploring our collection of articles, tutorials, and insights. Everything you need to build better software.',
                'Browse All Articles',
                '/blog'
            ),
        ];
    }

    /**
     * Get about page block structure.
     */
    protected function getAboutPageBlocks(): array
    {
        return [
            // Hero
            $this->heroSection(
                'About Us',
                'We are a team of passionate developers and writers dedicated to sharing knowledge that helps the community build better software.'
            ),
            // Our Story
            [
                'id' => self::blockId(),
                'type' => 'section',
                'props' => [
                    'fullWidth' => true,
                    'contentAlign' => 'center',
                    'backgroundType' => 'solid',
                    'backgroundColor' => '#ffffff',
                    'containerMaxWidth' => '800px',
                    'layoutStyles' => [
                        'padding' => ['top' => '72px', 'left' => '24px', 'right' => '24px', 'bottom' => '72px'],
                    ],
                    'children' => [[
                        ['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'Our Story', 'level' => 'h2', 'align' => 'center', 'color' => '#0f172a', 'fontSize' => '32px', 'fontWeight' => 'bold', 'layoutStyles' => ['margin' => ['bottom' => '24px']]]],
                        ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => 'What started as a simple blog has grown into a thriving platform for developers and creators. We noticed a gap in the market for high-quality, practical content that goes beyond surface-level tutorials.', 'align' => 'center', 'color' => '#475569', 'fontSize' => '17px', 'lineHeight' => '1.8', 'layoutStyles' => ['margin' => ['bottom' => '16px']]]],
                        ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => 'Every article we publish is carefully crafted, technically reviewed, and designed to solve real problems. We believe in depth over breadth, quality over quantity, and community over competition.', 'align' => 'center', 'color' => '#475569', 'fontSize' => '17px', 'lineHeight' => '1.8']],
                    ]],
                ],
            ],
            // Stats
            [
                'id' => self::blockId(),
                'type' => 'section',
                'props' => [
                    'fullWidth' => true,
                    'contentAlign' => 'center',
                    'backgroundType' => 'solid',
                    'backgroundColor' => '#f8fafc',
                    'containerMaxWidth' => '1280px',
                    'layoutStyles' => [
                        'padding' => ['top' => '56px', 'left' => '24px', 'right' => '24px', 'bottom' => '56px'],
                    ],
                    'children' => [[
                        [
                            'id' => self::blockId(),
                            'type' => 'columns',
                            'props' => [
                                'columns' => 4,
                                'gap' => '24px',
                                'verticalAlign' => 'center',
                                'children' => [
                                    [['id' => self::blockId(), 'type' => 'stats-item', 'props' => ['value' => '2020', 'label' => 'Founded', 'valueColor' => '#3b82f6', 'valueSize' => '40px', 'labelColor' => '#64748b', 'align' => 'center']]],
                                    [['id' => self::blockId(), 'type' => 'stats-item', 'props' => ['value' => '50', 'suffix' => '+', 'label' => 'Articles', 'valueColor' => '#8b5cf6', 'valueSize' => '40px', 'labelColor' => '#64748b', 'align' => 'center']]],
                                    [['id' => self::blockId(), 'type' => 'stats-item', 'props' => ['value' => '10K', 'suffix' => '+', 'label' => 'Readers', 'valueColor' => '#10b981', 'valueSize' => '40px', 'labelColor' => '#64748b', 'align' => 'center']]],
                                    [['id' => self::blockId(), 'type' => 'stats-item', 'props' => ['value' => '15', 'suffix' => '+', 'label' => 'Contributors', 'valueColor' => '#f59e0b', 'valueSize' => '40px', 'labelColor' => '#64748b', 'align' => 'center']]],
                                ],
                            ],
                        ],
                    ]],
                ],
            ],
            // Values
            [
                'id' => self::blockId(),
                'type' => 'section',
                'props' => [
                    'fullWidth' => true,
                    'contentAlign' => 'center',
                    'backgroundType' => 'solid',
                    'backgroundColor' => '#ffffff',
                    'containerMaxWidth' => '1280px',
                    'layoutStyles' => [
                        'padding' => ['top' => '72px', 'left' => '24px', 'right' => '24px', 'bottom' => '72px'],
                    ],
                    'children' => [[
                        ['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'Our Values', 'level' => 'h2', 'align' => 'center', 'color' => '#0f172a', 'fontSize' => '36px', 'fontWeight' => 'bold', 'layoutStyles' => ['margin' => ['bottom' => '12px']]]],
                        ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => 'The principles that guide everything we do.', 'align' => 'center', 'color' => '#64748b', 'fontSize' => '18px', 'lineHeight' => '1.6', 'layoutStyles' => ['margin' => ['bottom' => '48px']]]],
                        [
                            'id' => self::blockId(),
                            'type' => 'columns',
                            'props' => [
                                'columns' => 3,
                                'gap' => '32px',
                                'verticalAlign' => 'start',
                                'children' => [
                                    [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:heart', 'iconSize' => '28px', 'iconColor' => '#ef4444', 'iconBackgroundColor' => '#fee2e2', 'iconBackgroundShape' => 'rounded', 'title' => 'Quality First', 'titleColor' => '#0f172a', 'description' => 'Every piece of content is technically reviewed and tested. We never publish something we would not use ourselves.', 'descriptionColor' => '#64748b', 'align' => 'center']]],
                                    [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:eye', 'iconSize' => '28px', 'iconColor' => '#3b82f6', 'iconBackgroundColor' => '#dbeafe', 'iconBackgroundShape' => 'rounded', 'title' => 'Transparency', 'titleColor' => '#0f172a', 'description' => 'We share our processes, mistakes, and lessons learned. No gatekeeping, no hidden agendas, just honest knowledge sharing.', 'descriptionColor' => '#64748b', 'align' => 'center']]],
                                    [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:rocket', 'iconSize' => '28px', 'iconColor' => '#8b5cf6', 'iconBackgroundColor' => '#ede9fe', 'iconBackgroundShape' => 'rounded', 'title' => 'Continuous Growth', 'titleColor' => '#0f172a', 'description' => 'Technology evolves fast. We stay current so you do not have to spend hours researching what works today.', 'descriptionColor' => '#64748b', 'align' => 'center']]],
                                ],
                            ],
                        ],
                    ]],
                ],
            ],
            // CTA
            $this->ctaSection(
                'Want to Get in Touch?',
                'Have a question, feedback, or just want to say hello? We would love to hear from you.',
                'Contact Us',
                '/contact'
            ),
        ];
    }

    /**
     * Get blog page block structure.
     */
    protected function getBlogPageBlocks(): array
    {
        return [
            // Hero
            $this->heroSection(
                'Blog',
                'Explore our collection of articles, tutorials, and stories crafted to help you build better software.'
            ),
            // Interactive posts listing
            [
                'id' => self::blockId(),
                'type' => 'latest-posts',
                'props' => [
                    'layout' => 'grid',
                    'columns' => 3,
                    'showDate' => true,
                    'showSort' => true,
                    'postRoute' => 'starter26.post',
                    'showImage' => true,
                    'postsCount' => 12,
                    'showAuthor' => false,
                    'showSearch' => true,
                    'headingText' => null,
                    'interactive' => true,
                    'showExcerpt' => true,
                    'categorySlug' => null,
                    'layoutStyles' => [
                        'padding' => ['top' => '48px', 'left' => '24px', 'right' => '24px', 'bottom' => '48px'],
                    ],
                    'showCategoryFilter' => true,
                ],
            ],
            // CTA
            $this->ctaSection(
                'Have Something to Share?',
                'We welcome guest contributions from experienced developers. Share your knowledge with our growing community.',
                'Get in Touch',
                '/contact'
            ),
        ];
    }

    /**
     * Get experimental page block structure — showcases all new block types.
     */
    protected function getExperimentalPageBlocks(): array
    {
        return [
            // Hero Section (2-column: text left, image right)
            [
                'id' => self::blockId(), 'type' => 'section',
                'props' => [
                    'fullWidth' => true, 'containerMaxWidth' => '1200px', 'contentAlign' => 'center',
                    'backgroundType' => 'solid', 'backgroundColor' => '#ffffff',
                    'layoutStyles' => ['padding' => ['top' => '40px', 'bottom' => '40px', 'left' => '24px', 'right' => '24px']],
                    'children' => [[
                        ['id' => self::blockId(), 'type' => 'columns', 'props' => [
                            'columns' => 2, 'gap' => '40px',
                            'children' => [
                                // Left column
                                [
                                    ['id' => self::blockId(), 'type' => 'alert-banner', 'props' => ['text' => 'AI-powered module marketplace is live', 'badgeText' => 'NEW', 'linkUrl' => '/pricing', 'backgroundColor' => '#f3f4f6', 'textColor' => '#374151', 'badgeColor' => '#22c55e', 'badgeTextColor' => '#ffffff', 'align' => 'left', 'padding' => '6px 16px', 'borderRadius' => '9999px']],
                                    ['id' => self::blockId(), 'type' => 'spacer', 'props' => ['height' => '24px']],
                                    ['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'Laravel Admin Panel', 'level' => 'h1', 'align' => 'left', 'color' => '#111827', 'fontSize' => '56px', 'fontWeight' => '800', 'lineHeight' => '1.05']],
                                    ['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => '<span style="color: #7c3aed;">for CRM Systems</span>', 'level' => 'h1', 'align' => 'left', 'color' => '#7c3aed', 'fontSize' => '56px', 'fontWeight' => '800', 'lineHeight' => '1.05']],
                                    ['id' => self::blockId(), 'type' => 'spacer', 'props' => ['height' => '20px']],
                                    ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => '<p>Manage content, users, emails, menus, and settings out of the box — then extend with AI-powered modules from the marketplace. The complete Laravel CMS your internet app deserves.</p>', 'align' => 'left', 'color' => '#6b7280', 'fontSize' => '17px', 'lineHeight' => '1.7']],
                                    ['id' => self::blockId(), 'type' => 'spacer', 'props' => ['height' => '24px']],
                                    ['id' => self::blockId(), 'type' => 'button-group', 'props' => ['buttons' => [['text' => 'Try Live Demo', 'link' => 'https://demo.laradashboard.com', 'variant' => 'solid', 'backgroundColor' => '#4f46e5', 'textColor' => '#ffffff', 'icon' => 'lucide:play', 'iconPosition' => 'left'], ['text' => 'Build Now (Free)', 'link' => '/pricing', 'variant' => 'outline', 'backgroundColor' => '#374151', 'textColor' => '#374151', 'icon' => '', 'iconPosition' => 'left']], 'alignment' => 'left', 'gap' => '12px', 'size' => 'lg', 'stackOnMobile' => true, 'borderRadius' => '10px']],
                                    ['id' => self::blockId(), 'type' => 'spacer', 'props' => ['height' => '24px']],
                                    ['id' => self::blockId(), 'type' => 'columns', 'props' => ['columns' => 3, 'gap' => '16px', 'children' => [
                                        [['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => '<p><span style="color: #22c55e;">●</span> 100% Free Core</p>', 'align' => 'left', 'color' => '#6b7280', 'fontSize' => '13px']]],
                                        [['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => '<p><span style="color: #22c55e;">●</span> Laravel Native</p>', 'align' => 'left', 'color' => '#6b7280', 'fontSize' => '13px']]],
                                        [['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => '<p><span style="color: #22c55e;">●</span> 5+ Modules</p>', 'align' => 'left', 'color' => '#6b7280', 'fontSize' => '13px']]],
                                    ]]],
                                ],
                                // Right column
                                [
                                    ['id' => self::blockId(), 'type' => 'card', 'props' => ['backgroundColor' => '#ffffff', 'borderColor' => '#e5e7eb', 'borderWidth' => '1px', 'borderRadius' => '12px', 'shadow' => 'lg', 'hoverShadow' => 'xl', 'hoverScale' => 'none', 'padding' => '0px', 'children' => [[
                                        ['id' => self::blockId(), 'type' => 'html', 'props' => ['content' => '<div style="display: flex; align-items: center; gap: 8px; padding: 12px 16px; background: #f9fafb; border-bottom: 1px solid #e5e7eb; border-radius: 12px 12px 0 0;"><span style="width: 10px; height: 10px; background: #ef4444; border-radius: 50%; display: inline-block;"></span><span style="width: 10px; height: 10px; background: #f59e0b; border-radius: 50%; display: inline-block;"></span><span style="width: 10px; height: 10px; background: #22c55e; border-radius: 50%; display: inline-block;"></span><span style="margin-left: 8px; color: #9ca3af; font-size: 13px;">yourdomain.com/admin</span></div>']],
                                        ['id' => self::blockId(), 'type' => 'image', 'props' => ['src' => 'https://laradashboard.com/modules/laradashboard/images/demo.png', 'alt' => 'LaraDashboard — Admin Panel Preview', 'align' => 'center']],
                                    ]]]],
                                    ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => '<p><a href="https://demo.laradashboard.com" style="color: #22c55e; text-decoration: none; font-size: 13px;">● Live demo available ↗</a></p>', 'align' => 'center', 'color' => '#22c55e', 'fontSize' => '13px', 'layoutStyles' => ['margin' => ['top' => '12px']]]],
                                ],
                            ],
                        ]],
                    ]],
                ],
            ],

            // Logo Carousel
            [
                'id' => self::blockId(), 'type' => 'logo-carousel',
                'props' => [
                    'images' => [
                        ['src' => 'https://placehold.co/150x40/6366f1/ffffff?text=DMWords', 'alt' => 'DMWords', 'link' => ''],
                        ['src' => 'https://placehold.co/150x40/8b5cf6/ffffff?text=LifeCoach', 'alt' => 'LifeCoach', 'link' => ''],
                        ['src' => 'https://placehold.co/150x40/ec4899/ffffff?text=Gjiganti', 'alt' => 'Gjiganti', 'link' => ''],
                        ['src' => 'https://placehold.co/150x40/f59e0b/ffffff?text=Buuno', 'alt' => 'Buuno', 'link' => ''],
                        ['src' => 'https://placehold.co/150x40/10b981/ffffff?text=SimpleCRUD', 'alt' => 'SimpleCRUD', 'link' => ''],
                        ['src' => 'https://placehold.co/150x40/3b82f6/ffffff?text=FresMdia', 'alt' => 'FresMdia', 'link' => ''],
                        ['src' => 'https://placehold.co/150x40/ef4444/ffffff?text=Squartup', 'alt' => 'Squartup', 'link' => ''],
                    ],
                    'speed' => 30, 'direction' => 'left', 'pauseOnHover' => true, 'gap' => '64px',
                    'imageHeight' => '32px', 'grayscale' => true,
                    'headingText' => 'Trusted by Devs, Startups & Agencies worldwide', 'headingColor' => '#9ca3af', 'headingSize' => '14px',
                ],
            ],

            // Build Any Product section
            [
                'id' => self::blockId(), 'type' => 'section',
                'props' => [
                    'fullWidth' => true, 'containerMaxWidth' => '1100px', 'contentAlign' => 'center',
                    'backgroundType' => 'solid', 'backgroundColor' => '#f9fafb',
                    'layoutStyles' => ['padding' => ['top' => '56px', 'bottom' => '56px', 'left' => '24px', 'right' => '24px']],
                    'children' => [[
                        ['id' => self::blockId(), 'type' => 'badge', 'props' => ['text' => 'One Platform, Endless Possibilities', 'variant' => 'soft', 'size' => 'sm', 'color' => '#6366f1', 'textColor' => '#4f46e5', 'borderRadius' => 'pill', 'align' => 'center', 'icon' => '']],
                        ['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'Build Any Product With One Codebase', 'level' => 'h2', 'align' => 'center', 'color' => '#111827', 'fontSize' => '40px', 'fontWeight' => 'bold', 'lineHeight' => '1.2']],
                        ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => '<p>Stop juggling multiple tools and frameworks. Lara Dashboard gives you everything you need to build, manage, and scale any product.</p>', 'align' => 'center', 'color' => '#6b7280', 'fontSize' => '18px', 'lineHeight' => '1.6']],
                        ['id' => self::blockId(), 'type' => 'spacer', 'props' => ['height' => '24px']],
                        ['id' => self::blockId(), 'type' => 'columns', 'props' => ['columns' => 3, 'gap' => '20px', 'children' => [
                            [['id' => self::blockId(), 'type' => 'card', 'props' => ['backgroundColor' => '#ffffff', 'borderColor' => '#e5e7eb', 'borderWidth' => '1px', 'borderRadius' => '12px', 'shadow' => 'sm', 'hoverShadow' => 'md', 'hoverScale' => '1.02', 'padding' => '24px', 'children' => [[['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'SaaS Apps', 'level' => 'h4', 'align' => 'left', 'color' => '#111827', 'fontSize' => '16px', 'fontWeight' => '600']], ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => '<p>Subscription ready</p>', 'align' => 'left', 'color' => '#6b7280', 'fontSize' => '14px']]]]]]],
                            [['id' => self::blockId(), 'type' => 'card', 'props' => ['backgroundColor' => '#ffffff', 'borderColor' => '#e5e7eb', 'borderWidth' => '1px', 'borderRadius' => '12px', 'shadow' => 'sm', 'hoverShadow' => 'md', 'hoverScale' => '1.02', 'padding' => '24px', 'children' => [[['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'CRM Systems', 'level' => 'h4', 'align' => 'left', 'color' => '#111827', 'fontSize' => '16px', 'fontWeight' => '600']], ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => '<p>Contact & deals</p>', 'align' => 'left', 'color' => '#6b7280', 'fontSize' => '14px']]]]]]],
                            [['id' => self::blockId(), 'type' => 'card', 'props' => ['backgroundColor' => '#ffffff', 'borderColor' => '#e5e7eb', 'borderWidth' => '1px', 'borderRadius' => '12px', 'shadow' => 'sm', 'hoverShadow' => 'md', 'hoverScale' => '1.02', 'padding' => '24px', 'children' => [[['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'E-commerce', 'level' => 'h4', 'align' => 'left', 'color' => '#111827', 'fontSize' => '16px', 'fontWeight' => '600']], ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => '<p>Products & orders</p>', 'align' => 'left', 'color' => '#6b7280', 'fontSize' => '14px']]]]]]],
                        ]]],
                        ['id' => self::blockId(), 'type' => 'columns', 'props' => ['columns' => 3, 'gap' => '20px', 'layoutStyles' => ['margin' => ['top' => '16px']], 'children' => [
                            [['id' => self::blockId(), 'type' => 'card', 'props' => ['backgroundColor' => '#ffffff', 'borderColor' => '#e5e7eb', 'borderWidth' => '1px', 'borderRadius' => '12px', 'shadow' => 'sm', 'hoverShadow' => 'md', 'hoverScale' => '1.02', 'padding' => '24px', 'children' => [[['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'Blog & CMS', 'level' => 'h4', 'align' => 'left', 'color' => '#111827', 'fontSize' => '16px', 'fontWeight' => '600']], ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => '<p>Content sites</p>', 'align' => 'left', 'color' => '#6b7280', 'fontSize' => '14px']]]]]]],
                            [['id' => self::blockId(), 'type' => 'card', 'props' => ['backgroundColor' => '#ffffff', 'borderColor' => '#e5e7eb', 'borderWidth' => '1px', 'borderRadius' => '12px', 'shadow' => 'sm', 'hoverShadow' => 'md', 'hoverScale' => '1.02', 'padding' => '24px', 'children' => [[['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'Membership', 'level' => 'h4', 'align' => 'left', 'color' => '#111827', 'fontSize' => '16px', 'fontWeight' => '600']], ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => '<p>Gated content</p>', 'align' => 'left', 'color' => '#6b7280', 'fontSize' => '14px']]]]]]],
                            [['id' => self::blockId(), 'type' => 'card', 'props' => ['backgroundColor' => '#ffffff', 'borderColor' => '#e5e7eb', 'borderWidth' => '1px', 'borderRadius' => '12px', 'shadow' => 'sm', 'hoverShadow' => 'md', 'hoverScale' => '1.02', 'padding' => '24px', 'children' => [[['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'Internal Tools', 'level' => 'h4', 'align' => 'left', 'color' => '#111827', 'fontSize' => '16px', 'fontWeight' => '600']], ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => '<p>Admin panels</p>', 'align' => 'left', 'color' => '#6b7280', 'fontSize' => '14px']]]]]]],
                        ]]],
                    ]],
                ],
            ],

            // Value Props
            [
                'id' => self::blockId(), 'type' => 'section',
                'props' => [
                    'fullWidth' => true, 'containerMaxWidth' => '1100px', 'contentAlign' => 'center',
                    'backgroundType' => 'solid', 'backgroundColor' => '#ffffff',
                    'layoutStyles' => ['padding' => ['top' => '40px', 'bottom' => '40px', 'left' => '24px', 'right' => '24px']],
                    'children' => [[
                        ['id' => self::blockId(), 'type' => 'columns', 'props' => ['columns' => 3, 'gap' => '24px', 'children' => [
                            [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:zap', 'iconSize' => '32px', 'iconColor' => '#4f46e5', 'iconBackgroundColor' => '#eef2ff', 'iconBackgroundShape' => 'rounded', 'title' => 'Build 10x Faster', 'titleColor' => '#111827', 'titleSize' => '20px', 'description' => 'Skip months of boilerplate. Start with a production-ready foundation including auth, roles, CMS, and visual page builder.', 'descriptionColor' => '#6b7280', 'descriptionSize' => '14px', 'align' => 'left', 'gap' => '16px']]],
                            [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:puzzle', 'iconSize' => '32px', 'iconColor' => '#4f46e5', 'iconBackgroundColor' => '#eef2ff', 'iconBackgroundShape' => 'rounded', 'title' => 'Extend via Marketplace', 'titleColor' => '#111827', 'titleSize' => '20px', 'description' => 'Need more features? Browse 5+ modules from our marketplace or build and sell your own to earn 95% revenue.', 'descriptionColor' => '#6b7280', 'descriptionSize' => '14px', 'align' => 'left', 'gap' => '16px']]],
                            [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:shield-check', 'iconSize' => '32px', 'iconColor' => '#4f46e5', 'iconBackgroundColor' => '#eef2ff', 'iconBackgroundShape' => 'rounded', 'title' => 'Scale with Confidence', 'titleColor' => '#111827', 'titleSize' => '20px', 'description' => 'Built on Laravel 12 best practices. Queue support, caching, API rate limiting, and multi-tenant ready architecture.', 'descriptionColor' => '#6b7280', 'descriptionSize' => '14px', 'align' => 'left', 'gap' => '16px']]],
                        ]]],
                    ]],
                ],
            ],

            // Stats Bar
            [
                'id' => self::blockId(), 'type' => 'section',
                'props' => [
                    'fullWidth' => true, 'containerMaxWidth' => '1100px', 'contentAlign' => 'center',
                    'backgroundType' => 'solid', 'backgroundColor' => '#4f46e5',
                    'layoutStyles' => ['padding' => ['top' => '32px', 'bottom' => '32px', 'left' => '24px', 'right' => '24px']],
                    'children' => [[
                        ['id' => self::blockId(), 'type' => 'columns', 'props' => ['columns' => 4, 'gap' => '16px', 'children' => [
                            [['id' => self::blockId(), 'type' => 'stats-item', 'props' => ['value' => '30+', 'valueColor' => '#ffffff', 'valueSize' => '40px', 'label' => 'Built-in Features', 'labelColor' => '#c7d2fe', 'labelSize' => '14px', 'align' => 'center']]],
                            [['id' => self::blockId(), 'type' => 'stats-item', 'props' => ['value' => '5+', 'valueColor' => '#ffffff', 'valueSize' => '40px', 'label' => 'Marketplace Modules', 'labelColor' => '#c7d2fe', 'labelSize' => '14px', 'align' => 'center']]],
                            [['id' => self::blockId(), 'type' => 'stats-item', 'props' => ['value' => '30+', 'valueColor' => '#ffffff', 'valueSize' => '40px', 'label' => 'Languages Supported', 'labelColor' => '#c7d2fe', 'labelSize' => '14px', 'align' => 'center']]],
                            [['id' => self::blockId(), 'type' => 'stats-item', 'props' => ['value' => '100%', 'valueColor' => '#ffffff', 'valueSize' => '40px', 'label' => 'Open Source Core', 'labelColor' => '#c7d2fe', 'labelSize' => '14px', 'align' => 'center']]],
                        ]]],
                    ]],
                ],
            ],

            // AI Features
            [
                'id' => self::blockId(), 'type' => 'section',
                'props' => [
                    'fullWidth' => true, 'containerMaxWidth' => '1100px', 'contentAlign' => 'center',
                    'backgroundType' => 'solid', 'backgroundColor' => '#f9fafb',
                    'layoutStyles' => ['padding' => ['top' => '56px', 'bottom' => '56px', 'left' => '24px', 'right' => '24px']],
                    'children' => [[
                        ['id' => self::blockId(), 'type' => 'badge', 'props' => ['text' => 'AI-Powered', 'variant' => 'soft', 'size' => 'sm', 'color' => '#8b5cf6', 'textColor' => '#7c3aed', 'borderRadius' => 'pill', 'align' => 'center', 'icon' => 'lucide:sparkles']],
                        ['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'Build Smarter with Agentic AI', 'level' => 'h2', 'align' => 'center', 'color' => '#111827', 'fontSize' => '40px', 'fontWeight' => 'bold', 'lineHeight' => '1.2']],
                        ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => '<p>Lara Dashboard comes with built-in AI capabilities that help you build, automate, and scale your applications faster.</p>', 'align' => 'center', 'color' => '#6b7280', 'fontSize' => '18px', 'lineHeight' => '1.6']],
                        ['id' => self::blockId(), 'type' => 'spacer', 'props' => ['height' => '32px']],
                        ['id' => self::blockId(), 'type' => 'columns', 'props' => ['columns' => 3, 'gap' => '20px', 'children' => [
                            [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:bot', 'iconSize' => '28px', 'iconColor' => '#7c3aed', 'iconBackgroundColor' => '#f3e8ff', 'iconBackgroundShape' => 'rounded', 'title' => 'Agentic AI System', 'titleSize' => '16px', 'titleColor' => '#111827', 'description' => 'Built-in AI agents that automate tasks, generate content, and assist users.', 'descriptionColor' => '#6b7280', 'descriptionSize' => '14px', 'align' => 'left', 'gap' => '12px']]],
                            [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:puzzle', 'iconSize' => '28px', 'iconColor' => '#7c3aed', 'iconBackgroundColor' => '#f3e8ff', 'iconBackgroundShape' => 'rounded', 'title' => 'AI-Powered Modules', 'titleSize' => '16px', 'titleColor' => '#111827', 'description' => 'Create intelligent modules with AI agents. Build chatbots and smart automation.', 'descriptionColor' => '#6b7280', 'descriptionSize' => '14px', 'align' => 'left', 'gap' => '12px']]],
                            [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:layout-dashboard', 'iconSize' => '28px', 'iconColor' => '#7c3aed', 'iconBackgroundColor' => '#f3e8ff', 'iconBackgroundShape' => 'rounded', 'title' => 'Visual Page Builder', 'titleSize' => '16px', 'titleColor' => '#111827', 'description' => 'Drag-and-drop page builder with 30+ blocks. Create beautiful pages without code.', 'descriptionColor' => '#6b7280', 'descriptionSize' => '14px', 'align' => 'left', 'gap' => '12px']]],
                        ]]],
                        ['id' => self::blockId(), 'type' => 'columns', 'props' => ['columns' => 3, 'gap' => '20px', 'layoutStyles' => ['margin' => ['top' => '16px']], 'children' => [
                            [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:file-text', 'iconSize' => '28px', 'iconColor' => '#7c3aed', 'iconBackgroundColor' => '#f3e8ff', 'iconBackgroundShape' => 'rounded', 'title' => 'AI Content Generation', 'titleSize' => '16px', 'titleColor' => '#111827', 'description' => 'Generate blog posts, descriptions, and marketing copy with AI.', 'descriptionColor' => '#6b7280', 'descriptionSize' => '14px', 'align' => 'left', 'gap' => '12px']]],
                            [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:workflow', 'iconSize' => '28px', 'iconColor' => '#7c3aed', 'iconBackgroundColor' => '#f3e8ff', 'iconBackgroundShape' => 'rounded', 'title' => 'Smart Automation', 'titleSize' => '16px', 'titleColor' => '#111827', 'description' => 'Automate workflows with AI-powered triggers and actions.', 'descriptionColor' => '#6b7280', 'descriptionSize' => '14px', 'align' => 'left', 'gap' => '12px']]],
                            [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:cpu', 'iconSize' => '28px', 'iconColor' => '#7c3aed', 'iconBackgroundColor' => '#f3e8ff', 'iconBackgroundShape' => 'rounded', 'title' => 'Multi-Provider AI', 'titleSize' => '16px', 'titleColor' => '#111827', 'description' => 'Connect OpenAI, Anthropic, or other AI providers seamlessly.', 'descriptionColor' => '#6b7280', 'descriptionSize' => '14px', 'align' => 'left', 'gap' => '12px']]],
                        ]]],
                    ]],
                ],
            ],

            // Steps
            [
                'id' => self::blockId(), 'type' => 'section',
                'props' => [
                    'fullWidth' => true, 'containerMaxWidth' => '900px', 'contentAlign' => 'center',
                    'backgroundType' => 'solid', 'backgroundColor' => '#ffffff',
                    'layoutStyles' => ['padding' => ['top' => '56px', 'bottom' => '56px', 'left' => '24px', 'right' => '24px']],
                    'children' => [[
                        ['id' => self::blockId(), 'type' => 'badge', 'props' => ['text' => 'Quick Setup', 'variant' => 'soft', 'size' => 'sm', 'color' => '#10b981', 'textColor' => '#059669', 'borderRadius' => 'pill', 'align' => 'center', 'icon' => 'lucide:rocket']],
                        ['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'Get Started in 3 Simple Steps', 'level' => 'h2', 'align' => 'center', 'color' => '#111827', 'fontSize' => '40px', 'fontWeight' => 'bold', 'lineHeight' => '1.2']],
                        ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => '<p>From zero to production-ready in minutes. No complex configurations, no headaches.</p>', 'align' => 'center', 'color' => '#6b7280', 'fontSize' => '18px', 'lineHeight' => '1.6']],
                        ['id' => self::blockId(), 'type' => 'spacer', 'props' => ['height' => '32px']],
                        ['id' => self::blockId(), 'type' => 'steps', 'props' => ['steps' => [['title' => 'Download', 'description' => 'Get the starter template and follow the installation wizard.', 'code' => 'git clone https://github.com/laradashboard/laradashboard.git', 'linkText' => 'Installation Guide', 'linkUrl' => 'https://laradashboard.com/docs/installation'], ['title' => 'Configure', 'description' => 'Set up your database, run migrations, and configure your environment.', 'code' => 'php artisan migrate --seed && npm run build', 'linkText' => '', 'linkUrl' => ''], ['title' => 'Launch', 'description' => 'You\'re ready! Access your admin panel and start building your product.', 'code' => '', 'linkText' => '', 'linkUrl' => '']], 'layout' => 'vertical', 'showNumbers' => true, 'showConnector' => true, 'numberColor' => '#ffffff', 'numberBgColor' => '#4f46e5', 'titleColor' => '#111827', 'titleSize' => '20px', 'descriptionColor' => '#6b7280', 'descriptionSize' => '15px', 'connectorColor' => '#e5e7eb', 'codeBackgroundColor' => '#1f2937', 'codeTextColor' => '#e5e7eb']],
                    ]],
                ],
            ],

            // Testimonials
            [
                'id' => self::blockId(), 'type' => 'section',
                'props' => [
                    'fullWidth' => true, 'containerMaxWidth' => '1100px', 'contentAlign' => 'center',
                    'backgroundType' => 'solid', 'backgroundColor' => '#f9fafb',
                    'layoutStyles' => ['padding' => ['top' => '56px', 'bottom' => '56px', 'left' => '24px', 'right' => '24px']],
                    'children' => [[
                        ['id' => self::blockId(), 'type' => 'badge', 'props' => ['text' => 'Customers Review', 'variant' => 'soft', 'size' => 'sm', 'color' => '#f59e0b', 'textColor' => '#d97706', 'borderRadius' => 'pill', 'align' => 'center', 'icon' => 'lucide:heart']],
                        ['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'See What Our Customers Are Saying', 'level' => 'h2', 'align' => 'center', 'color' => '#111827', 'fontSize' => '40px', 'fontWeight' => 'bold', 'lineHeight' => '1.2']],
                        ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => '<p>Real feedback from happy customers who simplified their workflow with Lara Dashboard.</p>', 'align' => 'center', 'color' => '#6b7280', 'fontSize' => '18px']],
                        ['id' => self::blockId(), 'type' => 'spacer', 'props' => ['height' => '32px']],
                        ['id' => self::blockId(), 'type' => 'columns', 'props' => ['columns' => 3, 'gap' => '20px', 'children' => [
                            [['id' => self::blockId(), 'type' => 'testimonial', 'props' => ['quote' => 'Lara Dashboard has completely transformed how we manage operations. From handling CRM tasks to advanced analytics, it does it all.', 'authorName' => 'Faton Krasniqi', 'authorRole' => 'CEO of DM Words', 'avatarUrl' => '', 'rating' => 5, 'showRating' => true, 'cardStyle' => 'shadow', 'backgroundColor' => '#ffffff', 'textColor' => '#374151', 'nameColor' => '#111827', 'ratingColor' => '#fbbf24', 'borderColor' => '#e5e7eb']]],
                            [['id' => self::blockId(), 'type' => 'testimonial', 'props' => ['quote' => 'LD simplified HRM tasks like leave, salary, and attendance. It is user-friendly and saved us tons of time.', 'authorName' => 'Novák Balázs', 'authorRole' => 'Co-Founder, Heroes Digital', 'avatarUrl' => '', 'rating' => 5, 'showRating' => true, 'cardStyle' => 'shadow', 'backgroundColor' => '#ffffff', 'textColor' => '#374151', 'nameColor' => '#111827', 'ratingColor' => '#fbbf24', 'borderColor' => '#e5e7eb']]],
                            [['id' => self::blockId(), 'type' => 'testimonial', 'props' => ['quote' => 'We use LD as our default admin panel for client projects. It is powerful yet easy to use. The role and permissions system is great.', 'authorName' => 'Derek', 'authorRole' => 'Founder, Nitro Soft', 'avatarUrl' => '', 'rating' => 5, 'showRating' => true, 'cardStyle' => 'shadow', 'backgroundColor' => '#ffffff', 'textColor' => '#374151', 'nameColor' => '#111827', 'ratingColor' => '#fbbf24', 'borderColor' => '#e5e7eb']]],
                        ]]],
                    ]],
                ],
            ],

            // Tech Stack
            [
                'id' => self::blockId(), 'type' => 'section',
                'props' => [
                    'fullWidth' => true, 'containerMaxWidth' => '1100px', 'contentAlign' => 'center',
                    'backgroundType' => 'solid', 'backgroundColor' => '#ffffff',
                    'layoutStyles' => ['padding' => ['top' => '56px', 'bottom' => '56px', 'left' => '24px', 'right' => '24px']],
                    'children' => [[
                        ['id' => self::blockId(), 'type' => 'badge', 'props' => ['text' => 'Tech Stack', 'variant' => 'soft', 'size' => 'sm', 'color' => '#3b82f6', 'textColor' => '#2563eb', 'borderRadius' => 'pill', 'align' => 'center', 'icon' => 'lucide:layers']],
                        ['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'Built with Modern Technologies', 'level' => 'h2', 'align' => 'center', 'color' => '#111827', 'fontSize' => '40px', 'fontWeight' => 'bold', 'lineHeight' => '1.2']],
                        ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => '<p>Powered by Laravel, AI, and the best tools in the ecosystem.</p>', 'align' => 'center', 'color' => '#6b7280', 'fontSize' => '18px']],
                        ['id' => self::blockId(), 'type' => 'spacer', 'props' => ['height' => '32px']],
                        ['id' => self::blockId(), 'type' => 'columns', 'props' => ['columns' => 3, 'gap' => '16px', 'children' => [
                            [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'devicon:laravel', 'iconSize' => '36px', 'iconColor' => '#ff2d20', 'iconBackgroundColor' => '', 'iconBackgroundShape' => 'none', 'title' => 'Laravel 12', 'titleSize' => '16px', 'titleColor' => '#111827', 'description' => 'The PHP framework for web artisans', 'descriptionColor' => '#6b7280', 'descriptionSize' => '13px', 'align' => 'center', 'gap' => '8px']]],
                            [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'simple-icons:livewire', 'iconSize' => '36px', 'iconColor' => '#fb70a9', 'iconBackgroundColor' => '', 'iconBackgroundShape' => 'none', 'title' => 'Livewire 3', 'titleSize' => '16px', 'titleColor' => '#111827', 'description' => 'Real-time reactive UI', 'descriptionColor' => '#6b7280', 'descriptionSize' => '13px', 'align' => 'center', 'gap' => '8px']]],
                            [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'devicon:tailwindcss', 'iconSize' => '36px', 'iconColor' => '#06b6d4', 'iconBackgroundColor' => '', 'iconBackgroundShape' => 'none', 'title' => 'Tailwind CSS', 'titleSize' => '16px', 'titleColor' => '#111827', 'description' => 'Utility-first styling', 'descriptionColor' => '#6b7280', 'descriptionSize' => '13px', 'align' => 'center', 'gap' => '8px']]],
                        ]]],
                        ['id' => self::blockId(), 'type' => 'columns', 'props' => ['columns' => 3, 'gap' => '16px', 'layoutStyles' => ['margin' => ['top' => '16px']], 'children' => [
                            [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'devicon:alpinejs', 'iconSize' => '36px', 'iconColor' => '#77c1d2', 'iconBackgroundColor' => '', 'iconBackgroundShape' => 'none', 'title' => 'Alpine.js', 'titleSize' => '16px', 'titleColor' => '#111827', 'description' => 'Lightweight interactivity', 'descriptionColor' => '#6b7280', 'descriptionSize' => '13px', 'align' => 'center', 'gap' => '8px']]],
                            [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'devicon:vitejs', 'iconSize' => '36px', 'iconColor' => '#646cff', 'iconBackgroundColor' => '', 'iconBackgroundShape' => 'none', 'title' => 'Vite', 'titleSize' => '16px', 'titleColor' => '#111827', 'description' => 'Lightning-fast builds', 'descriptionColor' => '#6b7280', 'descriptionSize' => '13px', 'align' => 'center', 'gap' => '8px']]],
                            [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'devicon:react', 'iconSize' => '36px', 'iconColor' => '#61dafb', 'iconBackgroundColor' => '', 'iconBackgroundShape' => 'none', 'title' => 'React', 'titleSize' => '16px', 'titleColor' => '#111827', 'description' => 'Component-based UI', 'descriptionColor' => '#6b7280', 'descriptionSize' => '13px', 'align' => 'center', 'gap' => '8px']]],
                        ]]],
                    ]],
                ],
            ],

            // Final CTA
            $this->ctaSection(
                'Try Lara Dashboard for Free',
                'Explore every feature live — no sign-up required.',
                'Launch Live Demo',
                'https://demo.laradashboard.com/admin'
            ),
        ];
    }

    /**
     * Get contact page block structure.
     */
    protected function getContactPageBlocks(): array
    {
        return [
            // Hero
            $this->heroSection(
                'Contact Us',
                'Have a question, suggestion, or just want to say hello? We would love to hear from you. Reach out and we will get back to you as soon as possible.'
            ),
            // Contact Methods
            [
                'id' => self::blockId(),
                'type' => 'section',
                'props' => [
                    'fullWidth' => true,
                    'contentAlign' => 'center',
                    'backgroundType' => 'solid',
                    'backgroundColor' => '#ffffff',
                    'containerMaxWidth' => '1280px',
                    'layoutStyles' => [
                        'padding' => ['top' => '72px', 'left' => '24px', 'right' => '24px', 'bottom' => '72px'],
                    ],
                    'children' => [[
                        ['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'Get in Touch', 'level' => 'h2', 'align' => 'center', 'color' => '#0f172a', 'fontSize' => '36px', 'fontWeight' => 'bold', 'layoutStyles' => ['margin' => ['bottom' => '12px']]]],
                        ['id' => self::blockId(), 'type' => 'text', 'props' => ['content' => 'Choose the best way to reach us.', 'align' => 'center', 'color' => '#64748b', 'fontSize' => '18px', 'lineHeight' => '1.6', 'layoutStyles' => ['margin' => ['bottom' => '48px']]]],
                        [
                            'id' => self::blockId(),
                            'type' => 'columns',
                            'props' => [
                                'columns' => 3,
                                'gap' => '32px',
                                'verticalAlign' => 'start',
                                'children' => [
                                    [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:mail', 'iconSize' => '28px', 'iconColor' => '#3b82f6', 'iconBackgroundColor' => '#dbeafe', 'iconBackgroundShape' => 'rounded', 'title' => 'Email Us', 'titleColor' => '#0f172a', 'description' => 'Send us an email anytime. We typically respond within 24 hours on business days.', 'descriptionColor' => '#64748b', 'align' => 'center']]],
                                    [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:message-circle', 'iconSize' => '28px', 'iconColor' => '#10b981', 'iconBackgroundColor' => '#d1fae5', 'iconBackgroundShape' => 'rounded', 'title' => 'Community Forum', 'titleColor' => '#0f172a', 'description' => 'Join our community forum to ask questions, share ideas, and connect with fellow developers.', 'descriptionColor' => '#64748b', 'align' => 'center']]],
                                    [['id' => self::blockId(), 'type' => 'feature-box', 'props' => ['icon' => 'lucide:github', 'iconSize' => '28px', 'iconColor' => '#6366f1', 'iconBackgroundColor' => '#e0e7ff', 'iconBackgroundShape' => 'rounded', 'title' => 'Open Source', 'titleColor' => '#0f172a', 'description' => 'Found a bug or have a feature request? Open an issue on our GitHub repository.', 'descriptionColor' => '#64748b', 'align' => 'center']]],
                                ],
                            ],
                        ],
                    ]],
                ],
            ],
            // FAQ
            [
                'id' => self::blockId(),
                'type' => 'section',
                'props' => [
                    'fullWidth' => true,
                    'contentAlign' => 'center',
                    'backgroundType' => 'solid',
                    'backgroundColor' => '#f8fafc',
                    'containerMaxWidth' => '800px',
                    'layoutStyles' => [
                        'padding' => ['top' => '72px', 'left' => '24px', 'right' => '24px', 'bottom' => '72px'],
                    ],
                    'children' => [[
                        ['id' => self::blockId(), 'type' => 'heading', 'props' => ['text' => 'Frequently Asked Questions', 'level' => 'h2', 'align' => 'center', 'color' => '#0f172a', 'fontSize' => '32px', 'fontWeight' => 'bold', 'layoutStyles' => ['margin' => ['bottom' => '40px']]]],
                        ['id' => self::blockId(), 'type' => 'accordion', 'props' => [
                            'items' => [
                                ['title' => 'How can I contribute an article?', 'content' => 'We welcome guest contributions! Send us an email with your article idea and a brief outline. Our editorial team will review it and get back to you within a week.'],
                                ['title' => 'Do you offer sponsorship opportunities?', 'content' => 'Yes, we work with companies that align with our audience of developers and creators. Reach out via email with your proposal and we will discuss options.'],
                                ['title' => 'How do I report a technical issue?', 'content' => 'If you have found a bug or technical issue with our site, please open an issue on our GitHub repository. Include steps to reproduce the problem and any relevant screenshots.'],
                                ['title' => 'Can I republish your content?', 'content' => 'Our content is copyrighted, but we are open to syndication partnerships. Contact us to discuss terms. Please do not republish without written permission.'],
                            ],
                            'independentToggle' => false,
                            'defaultOpenIndex' => 0,
                            'borderColor' => '#e2e8f0',
                            'borderRadius' => '10px',
                            'headerPadding' => '20px',
                            'contentPadding' => '20px',
                            'titleFontSize' => '16px',
                            'contentFontSize' => '15px',
                            'itemGap' => '12px',
                        ]],
                    ]],
                ],
            ],
            // CTA
            $this->ctaSection(
                'Explore Our Content',
                'While you wait for our response, check out our latest articles and tutorials.',
                'Browse Articles',
                '/blog'
            ),
        ];
    }
}
