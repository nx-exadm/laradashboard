<?php

namespace Modules\Starter26\Database\Seeders;

use App\Models\Post;
use App\Models\Setting;
use Illuminate\Database\Seeder;

class Starter26SettingsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Set homepage ID
        $homePage = Post::where('slug', 'home')
            ->where('post_type', 'page')
            ->first();

        if ($homePage) {
            Setting::firstOrCreate(
                ['option_name' => 'homepage_id'],
                ['option_value' => (string) $homePage->id, 'autoload' => true]
            );
        }

        // Set blog page ID
        $blogPage = Post::where('slug', 'blog')
            ->where('post_type', 'page')
            ->first();

        if ($blogPage) {
            Setting::firstOrCreate(
                ['option_name' => 'blog_page_id'],
                ['option_value' => (string) $blogPage->id, 'autoload' => true]
            );
        }

        // Default settings
        $defaults = [
            'blog_url_prefix' => 'posts',
            'posts_per_page' => '12',
            'footer_description' => 'A modern starter theme built with Livewire, Alpine.js, and Tailwind CSS.',
        ];

        foreach ($defaults as $key => $value) {
            Setting::firstOrCreate(
                ['option_name' => $key],
                ['option_value' => $value, 'autoload' => true]
            );
        }
    }
}
