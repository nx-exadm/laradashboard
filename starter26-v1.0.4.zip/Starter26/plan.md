# Starter26
Starter 26 is the starter theme for Lara Dashboard.

## Features
- Navbar
- Home Page
- About Us Page
- Contact Us Page
- Posts Page
- Single Post Page
- Page
- Category Page
- Tag Page
- Search Page
- Footer
- Responsive Design
- Extendible filter hooks support

## Simplicity
- Follow Livewire wire-click routing
- Blade components
- Tailwind CSS
- Alpine.js
- Follow WordPress like simplified architecture

## Core support
- Maximum functions, stuffs should be added core itself, this module can just call those classes, methods wherever needed

## Design idea
- Follow modern design trends
- Minimalistic design
- Focus on content
- Easy navigation
- Good readability
- Multi lang support ready


## What follow
- In modules/laradashboard, we've already did for laradashboard website, can take idea for frontend for that
- In modules/DocForge also has frontend idea to take

## Styling
`st26` should be its tailwind prefix similar as others.
