/**
 * Starter26 - Frontend Theme JavaScript
 *
 * Uses Alpine.js from Livewire (Livewire 3 bundles Alpine).
 * Do NOT import Alpine separately — it causes "multiple instances" conflicts.
 */

// Wait for Livewire's Alpine to be available, then register components
document.addEventListener('alpine:init', () => {
    const Alpine = window.Alpine;
    if (!Alpine) return;

// Theme toggle functionality
Alpine.data('themeToggle', () => ({
    theme: localStorage.getItem('st26-theme') || 'system',

    get isDark() {
        if (this.theme === 'dark') return true;
        if (this.theme === 'light') return false;
        return window.matchMedia('(prefers-color-scheme: dark)').matches;
    },

    init() {
        this.applyTheme();
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => this.applyTheme());
    },

    applyTheme() {
        if (this.isDark) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    },

    toggleTheme() {
        if (this.theme === 'light') {
            this.theme = 'dark';
        } else if (this.theme === 'dark') {
            this.theme = 'system';
        } else {
            this.theme = 'light';
        }
        localStorage.setItem('st26-theme', this.theme);
        this.applyTheme();
    }
}));

// Mobile navigation functionality
Alpine.data('mobileNav', () => ({
    open: false,

    toggle() {
        this.open = !this.open;
        // Prevent body scroll when menu is open
        document.body.style.overflow = this.open ? 'hidden' : '';
    },

    close() {
        this.open = false;
        document.body.style.overflow = '';
    }
}));

// Search functionality
Alpine.data('searchForm', () => ({
    query: '',
    isSearching: false,

    async search() {
        if (!this.query.trim()) return;
        this.isSearching = true;

        // Navigate to search page with query
        window.location.href = `/search?q=${encodeURIComponent(this.query)}`;
    }
}));

}); // end alpine:init

// Apply theme immediately on page load to prevent flash
(function() {
    const theme = localStorage.getItem('st26-theme') || 'system';
    const isDark = theme === 'dark' || (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
    if (isDark) {
        document.documentElement.classList.add('dark');
    }
})();
