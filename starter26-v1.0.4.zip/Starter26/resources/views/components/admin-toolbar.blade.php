@if(auth()->check() && auth()->user()->hasAnyRole(['Superadmin', 'Admin', 'Editor']))
    <div class="st-admin-toolbar st:fixed st:bottom-0 st:left-0 st:right-0 st:z-50 st:bg-gray-900 st:text-white st:text-sm st:shadow-[0_-2px_10px_rgba(0,0,0,0.15)]"
         x-data="{ open: true }"
         x-show="open"
         x-transition:enter="st:transition st:ease-out st:duration-200"
         x-transition:enter-start="st:translate-y-full"
         x-transition:enter-end="st:translate-y-0">
        <div class="st:flex st:items-center st:justify-between st:px-4 st:h-10">
            {{-- Left side --}}
            <div class="st:flex st:items-center st:gap-3">
                {{-- Dashboard --}}
                <a href="{{ url('/admin') }}" class="st:flex st:items-center st:gap-1.5 st:text-gray-300 st:hover:text-white st:transition-colors">
                    <iconify-icon icon="lucide:layout-dashboard" class="st:text-sm" aria-hidden="true"></iconify-icon>
                    <span class="st:hidden st:sm:inline">{{ __('Dashboard') }}</span>
                </a>

                <span class="st:text-gray-600 st:text-xs">|</span>

                {{-- Edit link injected by each page --}}
                @stack('admin-toolbar-edit')

                {{-- New page --}}
                <a href="{{ url('/admin/posts/page/create') }}" class="st:flex st:items-center st:gap-1.5 st:text-gray-300 st:hover:text-white st:transition-colors">
                    <iconify-icon icon="lucide:plus" class="st:text-sm" aria-hidden="true"></iconify-icon>
                    <span class="st:hidden st:sm:inline">{{ __('New Page') }}</span>
                </a>

                <span class="st:text-gray-600 st:text-xs">|</span>

                {{-- New post --}}
                <a href="{{ url('/admin/posts/post/create') }}" class="st:flex st:items-center st:gap-1.5 st:text-gray-300 st:hover:text-white st:transition-colors">
                    <iconify-icon icon="lucide:file-plus" class="st:text-sm" aria-hidden="true"></iconify-icon>
                    <span class="st:hidden st:sm:inline">{{ __('New Post') }}</span>
                </a>
            </div>

            {{-- Right side --}}
            <div class="st:flex st:items-center st:gap-3">
                <span class="st:text-gray-400 st:hidden st:md:inline">
                    {{ auth()->user()->first_name ?? auth()->user()->name }}
                </span>

                <button @click="open = false" type="button"
                        class="st:p-1 st:text-gray-400 st:hover:text-white st:transition-colors"
                        aria-label="{{ __('Close toolbar') }}">
                    <iconify-icon icon="lucide:x" class="st:text-sm" aria-hidden="true"></iconify-icon>
                </button>
            </div>
        </div>
    </div>
@endif
