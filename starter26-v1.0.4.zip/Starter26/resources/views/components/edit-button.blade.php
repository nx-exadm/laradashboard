@props(['post' => null])

@if($post && auth()->check())
    @can('update', $post)
        <a href="{{ url('/admin/posts/' . ($post->post_type ?? 'page') . '/' . $post->id . '/edit') }}"
           class="st:fixed st:bottom-6 st:right-6 st:z-50 st:flex st:items-center st:gap-2 st:px-4 st:py-2 st:bg-gray-900 st:dark:bg-white st:text-white st:dark:text-gray-900 st:text-sm st:font-medium st:rounded-full st:shadow-lg st:hover:bg-gray-700 st:dark:hover:bg-gray-200 st:transition-colors st:opacity-80 st:hover:opacity-100"
           aria-label="{{ __('Edit this page') }}">
            <iconify-icon icon="lucide:pencil" class="st:text-base" aria-hidden="true"></iconify-icon>
            {{ __('Edit Page') }}
        </a>
    @endcan
@endif
