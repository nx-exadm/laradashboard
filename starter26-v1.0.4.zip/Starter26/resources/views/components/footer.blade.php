<footer class="st-footer st:bg-gray-50 st:dark:bg-gray-900 st:border-t st:border-gray-200 st:dark:border-gray-700" role="contentinfo">
    <div class="st-container st:py-12">
        @php
            $totalCols = 1 + count($footerColumns);
            $lgColClass = match(true) {
                $totalCols >= 4 => 'st:lg:grid-cols-4',
                $totalCols === 3 => 'st:lg:grid-cols-3',
                $totalCols === 2 => 'st:lg:grid-cols-2',
                default => 'st:lg:grid-cols-1',
            };
        @endphp
        <div class="st:grid st:grid-cols-1 st:md:grid-cols-2 {{ $lgColClass }} st:gap-8">
            {{-- Brand --}}
            <div class="st:lg:col-span-1">
                <a wire:navigate href="{{ route('starter26.home') }}" class="st:flex st:items-center st:gap-2 st:mb-4">
                    @if($logoLight || $logoDark)
                        @if($logoLight)
                            <img src="{{ $logoLight }}" alt="{{ $siteName }}" class="st:h-8 st:w-auto st:dark:hidden">
                        @endif
                        @if($logoDark)
                            <img src="{{ $logoDark }}" alt="{{ $siteName }}" class="st:h-8 st:w-auto st:hidden st:dark:block">
                        @elseif($logoLight)
                            <img src="{{ $logoLight }}" alt="{{ $siteName }}" class="st:h-8 st:w-auto st:hidden st:dark:block">
                        @endif
                    @else
                        <iconify-icon icon="lucide:layout-dashboard" class="st:text-2xl st:text-primary" aria-hidden="true"></iconify-icon>
                        <span class="st:text-lg st:font-semibold st:text-gray-900 st:dark:text-white">{{ $siteName }}</span>
                    @endif
                </a>
                <p class="st-footer-text st:text-sm st:text-gray-600 st:dark:text-gray-400 st:mb-4">
                    {{ $footerDescription }}
                </p>
                {{-- Social Links --}}
                @if(count($socialLinks) > 0)
                    <div class="st:flex st:items-center st:gap-3">
                        @foreach($socialLinks as $social)
                            <a href="{{ $social['url'] }}" target="_blank" rel="noopener noreferrer"
                               class="st:p-2 st:text-gray-500 st:hover:text-gray-700 st:dark:text-gray-400 st:dark:hover:text-gray-200 st:rounded-lg st:hover:bg-gray-100 st:dark:hover:bg-gray-800 st:transition-colors"
                               aria-label="{{ $social['label'] }}">
                                <iconify-icon icon="{{ $social['icon'] }}" class="st:text-xl" aria-hidden="true"></iconify-icon>
                            </a>
                        @endforeach
                    </div>
                @endif
            </div>

            {{-- Footer Link Columns --}}
            @foreach($footerColumns as $column)
                <nav aria-label="{{ $column['title'] }}">
                    <h4 class="st:text-sm st:font-semibold st:text-gray-900 st:dark:text-white st:uppercase st:tracking-wider st:mb-4">
                        {{ $column['title'] }}
                    </h4>
                    <ul class="st:space-y-2">
                        @if(!empty($column['isMenu']) && !empty($column['items']))
                            {{-- Core Menu items --}}
                            @foreach($column['items'] as $item)
                                <li>
                                    <a @if(!$item->target_blank) wire:navigate @endif
                                       href="{{ $item->getUrl() }}"
                                       @if($item->target_blank) target="_blank" rel="noopener noreferrer" @endif
                                       class="st:text-sm st:text-gray-600 st:dark:text-gray-400 st:hover:text-primary st:dark:hover:text-primary st:transition-colors">
                                        {{ $item->label }}
                                    </a>
                                </li>
                            @endforeach
                        @elseif(!empty($column['links']))
                            {{-- Fallback array-based links --}}
                            @foreach($column['links'] as $link)
                                <li>
                                    @if(isset($link['route']))
                                        <a wire:navigate href="{{ route($link['route']) }}"
                                           class="st:text-sm st:text-gray-600 st:dark:text-gray-400 st:hover:text-primary st:dark:hover:text-primary st:transition-colors">
                                            {{ $link['label'] }}
                                        </a>
                                    @else
                                        <a href="{{ $link['url'] }}"
                                           @if(str_starts_with($link['url'] ?? '', 'http')) target="_blank" rel="noopener noreferrer" @endif
                                           class="st:text-sm st:text-gray-600 st:dark:text-gray-400 st:hover:text-primary st:dark:hover:text-primary st:transition-colors">
                                            {{ $link['label'] }}
                                        </a>
                                    @endif
                                </li>
                            @endforeach
                        @endif
                    </ul>
                </nav>
            @endforeach
        </div>

        {{-- Bottom Bar --}}
        <div class="st:mt-12 st:pt-8 st:border-t st:border-gray-200 st:dark:border-gray-700">
            <div class="st:flex st:flex-col st:md:flex-row st:items-center st:justify-between st:gap-4">
                <p class="st:text-sm st:text-gray-500 st:dark:text-gray-400">
                    {{ $copyrightText }}
                </p>
                <p class="st:text-sm st:text-gray-500 st:dark:text-gray-400">
                    {{ __('Powered by') }}
                    <a href="https://laradashboard.com" target="_blank" rel="noopener noreferrer"
                       class="st:text-primary st:hover:underline">
                        Lara Dashboard
                    </a>
                </p>
            </div>
        </div>
    </div>
</footer>
