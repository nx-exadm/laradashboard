{{-- Footer Link Columns --}}
@foreach($footerColumns as $column)
    <nav aria-label="{{ $column['title'] }}">
        <h4 class="st:text-sm st:font-semibold st:text-gray-900 st:dark:text-white st:uppercase st:tracking-wider st:mb-4">
            {{ $column['title'] }}
        </h4>

        <ul class="st:space-y-2">
            @if(!empty($column['isMenu']) && !empty($column['items']))
                {{-- Core Menu items --}}
                @foreach($column['items'] as $item)
                    <li>
                        <a
                            @if(!$item->target_blank) wire:navigate @endif
                            href="{{ $item->getUrl() }}"
                            @if($item->target_blank)
                                target="_blank"
                                rel="noopener noreferrer"
                            @endif
                            class="st:text-sm st:text-gray-600 st:dark:text-gray-400 st:hover:text-primary st:dark:hover:text-primary st:transition-colors"
                        >
                            {{ $item->label }}
                        </a>
                    </li>
                @endforeach

            @elseif(!empty($column['links']))
                {{-- Fallback array-based links --}}
                @foreach($column['links'] as $link)
                    <li>
                        @if(isset($link['route']))
                            <a
                                wire:navigate
                                href="{{ route($link['route']) }}"
                                class="st:text-sm st:text-gray-600 st:dark:text-gray-400 st:hover:text-primary st:dark:hover:text-primary st:transition-colors"
                            >
                                {{ $link['label'] }}
                            </a>
                        @else
                            <a
                                href="{{ $link['url'] }}"
                                @if(str_starts_with($link['url'] ?? '', 'http'))
                                    target="_blank"
                                    rel="noopener noreferrer"
                                @endif
                                class="st:text-sm st:text-gray-600 st:dark:text-gray-400 st:hover:text-primary st:dark:hover:text-primary st:transition-colors"
                            >
                                {{ $link['label'] }}
                            </a>
                        @endif
                    </li>
                @endforeach
            @endif
        </ul>
    </nav>
@endforeach
</div>

{{-- Bottom Bar --}}
<div class="st:mt-12 st:pt-8 st:border-t st:border-gray-200 st:dark:border-gray-700">
    <div class="st:flex st:flex-col st:md:flex-row st:items-center st:justify-between st:gap-4">

        {{-- Copyright --}}
        <p class="st:text-sm st:text-gray-500 st:dark:text-gray-400">
            {{ $copyrightText }}
        </p>

        {{-- Powered By --}}
        <p class="st:text-sm st:text-gray-500 st:dark:text-gray-400">
            {{ __('Developed by') }}

            <a
                href="https://www.norielix.com"
                target="_blank"
                rel="noopener noreferrer"
                class="st:text-primary st:hover:underline"
            >
                Norielix Systems
            </a>
        </p>

    </div>
</div>
</div>