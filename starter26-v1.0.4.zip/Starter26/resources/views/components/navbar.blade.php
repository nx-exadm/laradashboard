<header class="st-header st:sticky st:top-0 st:z-50 st:bg-white st:dark:bg-gray-900 st:border-b st:border-gray-200 st:dark:border-gray-700"
        x-data="{
            mobileOpen: false,
            theme: localStorage.getItem('st-theme') || 'system',
            currentUrl: window.location.href,
            isLinkActive(href) {
                if (!href || href === '#') return false;
                return this.currentUrl === href || this.currentUrl === href + '/';
            },
            isGroupActive(childHrefs) {
                return childHrefs.some(href => this.isLinkActive(href));
            }
        }"
        x-init="$watch('theme', value => { localStorage.setItem('st-theme', value); updateTheme(); })"
        x-on:livewire:navigated.window="currentUrl = window.location.href; theme = localStorage.getItem('st-theme') || 'system'">

    <div class="st-container">

        <div class="st:flex st:items-center st:justify-between st:h-16">

            {{-- Logo --}}
            <div class="st:flex st:items-center st:gap-4">

                {{-- Mobile Menu Toggle --}}
                <button
                    @click="mobileOpen = !mobileOpen"
                    type="button"
                    aria-label="{{ __('Toggle navigation menu') }}"
                    :aria-expanded="mobileOpen ? 'true' : 'false'"
                    class="st-mobile-toggle st:p-2 st:text-gray-500 st:hover:text-gray-700 st:dark:text-gray-400 st:dark:hover:text-gray-200 st:rounded-lg st:hover:bg-gray-100 st:dark:hover:bg-gray-800"
                >
                    <iconify-icon
                        x-show="!mobileOpen"
                        icon="lucide:menu"
                        class="st:text-xl"
                        aria-hidden="true"
                    ></iconify-icon>

                    <iconify-icon
                        x-show="mobileOpen"
                        icon="lucide:x"
                        class="st:text-xl"
                        aria-hidden="true"
                        x-cloak
                    ></iconify-icon>
                </button>

                {{-- Norielix Logo --}}
                <a
                    wire:navigate
                    href="{{ route('starter26.home') }}"
                    class="st:flex st:items-center st:gap-3"
                >
                    {{-- Norielix SVG Logo --}}
                    <span class="st:inline-flex st:items-center st:justify-center st:w-9 st:h-9 st:shrink-0">
                        <svg
                            viewBox="0 0 40 40"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            class="st:w-9 st:h-9"
                            aria-hidden="true"
                        >
                            <rect
                                width="40"
                                height="40"
                                rx="8"
                                fill="#1e40af"
                            />

                            <path
                                d="M12 30V10L22 22V10H28V30L18 18V30H12Z"
                                fill="white"
                            />
                        </svg>
                    </span>

                    {{-- Norielix Site Name --}}
                    <span class="st:text-lg st:font-semibold st:text-gray-900 st:dark:text-white">
                        Norielix
                    </span>
                </a>

            </div>

            {{-- Desktop Navigation --}}
            <nav
                class="st-desktop-nav st:items-center st:gap-1"
                aria-label="{{ __('Primary navigation') }}"
            >
                @foreach($menuItems as $item)

                    @if($item instanceof \App\Models\MenuItem)

                        {{-- Core Menu Item --}}
                        @if($item->hasChildren())

                            @php
                                $childHrefs = json_encode(
                                    collect($item->getChildren())
                                        ->map(fn($c) => $c->getUrl())
                                        ->values()
                                        ->all()
                                );
                            @endphp

                            <div
                                x-data="{ open: false }"
                                class="st:relative"
                            >
                                <button
                                    @click="open = !open"
                                    @click.outside="open = false"
                                    @keydown.escape="open = false"
                                    type="button"
                                    aria-haspopup="true"
                                    :aria-expanded="open ? 'true' : 'false'"
                                    class="st-nav-link st:flex st:items-center st:gap-1 st:px-4 st:py-2 st:text-sm st:font-medium st:text-gray-600 st:hover:text-gray-900 st:dark:text-gray-300 st:dark:hover:text-white st:rounded-lg st:hover:bg-gray-100 st:dark:hover:bg-gray-800 st:transition-colors"
                                    :class="isGroupActive({{ $childHrefs }}) && 'st:bg-gray-100 st:dark:bg-gray-800 st:text-gray-900 st:dark:text-white'"
                                >
                                    @if($item->icon)
                                        <iconify-icon
                                            icon="{{ $item->icon }}"
                                            class="st:text-lg"
                                            aria-hidden="true"
                                        ></iconify-icon>
                                    @endif

                                    {{ $item->label }}

                                    <iconify-icon
                                        icon="lucide:chevron-down"
                                        class="st:text-xs st:transition-transform"
                                        :class="{ 'st:rotate-180': open }"
                                        aria-hidden="true"
                                    ></iconify-icon>
                                </button>

                                <div
                                    x-show="open"
                                    x-cloak
                                    x-transition:enter="st:transition st:ease-out st:duration-100"
                                    x-transition:enter-start="st:opacity-0 st:scale-95"
                                    x-transition:enter-end="st:opacity-100 st:scale-100"
                                    x-transition:leave="st:transition st:ease-in st:duration-75"
                                    x-transition:leave-start="st:opacity-100 st:scale-100"
                                    x-transition:leave-end="st:opacity-0 st:scale-95"
                                    class="st:absolute st:top-full st:left-0 st:mt-1 st:w-48 st:bg-white st:dark:bg-gray-800 st:rounded-lg st:shadow-lg st:border st:border-gray-200 st:dark:border-gray-700 st:py-1 st:z-50"
                                >
                                    @foreach($item->getChildren() as $child)

                                        <a
                                            @if(!$child->target_blank) wire:navigate @endif
                                            href="{{ $child->getUrl() }}"
                                            @if($child->target_blank)
                                                target="_blank"
                                                rel="noopener noreferrer"
                                            @endif
                                            :aria-current="isLinkActive('{{ $child->getUrl() }}') ? 'page' : null"
                                            class="st:block st:px-4 st:py-2 st:text-sm st:text-gray-600 st:dark:text-gray-300 st:hover:text-gray-900 st:dark:hover:text-white st:hover:bg-gray-100 st:dark:hover:bg-gray-800 st:transition-colors"
                                            :class="isLinkActive('{{ $child->getUrl() }}') && 'st:bg-gray-50 st:dark:bg-gray-700 st:text-gray-900 st:dark:text-white'"
                                        >
                                            @if($child->icon)
                                                <iconify-icon
                                                    icon="{{ $child->icon }}"
                                                    class="st:text-sm st:mr-2"
                                                    aria-hidden="true"
                                                ></iconify-icon>
                                            @endif

                                            {{ $child->label }}
                                        </a>

                                    @endforeach
                                </div>
                            </div>

                        @else

                            <a
                                @if(!$item->target_blank) wire:navigate @endif
                                href="{{ $item->getUrl() }}"
                                @if($item->target_blank)
                                    target="_blank"
                                    rel="noopener noreferrer"
                                @endif
                                :aria-current="isLinkActive('{{ $item->getUrl() }}') ? 'page' : null"
                                class="st-nav-link st:flex st:items-center st:gap-2 st:px-4 st:py-2 st:text-sm st:font-medium st:text-gray-600 st:hover:text-gray-900 st:dark:text-gray-300 st:dark:hover:text-white st:rounded-lg st:hover:bg-gray-100 st:dark:hover:bg-gray-800 st:transition-colors"
                                :class="isLinkActive('{{ $item->getUrl() }}') && 'st:bg-gray-100 st:dark:bg-gray-800 st:text-gray-900 st:dark:text-white'"
                            >
                                @if($item->icon)
                                    <iconify-icon
                                        icon="{{ $item->icon }}"
                                        class="st:text-lg"
                                        aria-hidden="true"
                                    ></iconify-icon>
                                @endif

                                {{ $item->label }}
                            </a>

                        @endif

                    @else

                        {{-- Fallback array-based nav item --}}
                        @php
                            $fallbackHref = isset($item['route'])
                                ? route($item['route'])
                                : ($item['url'] ?? '#');
                        @endphp

                        <a
                            wire:navigate
                            href="{{ $fallbackHref }}"
                            :aria-current="isLinkActive('{{ $fallbackHref }}') ? 'page' : null"
                            class="st-nav-link st:flex st:items-center st:gap-2 st:px-4 st:py-2 st:text-sm st:font-medium st:text-gray-600 st:hover:text-gray-900 st:dark:text-gray-300 st:dark:hover:text-white st:rounded-lg st:hover:bg-gray-100 st:dark:hover:bg-gray-800 st:transition-colors"
                            :class="isLinkActive('{{ $fallbackHref }}') && 'st:bg-gray-100 st:dark:bg-gray-800 st:text-gray-900 st:dark:text-white'"
                        >
                            {{ $item['label'] }}
                        </a>

                    @endif

                @endforeach
            </nav>

            {{-- Right Side Actions --}}
            <div class="st:flex st:items-center st:gap-2">

                {{-- Search Button --}}
                <a
                    wire:navigate
                    href="{{ route('starter26.search') }}"
                    aria-label="{{ __('Search') }}"
                    class="st:p-2 st:text-gray-500 st:hover:text-gray-700 st:dark:text-gray-400 st:dark:hover:text-gray-200 st:rounded-lg st:hover:bg-gray-100 st:dark:hover:bg-gray-800 st:transition-colors"
                >
                    <iconify-icon
                        icon="lucide:search"
                        class="st:text-xl"
                        aria-hidden="true"
                    ></iconify-icon>
                </a>

                {{-- Theme Toggle --}}
                <button
                    @click="theme = theme === 'light' ? 'dark' : (theme === 'dark' ? 'system' : 'light'); updateTheme();"
                    type="button"
                    class="st:p-2 st:text-gray-500 st:hover:text-gray-700 st:dark:text-gray-400 st:dark:hover:text-gray-200 st:rounded-lg st:hover:bg-gray-100 st:dark:hover:bg-gray-800 st:transition-colors"
                    :aria-label="theme === 'light'
                        ? '{{ __('Switch to dark mode') }}'
                        : (theme === 'dark'
                            ? '{{ __('Switch to system theme') }}'
                            : '{{ __('Switch to light mode') }}')"
                >
                    <iconify-icon
                        x-show="theme === 'light'"
                        icon="lucide:sun"
                        class="st:text-xl"
                        aria-hidden="true"
                    ></iconify-icon>

                    <iconify-icon
                        x-show="theme === 'dark'"
                        icon="lucide:moon"
                        class="st:text-xl"
                        aria-hidden="true"
                        x-cloak
                    ></iconify-icon>

                    <iconify-icon
                        x-show="theme === 'system'"
                        icon="lucide:monitor"
                        class="st:text-xl"
                        aria-hidden="true"
                        x-cloak
                    ></iconify-icon>
                </button>

            </div>

        </div>
    </div>

    {{-- Mobile Menu Overlay --}}
    <div
        @click="mobileOpen = false"
        class="st-mobile-overlay st:fixed st:inset-0 st:z-40 st:bg-gray-900/50"
        :class="{ 'is-open': mobileOpen }"
    ></div>

    {{-- Mobile Navigation --}}
    <nav
        class="st-mobile-nav st:bg-white st:dark:bg-gray-900 st:border-r st:border-gray-200 st:dark:border-gray-700"
        :class="{ 'is-open': mobileOpen }"
        aria-label="{{ __('Mobile navigation') }}"
    >
        <div class="st:flex st:items-center st:justify-between st:h-16 st:px-4 st:border-b st:border-gray-200 st:dark:border-gray-700">

            <span class="st:text-lg st:font-semibold st:text-gray-900 st:dark:text-white">
                {{ __('Menu') }}
            </span>

            <button
                @click="mobileOpen = false"
                type="button"
                aria-label="{{ __('Close menu') }}"
                class="st:p-2 st:text-gray-500 st:hover:text-gray-700 st:dark:text-gray-400"
            >
                <iconify-icon
                    icon="lucide:x"
                    class="st:text-xl"
                    aria-hidden="true"
                ></iconify-icon>
            </button>

        </div>

        <div class="st:p-4 st:space-y-1">

            @foreach($menuItems as $item)

                @if($item instanceof \App\Models\MenuItem)

                    @if($item->hasChildren())

                        @php
                            $mChildHrefs = json_encode(
                                collect($item->getChildren())
                                    ->map(fn($c) => $c->getUrl())
                                    ->values()
                                    ->all()
                            );
                        @endphp

                        <div x-data="{ subOpen: false }">

                            <button
                                @click="subOpen = !subOpen"
                                type="button"
                                :aria-expanded="subOpen ? 'true' : 'false'"
                                class="st:w-full st:flex st:items-center st:justify-between st:px-4 st:py-3 st:text-sm st:font-medium st:text-gray-600 st:dark:text-gray-300 st:hover:text-gray-900 st:dark:hover:text-white st:rounded-lg st:hover:bg-gray-100 st:dark:hover:bg-gray-800 st:transition-colors"
                                :class="isGroupActive({{ $mChildHrefs }}) && 'st:bg-gray-100 st:dark:bg-gray-800 st:text-gray-900 st:dark:text-white'"
                            >
                                <span class="st:flex st:items-center st:gap-3">

                                    @if($item->icon)
                                        <iconify-icon
                                            icon="{{ $item->icon }}"
                                            class="st:text-lg"
                                            aria-hidden="true"
                                        ></iconify-icon>
                                    @endif

                                    {{ $item->label }}

                                </span>

                                <iconify-icon
                                    icon="lucide:chevron-down"
                                    class="st:text-xs st:transition-transform"
                                    :class="{ 'st:rotate-180': subOpen }"
                                    aria-hidden="true"
                                ></iconify-icon>

                            </button>

                            <div
                                x-show="subOpen"
                                x-cloak
                                class="st:pl-8 st:space-y-1 st:mt-1"
                            >

                                @foreach($item->getChildren() as $child)

                                    <a
                                        @if(!$child->target_blank) wire:navigate @endif
                                        href="{{ $child->getUrl() }}"
                                        @click="mobileOpen = false"
                                        @if($child->target_blank)
                                            target="_blank"
                                            rel="noopener noreferrer"
                                        @endif
                                        :aria-current="isLinkActive('{{ $child->getUrl() }}') ? 'page' : null"
                                        class="st:flex st:items-center st:gap-3 st:px-4 st:py-2 st:text-sm st:text-gray-600 st:dark:text-gray-300 st:hover:text-gray-900 st:dark:hover:text-white st:rounded-lg st:hover:bg-gray-100 st:dark:hover:bg-gray-800 st:transition-colors"
                                        :class="isLinkActive('{{ $child->getUrl() }}') && 'st:bg-gray-50 st:dark:bg-gray-700'"
                                    >

                                        @if($child->icon)
                                            <iconify-icon
                                                icon="{{ $child->icon }}"
                                                class="st:text-sm"
                                                aria-hidden="true"
                                            ></iconify-icon>
                                        @endif

                                        {{ $child->label }}

                                    </a>

                                @endforeach

                            </div>
                        </div>

                    @else

                        <a
                            @if(!$item->target_blank) wire:navigate @endif
                            href="{{ $item->getUrl() }}"
                            @click="mobileOpen = false"
                            @if($item->target_blank)
                                target="_blank"
                                rel="noopener noreferrer"
                            @endif
                            :aria-current="isLinkActive('{{ $item->getUrl() }}') ? 'page' : null"
                            class="st:flex st:items-center st:gap-3 st:px-4 st:py-3 st:text-sm st:font-medium st:text-gray-600 st:dark:text-gray-300 st:hover:text-gray-900 st:dark:hover:text-white st:rounded-lg st:hover:bg-gray-100 st:dark:hover:bg-gray-800 st:transition-colors"
                            :class="isLinkActive('{{ $item->getUrl() }}') && 'st:bg-gray-100 st:dark:bg-gray-800 st:text-gray-900 st:dark:text-white'"
                        >

                            @if($item->icon)
                                <iconify-icon
                                    icon="{{ $item->icon }}"
                                    class="st:text-lg"
                                    aria-hidden="true"
                                ></iconify-icon>
                            @endif

                            {{ $item->label }}

                        </a>

                    @endif

                @else

                    {{-- Fallback array-based nav item --}}
                    @php
                        $mFallbackHref = isset($item['route'])
                            ? route($item['route'])
                            : ($item['url'] ?? '#');
                    @endphp

                    <a
                        wire:navigate
                        href="{{ $mFallbackHref }}"
                        @click="mobileOpen = false"
                        :aria-current="isLinkActive('{{ $mFallbackHref }}') ? 'page' : null"
                        class="st:flex st:items-center st:gap-3 st:px-4 st:py-3 st:text-sm st:font-medium st:text-gray-600 st:dark:text-gray-300 st:hover:text-gray-900 st:dark:hover:text-white st:rounded-lg st:hover:bg-gray-100 st:dark:hover:bg-gray-800 st:transition-colors"
                        :class="isLinkActive('{{ $mFallbackHref }}') && 'st:bg-gray-100 st:dark:bg-gray-800 st:text-gray-900 st:dark:text-white'"
                    >

                        @if(isset($item['icon']))
                            <iconify-icon
                                icon="{{ $item['icon'] }}"
                                class="st:text-lg"
                                aria-hidden="true"
                            ></iconify-icon>
                        @endif

                        {{ $item['label'] }}

                    </a>

                @endif

            @endforeach

        </div>
    </nav>

</header>