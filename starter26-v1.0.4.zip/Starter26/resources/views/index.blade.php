<x-starter26::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('starter26.name') !!}</p>
</x-starter26::layouts.master>
