<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="scroll-smooth">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    {{-- SEO Meta, Open Graph, Twitter Card, JSON-LD --}}
    @include('components.seo-head')

    {{-- Fonts --}}
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=inter:400,500,600,700&display=swap" rel="stylesheet" />

    {{-- Apply theme immediately to prevent flash --}}
    <script>
        // Global theme update function
        function updateTheme() {
            const theme = localStorage.getItem('st-theme') || 'system';
            const isDark = theme === 'dark' || (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
            if (isDark) {
                document.documentElement.classList.add('dark');
            } else {
                document.documentElement.classList.remove('dark');
            }
        }
        // Apply on initial load
        updateTheme();
        // Re-apply after Livewire navigation
        document.addEventListener('livewire:navigated', updateTheme);
    </script>

    {{-- Vite CSS & JS --}}
    @vite(['modules/starter26/resources/assets/css/app.css', 'modules/starter26/resources/assets/js/app.js'], 'build-starter26')

    {{-- Iconify for icons --}}
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.3.0/dist/iconify-icon.min.js"></script>

    @livewireStyles

    {{-- Loading indicator style --}}
    <style>
        .st-loading-bar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, #3b82f6, #8b5cf6, #3b82f6);
            background-size: 200% 100%;
            animation: loading-shimmer 1s ease-in-out infinite;
            z-index: 9999;
            opacity: 0;
            transition: opacity 0.2s;
        }
        .st-loading-bar.active { opacity: 1; }
        @keyframes loading-shimmer {
            0% { background-position: 200% 0; }
            100% { background-position: -200% 0; }
        }
    </style>

    @stack('styles')
</head>
<body class="st:bg-white st:dark:bg-gray-900 st:antialiased st:min-h-screen st:flex st:flex-col st:font-sans">
    {{-- Loading indicator --}}
    <div id="st-loading-bar" class="st-loading-bar"></div>
    <script>
        document.addEventListener('livewire:navigate', () => document.getElementById('st-loading-bar')?.classList.add('active'));
        document.addEventListener('livewire:navigated', () => document.getElementById('st-loading-bar')?.classList.remove('active'));
    </script>
    {{-- Skip to content link for accessibility --}}
    <a href="#main-content" class="st:sr-only st:focus:not-sr-only st:focus:absolute st:focus:top-4 st:focus:left-4 st:focus:z-50 st:focus:px-4 st:focus:py-2 st:focus:bg-primary st:focus:text-white st:focus:rounded-lg">
        {{ __('Skip to content') }}
    </a>

    {{-- Navbar --}}
    @persist('navbar')
    <x-starter26::navbar />
    @endpersist

    {{-- Main Content --}}
    <main id="main-content" class="st-main st:flex-1">
        {{ $slot }}
    </main>

    {{-- Footer --}}
    @persist('footer')
    <x-starter26::footer />
    @endpersist

    {{-- Admin Toolbar (core component, context passed via View::share from Livewire pages) --}}
    <x-frontend-admin-toolbar :context-post="$_toolbarPost ?? null" />

    @livewireScripts

    {{-- Speculation Rules API for instant navigation prefetching --}}
    <x-speculation-rules />

    @stack('scripts')
</body>
</html>
