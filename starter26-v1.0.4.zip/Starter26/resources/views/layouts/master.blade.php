<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Starter26 Module - {{ config('app.name', 'Laravel') }}</title>

    <meta name="description" content="{{ $description ?? '' }}">
    <meta name="keywords" content="{{ $keywords ?? '' }}">
    <meta name="author" content="{{ $author ?? '' }}">

    {{-- Favicon --}}
    <link rel="icon" type="image/x-icon" href="https://www.norielix.com/favicon.ico">
    <link rel="shortcut icon" type="image/x-icon" href="https://www.norielix.com/favicon.ico">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    {{-- Vite CSS --}}
    {{-- {{ module_vite('build-starter26', 'resources/assets/sass/app.scss') }} --}}
</head>

<body>
    {{ $slot }}

    {{-- Vite JS --}}
    {{-- {{ module_vite('build-starter26', 'resources/assets/js/app.js') }} --}}
</body>