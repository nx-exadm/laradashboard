<div>
    {{-- Page Builder Content (width/padding from canvasSettings) --}}
    {!! $page->renderContent('page') !!}
</div>
