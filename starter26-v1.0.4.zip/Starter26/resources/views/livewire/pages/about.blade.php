<div>
    {{-- Page Header --}}
    <section class="st-hero st:bg-gradient-to-br st:from-gray-50 st:to-gray-100 st:dark:from-gray-800 st:dark:to-gray-900">
        <div class="st-container">
            <h1 class="st-hero-title">{{ __('About Us') }}</h1>
            <p class="st-hero-subtitle">
                {{ __('Learn more about our mission, our team, and what drives us to create great content.') }}
            </p>
        </div>
    </section>

    {{-- Mission Section --}}
    <section class="st-section st:bg-white st:dark:bg-gray-900">
        <div class="st-container">
            <div class="st:grid st:grid-cols-1 st:lg:grid-cols-2 st:gap-12 st:items-center">
                <div>
                    <h2 class="st:text-2xl st:font-bold st:text-gray-900 st:dark:text-white st:mb-4">
                        {{ __('Our Mission') }}
                    </h2>
                    <p class="st:text-gray-600 st:dark:text-gray-400 st:mb-4 st:leading-relaxed">
                        {{ __('We are dedicated to providing high-quality content and resources to help our community grow and succeed. Our platform is built with love using the latest technologies.') }}
                    </p>
                    <p class="st:text-gray-600 st:dark:text-gray-400 st:leading-relaxed">
                        {{ __('Whether you are looking for tutorials, insights, or inspiration, we have got you covered. Join us on this journey of continuous learning and improvement.') }}
                    </p>
                </div>
                <div class="st:aspect-video st:bg-gradient-to-br st:from-primary/10 st:to-primary/20 st:rounded-xl st:flex st:items-center st:justify-center">
                    <iconify-icon icon="lucide:target" class="st:text-8xl st:text-primary/50"></iconify-icon>
                </div>
            </div>
        </div>
    </section>

    {{-- Stats Section --}}
    <section class="st-section st:bg-gray-50 st:dark:bg-gray-800">
        <div class="st-container">
            <div class="st:grid st:grid-cols-2 st:md:grid-cols-4 st:gap-8">
                @foreach($stats as $stat)
                    <div class="st:text-center">
                        <div class="st:text-4xl st:font-bold st:text-primary st:mb-2">{{ $stat['value'] }}</div>
                        <div class="st:text-gray-600 st:dark:text-gray-400">{{ $stat['label'] }}</div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

    {{-- Team Section --}}
    <section class="st-section st:bg-white st:dark:bg-gray-900">
        <div class="st-container">
            <h2 class="st-section-title">{{ __('Meet Our Team') }}</h2>
            <p class="st-section-subtitle">
                {{ __('The talented people behind our success.') }}
            </p>

            <div class="st:grid st:grid-cols-1 st:md:grid-cols-2 st:lg:grid-cols-3 st:gap-8">
                @foreach($teamMembers as $member)
                    <div class="st-card st:text-center">
                        <div class="st-card-body">
                            @if($member['image'])
                                <img src="{{ $member['image'] }}" alt="{{ $member['name'] }}"
                                     class="st:w-24 st:h-24 st:rounded-full st:mx-auto st:mb-4 st:object-cover">
                            @else
                                <div class="st:w-24 st:h-24 st:rounded-full st:mx-auto st:mb-4 st:bg-gradient-to-br st:from-gray-100 st:to-gray-200 st:dark:from-gray-700 st:dark:to-gray-600 st:flex st:items-center st:justify-center">
                                    <iconify-icon icon="lucide:user" class="st:text-3xl st:text-gray-400"></iconify-icon>
                                </div>
                            @endif
                            <h3 class="st-card-title st:mb-1">{{ $member['name'] }}</h3>
                            <p class="st:text-sm st:text-primary st:font-medium st:mb-3">{{ $member['role'] }}</p>
                            <p class="st-card-text st:text-sm">{{ $member['bio'] }}</p>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

    {{-- Values Section --}}
    <section class="st-section st:bg-gray-50 st:dark:bg-gray-800">
        <div class="st-container">
            <h2 class="st-section-title">{{ __('Our Values') }}</h2>
            <p class="st-section-subtitle">
                {{ __('The principles that guide everything we do.') }}
            </p>

            <div class="st:grid st:grid-cols-1 st:md:grid-cols-3 st:gap-8">
                <div class="st:text-center">
                    <div class="st:w-16 st:h-16 st:rounded-full st:bg-blue-100 st:dark:bg-blue-900/30 st:flex st:items-center st:justify-center st:mx-auto st:mb-4">
                        <iconify-icon icon="lucide:lightbulb" class="st:text-2xl st:text-blue-600 st:dark:text-blue-400"></iconify-icon>
                    </div>
                    <h3 class="st:text-lg st:font-semibold st:text-gray-900 st:dark:text-white st:mb-2">{{ __('Innovation') }}</h3>
                    <p class="st:text-gray-600 st:dark:text-gray-400">
                        {{ __('We constantly explore new ideas and technologies to deliver the best experience.') }}
                    </p>
                </div>
                <div class="st:text-center">
                    <div class="st:w-16 st:h-16 st:rounded-full st:bg-green-100 st:dark:bg-green-900/30 st:flex st:items-center st:justify-center st:mx-auto st:mb-4">
                        <iconify-icon icon="lucide:heart" class="st:text-2xl st:text-green-600 st:dark:text-green-400"></iconify-icon>
                    </div>
                    <h3 class="st:text-lg st:font-semibold st:text-gray-900 st:dark:text-white st:mb-2">{{ __('Quality') }}</h3>
                    <p class="st:text-gray-600 st:dark:text-gray-400">
                        {{ __('We are committed to delivering high-quality content and exceptional user experiences.') }}
                    </p>
                </div>
                <div class="st:text-center">
                    <div class="st:w-16 st:h-16 st:rounded-full st:bg-purple-100 st:dark:bg-purple-900/30 st:flex st:items-center st:justify-center st:mx-auto st:mb-4">
                        <iconify-icon icon="lucide:users" class="st:text-2xl st:text-purple-600 st:dark:text-purple-400"></iconify-icon>
                    </div>
                    <h3 class="st:text-lg st:font-semibold st:text-gray-900 st:dark:text-white st:mb-2">{{ __('Community') }}</h3>
                    <p class="st:text-gray-600 st:dark:text-gray-400">
                        {{ __('We believe in building a supportive community where everyone can learn and grow together.') }}
                    </p>
                </div>
            </div>
        </div>
    </section>
</div>
