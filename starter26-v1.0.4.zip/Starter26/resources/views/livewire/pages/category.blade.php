<div>
    {{-- Page Header --}}
    <section class="st-hero st:bg-gradient-to-br st:from-[#0f172a] st:to-[#1e3a5f] st:py-16">
        <div class="st-container">
            {{-- Breadcrumb --}}
            <nav class="st-breadcrumb st:justify-center st:mb-4">
                <a wire:navigate href="{{ route('starter26.home') }}" class="st:text-slate-400 st:hover:text-white st:transition-colors st:text-sm">
                    {{ __('Home') }}
                </a>
                <iconify-icon icon="lucide:chevron-right" class="st:text-xs st:text-slate-500"></iconify-icon>
                <a wire:navigate href="{{ route('starter26.posts') }}" class="st:text-slate-400 st:hover:text-white st:transition-colors st:text-sm">
                    {{ __('Posts') }}
                </a>
                <iconify-icon icon="lucide:chevron-right" class="st:text-xs st:text-slate-500"></iconify-icon>
                <span class="st:text-white st:text-sm">{{ $category->name }}</span>
            </nav>

            <div class="st:flex st:items-center st:justify-center st:gap-3 st:mb-4">
                <div class="st:w-12 st:h-12 st:rounded-full st:bg-white/10 st:flex st:items-center st:justify-center">
                    <iconify-icon icon="lucide:folder" class="st:text-2xl st:text-blue-400" aria-hidden="true"></iconify-icon>
                </div>
                <h1 class="st:text-4xl st:font-bold st:text-white st:mb-0">{{ $category->name }}</h1>
            </div>

            @if($category->description)
                <p class="st:text-lg st:text-center st:text-slate-400 st:mb-0">{{ $category->description }}</p>
            @else
                <p class="st:text-lg st:text-center st:text-slate-400 st:mb-0">
                    {{ __('Browse all posts in the :category category.', ['category' => $category->name]) }}
                </p>
            @endif
        </div>
    </section>

    {{-- Posts --}}
    <section class="st-section st:bg-white st:dark:bg-gray-900">
        <div class="st-container">
            @if($this->posts && $this->posts->count() > 0)
                <div class="st:grid st:grid-cols-1 st:md:grid-cols-2 st:lg:grid-cols-3 st:gap-6">
                    @foreach($this->posts as $post)
                        <article class="st-card st-post-card" wire:key="post-{{ $post->id }}">
                            @if($post->featured_image)
                                <img src="{{ $post->featured_image }}" alt="{{ $post->title }}" class="st-post-image">
                            @else
                                <div class="st:aspect-video st:bg-gradient-to-br st:from-gray-100 st:to-gray-200 st:dark:from-gray-700 st:dark:to-gray-800 st:flex st:items-center st:justify-center">
                                    <iconify-icon icon="lucide:image" class="st:text-4xl st:text-gray-400"></iconify-icon>
                                </div>
                            @endif
                            <div class="st-card-body">
                                <div class="st-post-meta">
                                    <span class="st:flex st:items-center st:gap-1">
                                        <iconify-icon icon="lucide:calendar"></iconify-icon>
                                        {{ $post->created_at->format('M d, Y') }}
                                    </span>
                                </div>
                                <h2 class="st-post-title">
                                    <a wire:navigate href="{{ route('starter26.post', $post->slug) }}">
                                        {{ $post->title }}
                                    </a>
                                </h2>
                                <p class="st-post-excerpt">
                                    {{ Str::limit(strip_tags($post->content), 120) }}
                                </p>
                                <a wire:navigate href="{{ route('starter26.post', $post->slug) }}"
                                   class="st:inline-flex st:items-center st:gap-1 st:mt-4 st:text-sm st:font-medium st:text-primary st:hover:underline">
                                    {{ __('Read More') }}
                                    <iconify-icon icon="lucide:arrow-right"></iconify-icon>
                                </a>
                            </div>
                        </article>
                    @endforeach
                </div>

                {{-- Pagination --}}
                @if($this->posts->hasPages())
                    <nav class="st:mt-8 st:flex st:items-center st:justify-center st:gap-2">
                        @if($this->posts->onFirstPage())
                            <span class="st:px-4 st:py-2 st:text-sm st:text-gray-400 st:bg-gray-100 st:dark:bg-gray-800 st:rounded-lg st:cursor-not-allowed">{{ __('Previous') }}</span>
                        @else
                            <button wire:click="previousPage" class="st:px-4 st:py-2 st:text-sm st:text-gray-700 st:dark:text-gray-300 st:bg-white st:dark:bg-gray-800 st:border st:border-gray-300 st:dark:border-gray-600 st:rounded-lg st:hover:bg-gray-50 st:dark:hover:bg-gray-700 st:transition-colors">{{ __('Previous') }}</button>
                        @endif
                        <span class="st:px-4 st:py-2 st:text-sm st:text-gray-600 st:dark:text-gray-400">{{ __('Page :current of :last', ['current' => $this->posts->currentPage(), 'last' => $this->posts->lastPage()]) }}</span>
                        @if($this->posts->hasMorePages())
                            <button wire:click="nextPage" class="st:px-4 st:py-2 st:text-sm st:text-gray-700 st:dark:text-gray-300 st:bg-white st:dark:bg-gray-800 st:border st:border-gray-300 st:dark:border-gray-600 st:rounded-lg st:hover:bg-gray-50 st:dark:hover:bg-gray-700 st:transition-colors">{{ __('Next') }}</button>
                        @else
                            <span class="st:px-4 st:py-2 st:text-sm st:text-gray-400 st:bg-gray-100 st:dark:bg-gray-800 st:rounded-lg st:cursor-not-allowed">{{ __('Next') }}</span>
                        @endif
                    </nav>
                @endif
            @else
                {{-- Empty State --}}
                <div class="st:text-center st:py-16">
                    <div class="st:w-20 st:h-20 st:mx-auto st:mb-6 st:rounded-full st:bg-gray-100 st:dark:bg-gray-800 st:flex st:items-center st:justify-center">
                        <iconify-icon icon="lucide:file-x" class="st:text-4xl st:text-gray-400"></iconify-icon>
                    </div>
                    <h2 class="st:text-xl st:font-semibold st:text-gray-900 st:dark:text-white st:mb-2">
                        {{ __('No Posts in This Category') }}
                    </h2>
                    <p class="st:text-gray-500 st:dark:text-gray-400 st:mb-6">
                        {{ __('Check back later for new content in this category.') }}
                    </p>
                    <a wire:navigate href="{{ route('starter26.posts') }}" class="st-btn st-btn-primary">
                        {{ __('View All Posts') }}
                    </a>
                </div>
            @endif
        </div>
    </section>
</div>
