<div>
    @if($page)
        {{-- Block-Based Homepage --}}
        {{-- Keep homepage content inside the same wrapper used by normal pages.
             This enables Starter26's dark-mode content overrides on the root URL (/). --}}
        <div class="st-page-content">
            {!! \Modules\Starter26\Support\ContentSanitizer::clean($page->renderContent('page')) !!}
        </div>
    @else
        {{-- Unconfigured State --}}
        <section class="st-section st:bg-white st:dark:bg-gray-900">
            <div class="st-container st:text-center st:py-20">
                <div class="st:max-w-lg st:mx-auto">
                    <iconify-icon icon="lucide:layout-dashboard" class="st:text-6xl st:text-gray-300 st:dark:text-gray-600 st:mb-6" aria-hidden="true"></iconify-icon>
                    <h1 class="st:text-2xl st:font-bold st:text-gray-900 st:dark:text-white st:mb-4">
                        {{ __('Welcome to') }} {{ config('app.name') }}
                    </h1>
                    <p class="st:text-gray-500 st:dark:text-gray-400 st:mb-6">
                        {{ __('Create a page with slug "home" in the admin panel and set it as your homepage in Settings > Starter26 Theme.') }}
                    </p>
                </div>
            </div>
        </section>
    @endif
</div>
