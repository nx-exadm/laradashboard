<div>

    @if($page)

        {{-- Block-Based Homepage --}}
        <div class="st-page-content">
            {!! $page->renderContent('page') !!}
        </div>

    @else

        {{-- Unconfigured State --}}
        <section class="st-section st:bg-white st:dark:bg-gray-900">

            <div class="st-container st:text-center st:py-20">

                <div class="st:max-w-lg st:mx-auto">

                    <iconify-icon
                        icon="lucide:layout-dashboard"
                        class="st:text-6xl st:text-gray-300 st:dark:text-gray-600 st:mb-6"
                        aria-hidden="true"
                    ></iconify-icon>

                    <h1 class="st:text-2xl st:font-bold st:text-gray-900 st:dark:text-white st:mb-4">
                        {{ __('Welcome to') }} {{ config('app.name') }}
                    </h1>

                    <p class="st:text-gray-500 st:dark:text-gray-400 st:mb-6">
                        {{ __('Create a page with slug "home" in the admin panel and set it as your homepage in Settings > Starter26 Theme.') }}
                    </p>

                </div>

            </div>

        </section>

    @endif

</div>

{{-- Admin-entered content: Light/Dark mode support --}}
<style>
    /*
     * Default / Light mode
     */
    .st-page-content {
        color: #111827;
    }

    /*
     * Dark mode
     */
    .dark .st-page-content {
        color: #f9fafb;
    }

    /*
     * Make normal text inherit the theme color.
     * This prevents editor-generated text from remaining black.
     */
    .st-page-content p,
    .st-page-content li,
    .st-page-content blockquote,
    .st-page-content span,
    .st-page-content div {
        color: inherit;
    }

    /*
     * Admin editors sometimes save an inline color such as:
     *
     * style="color: #000000"
     *
     * Override those colors in Dark mode.
     */
    .dark .st-page-content [style*="color"] {
        color: #f9fafb !important;
    }

    /*
     * Links remain visually identifiable.
     */
    .st-page-content a {
        color: #1e40af;
    }

    .dark .st-page-content a {
        color: #93c5fd !important;
    }

    /*
     * Headings
     */
    .st-page-content h1,
    .st-page-content h2,
    .st-page-content h3,
    .st-page-content h4,
    .st-page-content h5,
    .st-page-content h6 {
        color: #111827;
    }

    .dark .st-page-content h1,
    .dark .st-page-content h2,
    .dark .st-page-content h3,
    .dark .st-page-content h4,
    .dark .st-page-content h5,
    .dark .st-page-content h6 {
        color: #ffffff;
    }

    /*
     * Tables
     */
    .st-page-content th,
    .st-page-content td {
        color: inherit;
    }

    /*
     * Blockquotes
     */
    .st-page-content blockquote {
        color: inherit;
    }
</style>