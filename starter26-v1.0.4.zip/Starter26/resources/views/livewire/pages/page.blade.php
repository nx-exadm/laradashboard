<div>
    @if($page->design_json && count($page->design_json) > 0)
        {{-- Page Builder Content (Full-width support, width/padding from canvasSettings) --}}
        {!! $page->renderContent('page') !!}
    @else
        {{-- Traditional Page Content --}}
        {{-- Page Header --}}
        <section class="st-hero st:bg-gradient-to-br st:from-gray-50 st:to-gray-100 st:dark:from-gray-800 st:dark:to-gray-900 st:py-12">
            <div class="st-container">
                {{-- Breadcrumb --}}
                <nav class="st-breadcrumb st:justify-center st:mb-4">
                    <a wire:navigate href="{{ route('starter26.home') }}" class="st-breadcrumb-link">
                        {{ __('Home') }}
                    </a>
                    <iconify-icon icon="lucide:chevron-right" class="st:text-xs"></iconify-icon>
                    <span class="st-breadcrumb-current">{{ $page->title }}</span>
                </nav>

                <h1 class="st-hero-title">{{ $page->title }}</h1>
            </div>
        </section>

        {{-- Page Content --}}
        <section class="st-section st:bg-white st:dark:bg-gray-900">
            <div class="st-container">
                <div class="st:max-w-3xl st:mx-auto">
                    <div class="st-prose">
                        {!! $page->content !!}
                    </div>
                </div>
            </div>
        </section>
    @endif
</div>
