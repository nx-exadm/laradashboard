<div>
    {{-- Block-based header from blog page --}}
    @if($blogPage)
        {!! $blogPage->renderContent('page') !!}
    @endif

    {{-- Filters & Content --}}
    <section class="st-section st:bg-white st:dark:bg-gray-900 st:py-8" aria-label="{{ __('Blog posts') }}">
        <div class="st-container">
            {{-- Filters --}}
            <div class="st:flex st:flex-col st:md:flex-row st:gap-4 st:mb-8">
                {{-- Search --}}
                <div class="st:flex-1">
                    <div class="st-search-form">
                        <iconify-icon icon="lucide:search" class="st-search-icon" aria-hidden="true"></iconify-icon>
                        <input type="text" wire:model.live.debounce.300ms="search"
                               class="st-input st-search-input"
                               placeholder="{{ __('Search posts...') }}"
                               aria-label="{{ __('Search posts') }}">
                    </div>
                </div>

                {{-- Category Filter --}}
                @if(count($categories) > 0)
                    <div class="st:w-full st:md:w-48">
                        <label for="category-filter" class="st:sr-only">{{ __('Filter by category') }}</label>
                        <select wire:model.live="category" id="category-filter" class="st-input">
                            <option value="">{{ __('All Categories') }}</option>
                            @foreach($categories as $slug => $name)
                                <option value="{{ $slug }}">{{ $name }}</option>
                            @endforeach
                        </select>
                    </div>
                @endif

                {{-- Sort Filter --}}
                <div class="st:w-full st:md:w-40">
                    <label for="sort-filter" class="st:sr-only">{{ __('Sort posts') }}</label>
                    <select wire:model.live="sort" id="sort-filter" class="st-input">
                        <option value="latest">{{ __('Latest') }}</option>
                        <option value="oldest">{{ __('Oldest') }}</option>
                        <option value="title">{{ __('Title A-Z') }}</option>
                    </select>
                </div>

                {{-- Clear Filters --}}
                @if($search || $category || $sort !== 'latest')
                    <button wire:click="clearFilters" class="st-btn st-btn-outline st:shrink-0">
                        <iconify-icon icon="lucide:x" aria-hidden="true"></iconify-icon>
                        {{ __('Clear') }}
                    </button>
                @endif
            </div>

            {{-- Posts Grid --}}
            @if($this->posts && $this->posts->count() > 0)
                <div class="st:grid st:grid-cols-1 st:md:grid-cols-2 st:lg:grid-cols-3 st:gap-6">
                    @foreach($this->posts as $post)
                        <article class="st-card st-post-card" wire:key="post-{{ $post->id }}">
                            @if($post->featured_image)
                                <img src="{{ $post->featured_image }}" alt="{{ $post->title }}" class="st-post-image">
                            @else
                                <div class="st:aspect-video st:bg-gradient-to-br st:from-gray-100 st:to-gray-200 st:dark:from-gray-700 st:dark:to-gray-800 st:flex st:items-center st:justify-center">
                                    <iconify-icon icon="lucide:image" class="st:text-4xl st:text-gray-400" aria-hidden="true"></iconify-icon>
                                </div>
                            @endif
                            <div class="st-card-body">
                                <div class="st-post-meta">
                                    <span class="st:flex st:items-center st:gap-1">
                                        <iconify-icon icon="lucide:calendar" aria-hidden="true"></iconify-icon>
                                        <time datetime="{{ $post->created_at->toISOString() }}">{{ $post->created_at->format('M d, Y') }}</time>
                                    </span>
                                    @if($post->terms?->where('taxonomy', 'category')->first())
                                        <span class="st-category">
                                            {{ $post->terms->where('taxonomy', 'category')->first()->name }}
                                        </span>
                                    @endif
                                </div>
                                <h2 class="st-post-title">
                                    <a wire:navigate href="{{ route('starter26.post', $post->slug) }}">
                                        {{ $post->title }}
                                    </a>
                                </h2>
                                <p class="st-post-excerpt">
                                    {{ Str::limit(strip_tags($post->content), 120) }}
                                </p>
                                <a wire:navigate href="{{ route('starter26.post', $post->slug) }}"
                                   class="st:inline-flex st:items-center st:gap-1 st:mt-4 st:text-sm st:font-medium st:text-primary st:hover:underline">
                                    {{ __('Read More') }}
                                    <iconify-icon icon="lucide:arrow-right" aria-hidden="true"></iconify-icon>
                                </a>
                            </div>
                        </article>
                    @endforeach
                </div>

                {{-- Pagination --}}
                @if($this->posts->hasPages())
                    <nav class="st:mt-8 st:flex st:items-center st:justify-center st:gap-2" aria-label="{{ __('Posts pagination') }}">
                        {{-- Previous --}}
                        @if($this->posts->onFirstPage())
                            <span class="st:px-4 st:py-2 st:text-sm st:text-gray-400 st:bg-gray-100 st:dark:bg-gray-800 st:rounded-lg st:cursor-not-allowed" aria-disabled="true">
                                {{ __('Previous') }}
                            </span>
                        @else
                            <button wire:click="previousPage" class="st:px-4 st:py-2 st:text-sm st:text-gray-700 st:dark:text-gray-300 st:bg-white st:dark:bg-gray-800 st:border st:border-gray-300 st:dark:border-gray-600 st:rounded-lg st:hover:bg-gray-50 st:dark:hover:bg-gray-700 st:transition-colors">
                                {{ __('Previous') }}
                            </button>
                        @endif

                        {{-- Page Info --}}
                        <span class="st:px-4 st:py-2 st:text-sm st:text-gray-600 st:dark:text-gray-400">
                            {{ __('Page :current of :last', ['current' => $this->posts->currentPage(), 'last' => $this->posts->lastPage()]) }}
                        </span>

                        {{-- Next --}}
                        @if($this->posts->hasMorePages())
                            <button wire:click="nextPage" class="st:px-4 st:py-2 st:text-sm st:text-gray-700 st:dark:text-gray-300 st:bg-white st:dark:bg-gray-800 st:border st:border-gray-300 st:dark:border-gray-600 st:rounded-lg st:hover:bg-gray-50 st:dark:hover:bg-gray-700 st:transition-colors">
                                {{ __('Next') }}
                            </button>
                        @else
                            <span class="st:px-4 st:py-2 st:text-sm st:text-gray-400 st:bg-gray-100 st:dark:bg-gray-800 st:rounded-lg st:cursor-not-allowed" aria-disabled="true">
                                {{ __('Next') }}
                            </span>
                        @endif
                    </nav>
                @endif
            @else
                {{-- Empty State --}}
                <div class="st:text-center st:py-16">
                    <div class="st:w-20 st:h-20 st:mx-auto st:mb-6 st:rounded-full st:bg-gray-100 st:dark:bg-gray-800 st:flex st:items-center st:justify-center">
                        <iconify-icon icon="lucide:file-x" class="st:text-4xl st:text-gray-400" aria-hidden="true"></iconify-icon>
                    </div>
                    <h2 class="st:text-xl st:font-semibold st:text-gray-900 st:dark:text-white st:mb-2">
                        {{ __('No Posts Found') }}
                    </h2>
                    <p class="st:text-gray-500 st:dark:text-gray-400 st:mb-6">
                        @if($search || $category)
                            {{ __('Try adjusting your search or filter criteria.') }}
                        @else
                            {{ __('Check back later for new content.') }}
                        @endif
                    </p>
                    @if($search || $category)
                        <button wire:click="clearFilters" class="st-btn st-btn-primary">
                            {{ __('Clear Filters') }}
                        </button>
                    @endif
                </div>
            @endif
        </div>
    </section>
</div>
