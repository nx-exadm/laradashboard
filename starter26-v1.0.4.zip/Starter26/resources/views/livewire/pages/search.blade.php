{{-- Results --}}
<section class="st-section st:bg-white st:dark:bg-gray-900">
    <div class="st-container">

        @if($query)

            @if($this->results && $this->results->count() > 0)

                {{-- Results Count --}}
                <div class="st:mb-6">
                    <p class="st:text-gray-600 st:dark:text-gray-400">
                        {{ trans_choice(
                            ':count result found|:count results found',
                            $this->results->total(),
                            ['count' => $this->results->total()]
                        ) }}

                        {{ __('for') }}

                        "<span class="st:font-semibold st:text-gray-900 st:dark:text-white">{{ $query }}</span>"
                    </p>
                </div>

                {{-- Page Results --}}
                <div class="st:grid st:grid-cols-1 st:md:grid-cols-2 st:lg:grid-cols-3 st:gap-6">

                    @foreach($this->results as $page)

                        <article
                            class="st-card st:h-full st:flex st:flex-col st:transition-all st:duration-200 st:hover:-translate-y-1 st:hover:shadow-lg"
                            wire:key="search-page-{{ $page->id }}"
                        >

                            <div class="st-card-body st:flex st:flex-col st:h-full">

                                {{-- Page Name --}}
                                <h2 class="st:text-xl st:font-semibold st:text-gray-900 st:dark:text-white st:mb-3">
                                    <a
                                        wire:navigate
                                        href="{{ route('starter26.page', $page->slug) }}"
                                        class="st:hover:text-primary st:transition-colors"
                                    >
                                        {{ $page->title }}
                                    </a>
                                </h2>

                                {{-- Meta Description --}}
                                @if(filled($page->meta_description ?? null))

                                    <p class="st:text-gray-600 st:dark:text-gray-400 st:leading-relaxed st:flex-1">
                                        {{ $page->meta_description }}
                                    </p>

                                @else

                                    <p class="st:text-gray-500 st:dark:text-gray-400 st:italic st:flex-1">
                                        {{ __('No description available.') }}
                                    </p>

                                @endif

                                {{-- View Page --}}
                                <div class="st:mt-5">
                                    <a
                                        wire:navigate
                                        href="{{ route('starter26.page', $page->slug) }}"
                                        class="st:inline-flex st:items-center st:gap-1 st:text-sm st:font-medium st:text-primary st:hover:underline"
                                    >
                                        {{ __('View Page') }}
                                        <iconify-icon
                                            icon="lucide:arrow-right"
                                            aria-hidden="true"
                                        ></iconify-icon>
                                    </a>
                                </div>

                            </div>

                        </article>

                    @endforeach

                </div>

                {{-- Pagination --}}
                @if($this->results->hasPages())

                    <nav
                        class="st:mt-8 st:flex st:items-center st:justify-center st:gap-2"
                        aria-label="{{ __('Search results pagination') }}"
                    >

                        {{-- Previous --}}
                        @if($this->results->onFirstPage())

                            <span
                                class="st:px-4 st:py-2 st:text-sm st:text-gray-400 st:bg-gray-100 st:dark:bg-gray-800 st:rounded-lg st:cursor-not-allowed"
                            >
                                {{ __('Previous') }}
                            </span>

                        @else

                            <button
                                type="button"
                                wire:click="previousPage"
                                class="st:px-4 st:py-2 st:text-sm st:text-gray-700 st:dark:text-gray-300 st:bg-white st:dark:bg-gray-800 st:border st:border-gray-300 st:dark:border-gray-600 st:rounded-lg st:hover:bg-gray-50 st:dark:hover:bg-gray-700 st:transition-colors"
                            >
                                {{ __('Previous') }}
                            </button>

                        @endif

                        {{-- Current Page --}}
                        <span
                            class="st:px-4 st:py-2 st:text-sm st:text-gray-600 st:dark:text-gray-400"
                        >
                            {{ __('Page :current of :last', [
                                'current' => $this->results->currentPage(),
                                'last' => $this->results->lastPage()
                            ]) }}
                        </span>

                        {{-- Next --}}
                        @if($this->results->hasMorePages())

                            <button
                                type="button"
                                wire:click="nextPage"
                                class="st:px-4 st:py-2 st:text-sm st:text-gray-700 st:dark:text-gray-300 st:bg-white st:dark:bg-gray-800 st:border st:border-gray-300 st:dark:border-gray-600 st:rounded-lg st:hover:bg-gray-50 st:dark:hover:bg-gray-700 st:transition-colors"
                            >
                                {{ __('Next') }}
                            </button>

                        @else

                            <span
                                class="st:px-4 st:py-2 st:text-sm st:text-gray-400 st:bg-gray-100 st:dark:bg-gray-800 st:rounded-lg st:cursor-not-allowed"
                            >
                                {{ __('Next') }}
                            </span>

                        @endif

                    </nav>

                @endif

            @else

                {{-- No Results --}}
                <div class="st:text-center st:py-16">

                    <div class="st:w-20 st:h-20 st:mx-auto st:mb-6 st:rounded-full st:bg-gray-100 st:dark:bg-gray-800 st:flex st:items-center st:justify-center">
                        <iconify-icon
                            icon="lucide:search-x"
                            class="st:text-4xl st:text-gray-400"
                            aria-hidden="true"
                        ></iconify-icon>
                    </div>

                    <h2 class="st:text-xl st:font-semibold st:text-gray-900 st:dark:text-white st:mb-2">
                        {{ __('No Results Found') }}
                    </h2>

                    <p class="st:text-gray-500 st:dark:text-gray-400 st:mb-6">
                        {{ __('We could not find any pages matching your search.') }}
                    </p>

                    <p class="st:text-gray-500 st:dark:text-gray-400 st:text-sm">
                        {{ __('Try different keywords or browse our') }}

                        <a
                            wire:navigate
                            href="{{ route('starter26.posts') }}"
                            class="st:text-primary st:hover:underline"
                        >
                            {{ __('latest posts') }}
                        </a>.
                    </p>

                </div>

            @endif

        @else

            {{-- Initial State --}}
            <div class="st:text-center st:py-16">

                <div class="st:w-20 st:h-20 st:mx-auto st:mb-6 st:rounded-full st:bg-gray-100 st:dark:bg-gray-800 st:flex st:items-center st:justify-center">
                    <iconify-icon
                        icon="lucide:search"
                        class="st:text-4xl st:text-gray-400"
                        aria-hidden="true"
                    ></iconify-icon>
                </div>

                <h2 class="st:text-xl st:font-semibold st:text-gray-900 st:dark:text-white st:mb-2">
                    {{ __('Start Searching') }}
                </h2>

                <p class="st:text-gray-500 st:dark:text-gray-400">
                    {{ __('Type in the search box above to find pages.') }}
                </p>

            </div>

        @endif

    </div>
</section>