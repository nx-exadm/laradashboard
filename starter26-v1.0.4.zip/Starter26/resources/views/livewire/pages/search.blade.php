<div>
    {{-- Page Header --}}
    <section class="st-hero st:bg-gradient-to-br st:from-[#0f172a] st:to-[#1e3a5f] st:py-16">
        <div class="st-container">
            <h1 class="st:text-4xl st:font-bold st:text-center st:text-white st:mb-4">{{ __('Search') }}</h1>
            <p class="st:text-lg st:text-center st:text-slate-400 st:mb-0">
                {{ __('Find articles, tutorials, and more.') }}
            </p>

            {{-- Search Form --}}
            <div class="st:max-w-2xl st:mx-auto st:mt-8">
                <div class="st:relative">
                    <iconify-icon icon="lucide:search" class="st:absolute st:left-4 st:top-1/2 st:-translate-y-1/2 st:text-xl st:text-gray-400"></iconify-icon>
                    <input type="text" wire:model.live.debounce.300ms="query"
                           class="st-input st:pl-12 st:pr-12 st:py-4 st:text-lg"
                           placeholder="{{ __('Type to search...') }}"
                           autofocus>
                    @if($query)
                        <button wire:click="clearSearch"
                                class="st:absolute st:right-4 st:top-1/2 st:-translate-y-1/2 st:p-1 st:text-gray-400 st:hover:text-gray-600 st:dark:hover:text-gray-200">
                            <iconify-icon icon="lucide:x" class="st:text-xl"></iconify-icon>
                        </button>
                    @endif
                </div>
            </div>
        </div>
    </section>

    {{-- Results --}}
    <section class="st-section st:bg-white st:dark:bg-gray-900">
        <div class="st-container">
            @if($query)
                @if($this->results && $this->results->count() > 0)
                    <div class="st:mb-6">
                        <p class="st:text-gray-600 st:dark:text-gray-400">
                            {{ trans_choice(':count result found|:count results found', $this->results->total(), ['count' => $this->results->total()]) }}
                            {{ __('for') }} "<span class="st:font-semibold st:text-gray-900 st:dark:text-white">{{ $query }}</span>"
                        </p>
                    </div>

                    <div class="st:grid st:grid-cols-1 st:md:grid-cols-2 st:lg:grid-cols-3 st:gap-6">
                        @foreach($this->results as $post)
                            <article class="st-card st-post-card" wire:key="result-{{ $post->id }}">
                                @if($post->featured_image)
                                    <img src="{{ $post->featured_image }}" alt="{{ $post->title }}" class="st-post-image">
                                @else
                                    <div class="st:aspect-video st:bg-gradient-to-br st:from-gray-100 st:to-gray-200 st:dark:from-gray-700 st:dark:to-gray-800 st:flex st:items-center st:justify-center">
                                        <iconify-icon icon="lucide:image" class="st:text-4xl st:text-gray-400"></iconify-icon>
                                    </div>
                                @endif
                                <div class="st-card-body">
                                    <div class="st-post-meta">
                                        <span class="st:flex st:items-center st:gap-1">
                                            <iconify-icon icon="lucide:calendar"></iconify-icon>
                                            {{ $post->created_at->format('M d, Y') }}
                                        </span>
                                    </div>
                                    <h2 class="st-post-title">
                                        <a wire:navigate href="{{ route('starter26.post', $post->slug) }}">
                                            {{ $post->title }}
                                        </a>
                                    </h2>
                                    <p class="st-post-excerpt">
                                        {{ Str::limit(strip_tags($post->content), 120) }}
                                    </p>
                                    <a wire:navigate href="{{ route('starter26.post', $post->slug) }}"
                                       class="st:inline-flex st:items-center st:gap-1 st:mt-4 st:text-sm st:font-medium st:text-primary st:hover:underline">
                                        {{ __('Read More') }}
                                        <iconify-icon icon="lucide:arrow-right"></iconify-icon>
                                    </a>
                                </div>
                            </article>
                        @endforeach
                    </div>

                    {{-- Pagination --}}
                    @if($this->results->hasPages())
                        <nav class="st:mt-8 st:flex st:items-center st:justify-center st:gap-2">
                            @if($this->results->onFirstPage())
                                <span class="st:px-4 st:py-2 st:text-sm st:text-gray-400 st:bg-gray-100 st:dark:bg-gray-800 st:rounded-lg st:cursor-not-allowed">{{ __('Previous') }}</span>
                            @else
                                <button wire:click="previousPage" class="st:px-4 st:py-2 st:text-sm st:text-gray-700 st:dark:text-gray-300 st:bg-white st:dark:bg-gray-800 st:border st:border-gray-300 st:dark:border-gray-600 st:rounded-lg st:hover:bg-gray-50 st:dark:hover:bg-gray-700 st:transition-colors">{{ __('Previous') }}</button>
                            @endif
                            <span class="st:px-4 st:py-2 st:text-sm st:text-gray-600 st:dark:text-gray-400">{{ __('Page :current of :last', ['current' => $this->results->currentPage(), 'last' => $this->results->lastPage()]) }}</span>
                            @if($this->results->hasMorePages())
                                <button wire:click="nextPage" class="st:px-4 st:py-2 st:text-sm st:text-gray-700 st:dark:text-gray-300 st:bg-white st:dark:bg-gray-800 st:border st:border-gray-300 st:dark:border-gray-600 st:rounded-lg st:hover:bg-gray-50 st:dark:hover:bg-gray-700 st:transition-colors">{{ __('Next') }}</button>
                            @else
                                <span class="st:px-4 st:py-2 st:text-sm st:text-gray-400 st:bg-gray-100 st:dark:bg-gray-800 st:rounded-lg st:cursor-not-allowed">{{ __('Next') }}</span>
                            @endif
                        </nav>
                    @endif
                @else
                    {{-- No Results --}}
                    <div class="st:text-center st:py-16">
                        <div class="st:w-20 st:h-20 st:mx-auto st:mb-6 st:rounded-full st:bg-gray-100 st:dark:bg-gray-800 st:flex st:items-center st:justify-center">
                            <iconify-icon icon="lucide:search-x" class="st:text-4xl st:text-gray-400"></iconify-icon>
                        </div>
                        <h2 class="st:text-xl st:font-semibold st:text-gray-900 st:dark:text-white st:mb-2">
                            {{ __('No Results Found') }}
                        </h2>
                        <p class="st:text-gray-500 st:dark:text-gray-400 st:mb-6">
                            {{ __('We could not find any posts matching your search.') }}
                        </p>
                        <p class="st:text-gray-500 st:dark:text-gray-400 st:text-sm">
                            {{ __('Try different keywords or browse our') }}
                            <a wire:navigate href="{{ route('starter26.posts') }}" class="st:text-primary st:hover:underline">
                                {{ __('latest posts') }}
                            </a>.
                        </p>
                    </div>
                @endif
            @else
                {{-- Initial State --}}
                <div class="st:text-center st:py-16">
                    <div class="st:w-20 st:h-20 st:mx-auto st:mb-6 st:rounded-full st:bg-gray-100 st:dark:bg-gray-800 st:flex st:items-center st:justify-center">
                        <iconify-icon icon="lucide:search" class="st:text-4xl st:text-gray-400"></iconify-icon>
                    </div>
                    <h2 class="st:text-xl st:font-semibold st:text-gray-900 st:dark:text-white st:mb-2">
                        {{ __('Start Searching') }}
                    </h2>
                    <p class="st:text-gray-500 st:dark:text-gray-400">
                        {{ __('Type in the search box above to find posts.') }}
                    </p>
                </div>
            @endif
        </div>
    </section>
</div>
