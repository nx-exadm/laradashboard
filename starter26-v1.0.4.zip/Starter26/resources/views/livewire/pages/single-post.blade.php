<div>

    {{-- Article --}}
    <article class="st:bg-white st:dark:bg-gray-900">

        {{-- Featured Image --}}
        @if($post->featured_image)
            <div class="st:w-full st:aspect-[21/9] st:bg-gray-100 st:dark:bg-gray-800">
                <img
                    src="{{ $post->featured_image }}"
                    alt="{{ $post->title }}"
                    class="st:w-full st:h-full st:object-cover"
                >
            </div>
        @endif


        {{-- Article Content --}}
        <div class="st-container st:py-12">

            <div class="st:max-w-3xl st:mx-auto">

                {{-- Breadcrumb --}}
                <nav class="st-breadcrumb st:mb-8">

                    <a
                        wire:navigate
                        href="{{ route('starter26.home') }}"
                        class="st-breadcrumb-link"
                    >
                        {{ __('Home') }}
                    </a>

                    <iconify-icon
                        icon="lucide:chevron-right"
                        class="st:text-xs"
                    ></iconify-icon>

                    <a
                        wire:navigate
                        href="{{ route('starter26.posts') }}"
                        class="st-breadcrumb-link"
                    >
                        {{ __('Blog') }}
                    </a>

                    <iconify-icon
                        icon="lucide:chevron-right"
                        class="st:text-xs"
                    ></iconify-icon>

                    <span class="st-breadcrumb-current">
                        {{ $post->title }}
                    </span>

                </nav>


                {{-- Meta --}}
                <div class="st:flex st:flex-wrap st:items-center st:gap-4 st:mb-6 st:text-sm st:text-gray-500 st:dark:text-gray-400">

                    <span class="st:flex st:items-center st:gap-1">
                        <iconify-icon
                            icon="lucide:calendar"
                            aria-hidden="true"
                        ></iconify-icon>

                        {{ $post->created_at->format('F d, Y') }}
                    </span>


                    @if($post->author)

                        <span class="st:flex st:items-center st:gap-1">
                            <iconify-icon
                                icon="lucide:user"
                                aria-hidden="true"
                            ></iconify-icon>

                            {{ $post->author->name }}
                        </span>

                    @endif


                    @if($post->terms?->where('taxonomy', 'category')->count() > 0)

                        @foreach($post->terms->where('taxonomy', 'category') as $category)

                            <a
                                wire:navigate
                                href="{{ route('starter26.category', $category->slug) }}"
                                class="st-category st:hover:bg-gray-200 st:dark:hover:bg-gray-600 st:transition-colors"
                            >
                                {{ $category->name }}
                            </a>

                        @endforeach

                    @endif

                </div>


                {{-- Title --}}
                <h1 class="st:text-3xl st:md:text-4xl st:font-bold st:text-gray-900 st:dark:text-white st:mb-8 st:leading-tight">
                    {{ $post->title }}
                </h1>


                {{-- Tags --}}
                @if($post->terms?->where('taxonomy', 'tag')->count() > 0)

                    <div class="st:flex st:flex-wrap st:gap-2 st:mb-8">

                        @foreach($post->terms->where('taxonomy', 'tag') as $tag)

                            <a
                                wire:navigate
                                href="{{ route('starter26.tag', $tag->slug) }}"
                                class="st-tag"
                            >
                                #{{ $tag->name }}
                            </a>

                        @endforeach

                    </div>

                @endif


                {{-- Content --}}
                <div class="st-prose st-page-content">
                    {!! \Modules\Starter26\Support\ContentSanitizer::clean($post->content) !!}
                </div>


                {{-- Share --}}
                <div class="st:mt-12 st:pt-8 st:border-t st:border-gray-200 st:dark:border-gray-700">

                    <h3 class="st:text-sm st:font-semibold st:text-gray-900 st:dark:text-white st:mb-4">
                        {{ __('Share this post') }}
                    </h3>

                    <div class="st:flex st:gap-2">

                        {{-- Twitter --}}
                        <a
                            href="https://twitter.com/intent/tweet?url={{ urlencode(request()->url()) }}&text={{ urlencode($post->title) }}"
                            target="_blank"
                            rel="noopener"
                            class="st:p-2 st:rounded-lg st:bg-gray-100 st:dark:bg-gray-800 st:text-gray-600 st:dark:text-gray-400 st:hover:bg-blue-100 st:hover:text-blue-600 st:transition-colors"
                            aria-label="{{ __('Share on Twitter') }}"
                        >
                            <iconify-icon
                                icon="mdi:twitter"
                                class="st:text-xl"
                                aria-hidden="true"
                            ></iconify-icon>
                        </a>


                        {{-- Facebook --}}
                        <a
                            href="https://www.facebook.com/sharer/sharer.php?u={{ urlencode(request()->url()) }}"
                            target="_blank"
                            rel="noopener"
                            class="st:p-2 st:rounded-lg st:bg-gray-100 st:dark:bg-gray-800 st:text-gray-600 st:dark:text-gray-400 st:hover:bg-blue-100 st:hover:text-blue-600 st:transition-colors"
                            aria-label="{{ __('Share on Facebook') }}"
                        >
                            <iconify-icon
                                icon="mdi:facebook"
                                class="st:text-xl"
                                aria-hidden="true"
                            ></iconify-icon>
                        </a>


                        {{-- LinkedIn --}}
                        <a
                            href="https://www.linkedin.com/shareArticle?mini=true&url={{ urlencode(request()->url()) }}&title={{ urlencode($post->title) }}"
                            target="_blank"
                            rel="noopener"
                            class="st:p-2 st:rounded-lg st:bg-gray-100 st:dark:bg-gray-800 st:text-gray-600 st:dark:text-gray-400 st:hover:bg-blue-100 st:hover:text-blue-600 st:transition-colors"
                            aria-label="{{ __('Share on LinkedIn') }}"
                        >
                            <iconify-icon
                                icon="mdi:linkedin"
                                class="st:text-xl"
                                aria-hidden="true"
                            ></iconify-icon>
                        </a>


                        {{-- Copy Link --}}
                        <button
                            type="button"
                            onclick="navigator.clipboard.writeText('{{ request()->url() }}')"
                            class="st:p-2 st:rounded-lg st:bg-gray-100 st:dark:bg-gray-800 st:text-gray-600 st:dark:text-gray-400 st:hover:bg-green-100 st:hover:text-green-600 st:transition-colors"
                            aria-label="{{ __('Copy link') }}"
                        >
                            <iconify-icon
                                icon="lucide:link"
                                class="st:text-xl"
                                aria-hidden="true"
                            ></iconify-icon>
                        </button>

                    </div>

                </div>


                {{-- Navigation --}}
                @if($previousPost || $nextPost)

                    <nav class="st:mt-12 st:pt-8 st:border-t st:border-gray-200 st:dark:border-gray-700">

                        <div class="st:grid st:grid-cols-1 st:md:grid-cols-2 st:gap-4">

                            {{-- Previous Post --}}
                            @if($previousPost)

                                <a
                                    wire:navigate
                                    href="{{ route('starter26.post', $previousPost->slug) }}"
                                    class="st:flex st:items-center st:gap-4 st:p-4 st:rounded-lg st:border st:border-gray-200 st:dark:border-gray-700 st:hover:border-primary st:transition-colors st:group"
                                >

                                    <iconify-icon
                                        icon="lucide:arrow-left"
                                        class="st:text-xl st:text-gray-400 group-st:hover:text-primary st:transition-colors"
                                        aria-hidden="true"
                                    ></iconify-icon>

                                    <div class="st:flex-1 st:min-w-0">

                                        <span class="st:text-xs st:text-gray-500 st:dark:text-gray-400">
                                            {{ __('Previous') }}
                                        </span>

                                        <p class="st:text-sm st:font-medium st:text-gray-900 st:dark:text-white st:truncate">
                                            {{ $previousPost->title }}
                                        </p>

                                    </div>

                                </a>

                            @else

                                <div></div>

                            @endif


                            {{-- Next Post --}}
                            @if($nextPost)

                                <a
                                    wire:navigate
                                    href="{{ route('starter26.post', $nextPost->slug) }}"
                                    class="st:flex st:items-center st:gap-4 st:p-4 st:rounded-lg st:border st:border-gray-200 st:dark:border-gray-700 st:hover:border-primary st:transition-colors st:group st:text-right"
                                >

                                    <div class="st:flex-1 st:min-w-0">

                                        <span class="st:text-xs st:text-gray-500 st:dark:text-gray-400">
                                            {{ __('Next') }}
                                        </span>

                                        <p class="st:text-sm st:font-medium st:text-gray-900 st:dark:text-white st:truncate">
                                            {{ $nextPost->title }}
                                        </p>

                                    </div>

                                    <iconify-icon
                                        icon="lucide:arrow-right"
                                        class="st:text-xl st:text-gray-400 group-st:hover:text-primary st:transition-colors"
                                        aria-hidden="true"
                                    ></iconify-icon>

                                </a>

                            @endif

                        </div>

                    </nav>

                @endif

            </div>

        </div>

    </article>


    {{-- Related Posts --}}
    @if(count($relatedPosts) > 0)

        <section class="st-section st:bg-gray-50 st:dark:bg-gray-800">

            <div class="st-container">

                <h2 class="st-section-title st:text-gray-900 st:dark:text-white">
                    {{ __('Related Posts') }}
                </h2>


                <div class="st:grid st:grid-cols-1 st:md:grid-cols-2 st:lg:grid-cols-3 st:gap-6">

                    @foreach($relatedPosts as $relatedPost)

                        <article class="st-card st-post-card">

                            <div class="st-card-body">

                                <div class="st-post-meta">

                                    <span class="st:flex st:items-center st:gap-1">

                                        <iconify-icon
                                            icon="lucide:calendar"
                                            aria-hidden="true"
                                        ></iconify-icon>

                                        {{ $relatedPost->created_at->format('M d, Y') }}

                                    </span>

                                </div>


                                <h3 class="st-post-title st:text-gray-900 st:dark:text-white">

                                    <a
                                        wire:navigate
                                        href="{{ route('starter26.post', $relatedPost->slug) }}"
                                        class="st:text-gray-900 st:dark:text-white"
                                    >
                                        {{ $relatedPost->title }}
                                    </a>

                                </h3>


                                <p class="st-post-excerpt st:text-gray-600 st:dark:text-gray-300">
                                    {{ Str::limit(strip_tags($relatedPost->content), 100) }}
                                </p>

                            </div>

                        </article>

                    @endforeach

                </div>

            </div>

        </section>

    @endif

</div>
