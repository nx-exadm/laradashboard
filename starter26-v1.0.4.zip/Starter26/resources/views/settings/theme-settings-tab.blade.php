@php
    $pages = \App\Models\Post::where('post_type', 'page')
        ->where('status', 'published')
        ->orderBy('title')
        ->get(['id', 'title']);
@endphp

<x-card>
    <x-slot name="header">
        {{ __('Starter26 Theme') }}
    </x-slot>
    <x-slot name="headerDescription">
        {{ __('Configure the Starter26 frontend theme settings.') }}
    </x-slot>

    <div class="space-y-6">
        {{-- Homepage Picker --}}
        <div>
            <label for="starter26_homepage_id" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                {{ __('Homepage') }}
            </label>
            <select name="starter26_homepage_id" id="starter26_homepage_id"
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-500 focus:ring-brand-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300 sm:text-sm">
                <option value="">{{ __('— Default (static homepage) —') }}</option>
                @foreach($pages as $page)
                    <option value="{{ $page->id }}" @if(config('settings.starter26_homepage_id') == $page->id) selected @endif>
                        {{ $page->title }}
                    </option>
                @endforeach
            </select>
            <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
                {{ __('Select a page to use as your homepage. The page should be built with LaraBuilder blocks.') }}
            </p>
        </div>

        {{-- Blog Page Picker --}}
        <div>
            <label for="starter26_blog_page_id" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                {{ __('Blog Page') }}
            </label>
            <select name="starter26_blog_page_id" id="starter26_blog_page_id"
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-500 focus:ring-brand-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300 sm:text-sm">
                <option value="">{{ __('— Default (static header) —') }}</option>
                @foreach($pages as $page)
                    <option value="{{ $page->id }}" @if(config('settings.starter26_blog_page_id') == $page->id) selected @endif>
                        {{ $page->title }}
                    </option>
                @endforeach
            </select>
            <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
                {{ __('Select a page whose block content will appear as a header above the blog listing.') }}
            </p>
        </div>

        {{-- Blog URL Prefix --}}
        <div>
            <label for="starter26_blog_url_prefix" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                {{ __('Blog URL Prefix') }}
            </label>
            <input type="text" name="starter26_blog_url_prefix" id="starter26_blog_url_prefix"
                   value="{{ config('settings.starter26_blog_url_prefix', 'posts') }}"
                   class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-500 focus:ring-brand-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300 sm:text-sm"
                   placeholder="posts">
            <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
                {{ __('URL prefix for the blog listing page. Default: "posts" (e.g., /posts).') }}
            </p>
        </div>

        {{-- Posts Per Page --}}
        <div>
            <label for="starter26_posts_per_page" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                {{ __('Posts Per Page') }}
            </label>
            <input type="number" name="starter26_posts_per_page" id="starter26_posts_per_page"
                   value="{{ config('settings.starter26_posts_per_page', 12) }}"
                   min="1" max="100"
                   class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-500 focus:ring-brand-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300 sm:text-sm">
        </div>
    </div>
</x-card>

<x-card class="mt-6">
    <x-slot name="header">
        {{ __('Footer Settings') }}
    </x-slot>
    <x-slot name="headerDescription">
        {{ __('Customize the footer content and branding.') }}
    </x-slot>

    <div class="space-y-6">
        {{-- Footer Description --}}
        <div>
            <label for="starter26_footer_description" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                {{ __('Footer Description') }}
            </label>
            <textarea name="starter26_footer_description" id="starter26_footer_description" rows="3"
                      class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-500 focus:ring-brand-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300 sm:text-sm">{{ config('settings.starter26_footer_description', __('A modern starter theme built with Livewire, Alpine.js, and Tailwind CSS.')) }}</textarea>
        </div>

        {{-- Copyright Text --}}
        <div>
            <label for="starter26_copyright_text" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                {{ __('Copyright Text') }}
            </label>
            <input type="text" name="starter26_copyright_text" id="starter26_copyright_text"
                   value="{{ config('settings.starter26_copyright_text', '© {year} ' . config('app.name') . '. ' . __('All rights reserved.')) }}"
                   class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-500 focus:ring-brand-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300 sm:text-sm">
            <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
                {{ __('Use {year} as a placeholder for the current year.') }}
            </p>
        </div>
    </div>
</x-card>
