<?php

use Illuminate\Support\Facades\Route;
use Modules\Starter26\Http\Controllers\Starter26Controller;

Route::middleware(['auth:sanctum'])->prefix('v1')->group(function () {
    Route::apiResource('starter26s', Starter26Controller::class)->names('starter26');
});
