<?php

use Illuminate\Support\Facades\Route;
use Modules\Starter26\Http\Controllers\SeoController;
use Modules\Starter26\Livewire\Pages\Category;
use Modules\Starter26\Livewire\Pages\Home;
use Modules\Starter26\Livewire\Pages\Page;
use Modules\Starter26\Livewire\Pages\Posts;
use Modules\Starter26\Livewire\Pages\Search;
use Modules\Starter26\Livewire\Pages\SinglePost;
use Modules\Starter26\Livewire\Pages\Tag;

/*
|--------------------------------------------------------------------------
| SEO: robots.txt & sitemap.xml
|--------------------------------------------------------------------------
|
| These always live at the canonical site root, regardless of the
| configurable Starter26 route prefix below, since crawlers expect
| them at /robots.txt and /sitemap.xml.
|
*/
Route::get('/robots.txt', [SeoController::class, 'robots'])->name('starter26.robots');
Route::get('/sitemap.xml', [SeoController::class, 'sitemap'])->name('starter26.sitemap');
Route::get('/sitemap.xsl', [SeoController::class, 'sitemapStylesheet'])->name('starter26.sitemap-xsl');

/*
|--------------------------------------------------------------------------
| Starter26 Frontend Routes
|--------------------------------------------------------------------------
|
| These routes define the public frontend pages for the Starter26 theme.
| All routes use Livewire components for a seamless SPA-like experience.
|
*/

// The route prefix can be configured via config('starter26.route_prefix')
$prefix = config('starter26.route_prefix', '');
$blogSlug = config('settings.blog_url_prefix', 'blog');

Route::prefix($prefix)->group(function () use ($blogSlug) {
    // Home page
    Route::get('/', Home::class)->name('starter26.home');

    // Search
    Route::get('/search', Search::class)->name('starter26.search');

    // Blog
    Route::get("/{$blogSlug}", Page::class)->name('starter26.posts')->defaults('slug', $blogSlug);
    Route::get("/{$blogSlug}/{slug}", SinglePost::class)->name('starter26.post');

    // Taxonomies
    Route::get('/category/{slug}', Category::class)->name('starter26.category');
    Route::get('/tag/{slug}', Tag::class)->name('starter26.tag');

    // Catch-all page route (MUST be last)
    // Exclude reserved paths so admin, login, api, etc. are not intercepted
    Route::get('/{slug}', Page::class)
        ->name('starter26.page')
        ->where('slug', '^(?!admin|login|register|api|livewire|sanctum|password|email|logout|locale|auth|unsubscribe|profile|install|screenshot-login|demo-preview|sitemap\.xml|sitemap\.xsl|robots\.txt|forum|forums|customform|forms|_).*$');
});
