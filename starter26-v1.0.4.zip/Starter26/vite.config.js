import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import tailwindcss from '@tailwindcss/vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Determine if we're building for distribution (self-contained) or development
const isDistBuild = process.env.MODULE_DIST_BUILD === 'true';

// For distribution: build inside module directory (self-contained ZIP)
// For development: build to public directory (hot reload works)
const distOutDir = path.resolve(__dirname, 'dist/build-starter26');
const devOutDir = path.resolve(__dirname, '../../public/build-starter26');

export default defineConfig({
    build: {
        outDir: isDistBuild ? distOutDir : devOutDir,
        emptyOutDir: true,
        manifest: 'manifest.json',
    },
    plugins: [
        laravel({
            publicDirectory: isDistBuild ? path.resolve(__dirname, 'dist') : path.resolve(__dirname, '../../public'),
            buildDirectory: 'build-starter26',
            input: [
                'modules/starter26/resources/assets/css/app.css',
                'modules/starter26/resources/assets/js/app.js',
            ],
            refresh: true,
        }),
        tailwindcss(),
    ],
});
